package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.McqQuestionRecord
import com.example.data.model.QuizAttemptRecord
import com.example.data.model.QuizCollectionRecord
import com.example.data.model.QuizModeType
import com.example.data.model.RemoteUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Local-only Quiz controller active when user has not signed in with Google.
 * Strictly avoids any FirebaseFirestore instantiation or queries while enabling
 * offline textbook/random/chapter/timed/exam quiz modes.
 */
class GuestQuizViewModel : ViewModel(), QuizController {

    private val engine = QuizSessionEngine(viewModelScope)

    override val selectionState: StateFlow<QuizSelectionState> = engine.selectionState
    override val sessionState: StateFlow<QuizSessionState> = engine.sessionState

    override val publishedQuizzes: StateFlow<RemoteUiState<List<QuizCollectionRecord>>> =
        MutableStateFlow(RemoteUiState.Success(emptyList()))

    override val publishedMcqs: StateFlow<RemoteUiState<List<McqQuestionRecord>>> =
        MutableStateFlow(RemoteUiState.Success(emptyList()))

    override val myAttempts: StateFlow<RemoteUiState<List<QuizAttemptRecord>>> =
        MutableStateFlow(RemoteUiState.Success(emptyList()))

    override fun selectSubject(subjectId: String) = engine.selectSubject(subjectId)

    override fun selectChapter(chapterNumber: Int?) = engine.selectChapter(chapterNumber)

    override fun selectMode(mode: QuizModeType) = engine.selectMode(mode)

    override fun setQuestionLimit(limit: Int) = engine.setQuestionLimit(limit)

    override fun setDurationMinutes(minutes: Int) = engine.setDurationMinutes(minutes)

    override fun clearBannerMessage() = engine.clearBannerMessage()

    override fun availableBookCountForSubject(subjectId: String): Int =
        engine.availableBookCountForSubject(subjectId)

    override fun availablePublishedAgentCountForSubject(subjectId: String): Int = 0

    override fun availableCountForChapter(subjectId: String, chapterNumber: Int): Int =
        engine.availableCountForChapter(subjectId, chapterNumber, emptyList())

    override fun startConfiguredQuiz() {
        engine.startConfiguredQuiz(
            agentRaw = emptyList(),
            isAuthenticated = false,
            onTimeoutSubmit = { submitActiveQuiz(onRecordMistake = null) }
        )
    }

    override fun startPublishedQuizCollection(quiz: QuizCollectionRecord) {
        engine.setBannerMessage("এজেন্ট প্রকাশিত কুইজ শুরু করতে Google দিয়ে সাইন-ইন করুন।")
    }

    override fun selectAnswer(questionIndex: Int, optionIndex: Int) =
        engine.selectAnswer(questionIndex, optionIndex)

    override fun goToQuestion(index: Int) = engine.goToQuestion(index)

    override fun nextQuestion() = engine.nextQuestion()

    override fun previousQuestion() = engine.previousQuestion()

    override fun submitActiveQuiz(
        onRecordMistake: ((
            subjectName: String,
            chapterTitle: String,
            question: String,
            studentAnswer: String,
            correctAnswer: String,
            explanation: String
        ) -> Unit)?
    ) {
        engine.evaluateAndMarkSubmitted(
            userId = "local_guest",
            isSavingToCloud = false,
            initialStatusMessage = "ভুল প্রশ্নসমূহ 'ভুলের খাতা'-তে যুক্ত হয়েছে। ক্লাউড স্কোর সংরক্ষণে Google সাইন-ইন করুন।",
            onRecordMistake = onRecordMistake
        )
    }

    override fun closeSession() = engine.closeSession()

    override fun onCleared() {
        super.onCleared()
        engine.cancelTimers()
    }
}
