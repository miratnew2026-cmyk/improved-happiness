package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.McqQuestionRecord
import com.example.data.model.QuizAttemptRecord
import com.example.data.model.QuizCollectionRecord
import com.example.data.model.QuizModeType
import com.example.data.model.RemoteUiState
import com.example.data.model.toPlayableMcq
import com.example.data.remote.QuizAgentRepository
import com.example.data.remote.unwrapFirestoreException
import com.example.data.remote.userFriendlyFirestoreMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class QuizViewModel(
    private val repository: QuizAgentRepository,
    private val currentUserId: String
) : ViewModel(), QuizController {

    private val engine = QuizSessionEngine(viewModelScope)

    override val publishedQuizzes: StateFlow<RemoteUiState<List<QuizCollectionRecord>>> =
        repository.observePublishedQuizzes()
            .map<List<QuizCollectionRecord>, RemoteUiState<List<QuizCollectionRecord>>> { quizzes ->
                RemoteUiState.Success(quizzes)
            }
            .catch { error ->
                val fsEx = error.unwrapFirestoreException()
                if (fsEx == null && error is CancellationException) throw error
                emit(
                    RemoteUiState.Error(
                        error.userFriendlyFirestoreMessage("প্রকাশিত কুইজগুলো লোড করা যায়নি।")
                    )
                )
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = RemoteUiState.Loading
            )

    override val publishedMcqs: StateFlow<RemoteUiState<List<McqQuestionRecord>>> =
        repository.observePublishedMcqs()
            .map<List<McqQuestionRecord>, RemoteUiState<List<McqQuestionRecord>>> { mcqs ->
                RemoteUiState.Success(mcqs)
            }
            .catch { error ->
                val fsEx = error.unwrapFirestoreException()
                if (fsEx == null && error is CancellationException) throw error
                emit(
                    RemoteUiState.Error(
                        error.userFriendlyFirestoreMessage("এজেন্ট MCQ প্রশ্ন লোড করা যায়নি।")
                    )
                )
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = RemoteUiState.Loading
            )

    override val myAttempts: StateFlow<RemoteUiState<List<QuizAttemptRecord>>> =
        repository.observeMyAttempts(currentUserId)
            .map<List<QuizAttemptRecord>, RemoteUiState<List<QuizAttemptRecord>>> { attempts ->
                RemoteUiState.Success(attempts)
            }
            .catch { error ->
                val fsEx = error.unwrapFirestoreException()
                if (fsEx == null && error is CancellationException) throw error
                emit(
                    RemoteUiState.Error(
                        error.userFriendlyFirestoreMessage("আপনার কুইজ ফলাফলের ইতিহাস লোড করা যায়নি।")
                    )
                )
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = RemoteUiState.Loading
            )

    override val selectionState: StateFlow<QuizSelectionState> = engine.selectionState
    override val sessionState: StateFlow<QuizSessionState> = engine.sessionState

    override fun selectSubject(subjectId: String) = engine.selectSubject(subjectId)

    override fun selectChapter(chapterNumber: Int?) = engine.selectChapter(chapterNumber)

    override fun selectMode(mode: QuizModeType) = engine.selectMode(mode)

    override fun setQuestionLimit(limit: Int) = engine.setQuestionLimit(limit)

    override fun setDurationMinutes(minutes: Int) = engine.setDurationMinutes(minutes)

    override fun clearBannerMessage() = engine.clearBannerMessage()

    override fun availableBookCountForSubject(subjectId: String): Int =
        engine.availableBookCountForSubject(subjectId)

    override fun availablePublishedAgentCountForSubject(subjectId: String): Int {
        val state = publishedMcqs.value as? RemoteUiState.Success ?: return 0
        return state.data.count { it.subjectId == subjectId }
    }

    override fun availableCountForChapter(subjectId: String, chapterNumber: Int): Int {
        val agentList = (publishedMcqs.value as? RemoteUiState.Success)?.data.orEmpty()
        return engine.availableCountForChapter(subjectId, chapterNumber, agentList)
    }

    override fun startConfiguredQuiz() {
        val agentRaw = (publishedMcqs.value as? RemoteUiState.Success)?.data.orEmpty()
        engine.startConfiguredQuiz(
            agentRaw = agentRaw,
            isAuthenticated = true,
            onTimeoutSubmit = { submitActiveQuiz(onRecordMistake = null) }
        )
    }

    override fun startPublishedQuizCollection(quiz: QuizCollectionRecord) {
        val allPublished = (publishedMcqs.value as? RemoteUiState.Success)?.data.orEmpty()
        val mcqMap = allPublished.associateBy { it.id }

        val resolvedFromIds = quiz.mcqIds.mapNotNull { id -> mcqMap[id]?.toPlayableMcq() }
        val resolvedQuestions = resolvedFromIds.ifEmpty {
            allPublished.filter { it.quizId == quiz.id }.map { it.toPlayableMcq() }
        }

        if (resolvedQuestions.isEmpty()) {
            engine.setBannerMessage("'${quiz.title}' কুইজের প্রশ্নগুলো লোড হয়নি বা এখনো প্রকাশিত হয়নি।")
            return
        }

        val mappedMode = QuizModeType.entries.find { it.wireKey == quiz.quizType } ?: QuizModeType.AGENT_UPLOADED
        engine.launchSession(
            quizId = quiz.id,
            quizTitle = quiz.title,
            mode = mappedMode,
            subjectId = quiz.subjectId,
            subjectName = quiz.subjectName.ifBlank { "সকল বিষয়" },
            chapterTitle = quiz.chapterTitle.ifBlank { "সমন্বিত অধ্যায়" },
            questions = resolvedQuestions,
            durationMinutes = quiz.durationMinutes.toInt().coerceIn(1, 90),
            onTimeoutSubmit = { submitActiveQuiz(onRecordMistake = null) }
        )
    }

    override fun selectAnswer(questionIndex: Int, optionIndex: Int) =
        engine.selectAnswer(questionIndex, optionIndex)

    override fun goToQuestion(index: Int) = engine.goToQuestion(index)

    override fun nextQuestion() = engine.nextQuestion()

    override fun previousQuestion() = engine.previousQuestion()

    override fun submitActiveQuiz(
        onRecordMistake: ((
            subjectName: String,
            chapterTitle: String,
            question: String,
            studentAnswer: String,
            correctAnswer: String,
            explanation: String
        ) -> Unit)?
    ) {
        val attemptRecord = engine.evaluateAndMarkSubmitted(
            userId = currentUserId,
            isSavingToCloud = true,
            initialStatusMessage = null,
            onRecordMistake = onRecordMistake
        ) ?: return

        viewModelScope.launch {
            val result = repository.submitQuizAttempt(attemptRecord)
            engine.updateSaveStatus(
                isSaving = false,
                message = result.fold(
                    onSuccess = { "ফলাফল ক্লাউডে সংরক্ষিত হয়েছে।" },
                    onFailure = { err ->
                        err.userFriendlyFirestoreMessage("ক্লাউডে ফলাফল সেভ করতে সমস্যা হয়েছে।")
                    }
                )
            )
        }
    }

    override fun closeSession() = engine.closeSession()

    override fun onCleared() {
        super.onCleared()
        engine.cancelTimers()
    }
}
