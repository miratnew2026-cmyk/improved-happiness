package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiRepository
import com.example.data.ai.AiResult
import com.example.data.local.ChapterProgressEntity
import com.example.data.local.ChatMessageEntity
import com.example.data.local.DailyGoalEntity
import com.example.data.local.ExamResultEntity
import com.example.data.local.MistakeEntity
import com.example.data.local.ScheduledTaskEntity
import com.example.data.local.StudyDatabase
import com.example.data.local.StudyPlanConfigEntity
import com.example.data.local.StudySessionEntity
import com.example.data.model.Bangla1ProgressSummary
import com.example.data.model.BoardMcqQuestion
import com.example.data.model.ChapterInfo
import com.example.data.model.MathPriorityMetrics
import com.example.data.model.PlanProgressMetrics
import com.example.data.model.SciencePriorityMetrics
import com.example.data.model.SocialIctPriorityMetrics
import com.example.data.model.SscSyllabusData
import com.example.data.model.StudyPlanGenerator
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = StudyDatabase.getInstance(application)
    private val dao = database.studyDao()
    private val aiRepository = AiRepository()

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    // --- Local Database Flows ---
    val allChapters = dao.getAllChapters()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStudySessions = dao.getAllStudySessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalStudyMinutes = dao.getTotalStudyMinutes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val todayString: String
        get() = dateFormat.format(Date())

    val tomorrowString: String
        get() {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
            return dateFormat.format(cal.time)
        }

    val todayGoals = dao.getGoalsForDate(todayString)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val examResults = dao.getAllExamResults()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mistakes = dao.getAllMistakes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatMessages = dao.getChatMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Future Study Plan Flows ---
    val activePlanConfig: StateFlow<StudyPlanConfigEntity?> = dao.getActivePlanConfig()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allScheduledTasks: StateFlow<List<ScheduledTaskEntity>> = dao.getAllScheduledTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Computed Plan Metrics Flow
    val planMetrics: StateFlow<PlanProgressMetrics> = combine(
        allChapters,
        activePlanConfig,
        allScheduledTasks
    ) { chapters, config, tasks ->
        val totalChaptersCount = SscSyllabusData.totalChaptersCount
        val completedCount = chapters.count { it.isCompleted }
        val remainingCount = (totalChaptersCount - completedCount).coerceAtLeast(0)
        val percent = if (totalChaptersCount > 0) (completedCount * 100) / totalChaptersCount else 0

        val totalDays = config?.totalPlanDays ?: 120
        val startMillis = config?.startDateMillis ?: System.currentTimeMillis()
        val targetMillis = config?.targetCompletionDateMillis ?: (startMillis + totalDays.toLong() * 24 * 60 * 60 * 1000)

        val daysDiff = ((System.currentTimeMillis() - startMillis) / (24 * 60 * 60 * 1000)).toInt().coerceAtLeast(0)
        val remainingDays = (totalDays - daysDiff).coerceAtLeast(0)

        val pendingMcqs = tasks.filter { !it.isCompleted }.sumOf { it.mcqCount }
        val pendingCqs = tasks.filter { !it.isCompleted }.sumOf { it.cqCount }
        val pendingBoard = tasks.filter { !it.isCompleted }.sumOf { it.boardQuestionCount }

        val missedCount = tasks.count { it.dateString < todayString && !it.isCompleted && !it.isRecovered }

        PlanProgressMetrics(
            totalChapters = totalChaptersCount,
            completedChapters = completedCount,
            remainingChapters = remainingCount,
            syllabusPercent = percent,
            totalPlanDays = totalDays,
            elapsedDays = daysDiff,
            remainingDays = remainingDays,
            dailyHours = config?.dailyStudyHours ?: 4,
            pendingMcqCount = pendingMcqs,
            pendingCqCount = pendingCqs,
            pendingBoardQuestionCount = pendingBoard,
            missedTasksCount = missedCount,
            targetCompletionDate = StudyPlanGenerator.formatDisplayDate(targetMillis)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PlanProgressMetrics())

    // --- Bangla 1st Paper Dedicated Routine & Progress ---
    val bangla1ProseChapters: List<ChapterInfo> =
        SscSyllabusData.getSubject("bangla_1")?.chapters?.filter { it.section == "গদ্য" } ?: emptyList()

    val bangla1PoetryChapters: List<ChapterInfo> =
        SscSyllabusData.getSubject("bangla_1")?.chapters?.filter { it.section == "কবিতা" } ?: emptyList()

    val bangla1Metrics: StateFlow<Bangla1ProgressSummary> = combine(
        allChapters,
        allScheduledTasks
    ) { chapters, tasks ->
        val b1Chapters = chapters.filter { it.subjectId == "bangla_1" }
        val proseDone = b1Chapters.count { ch -> ch.isCompleted && (bangla1ProseChapters.any { it.number == ch.chapterNumber }) }
        val poetryDone = b1Chapters.count { ch -> ch.isCompleted && (bangla1PoetryChapters.any { it.number == ch.chapterNumber }) }
        val totalDone = proseDone + poetryDone
        val totalChapters = 53
        val remaining = (totalChapters - totalDone).coerceAtLeast(0)
        val percent = if (totalChapters > 0) (totalDone * 100) / totalChapters else 0

        val b1Tasks = tasks.filter { it.subjectId == "bangla_1" }
        val mcqDone = b1Tasks.filter { it.mcqPracticeCompleted }.sumOf { it.mcqCount }
        val totalMcq = if (b1Tasks.isNotEmpty()) b1Tasks.sumOf { it.mcqCount } else (53 * 20)
        val cqDone = b1Tasks.filter { it.cqPracticeCompleted }.sumOf { it.cqCount }
        val totalCq = if (b1Tasks.isNotEmpty()) b1Tasks.sumOf { it.cqCount } else (53 * 3)
        val boardDone = b1Tasks.filter { it.boardQuestionsSolved }.sumOf { it.boardQuestionCount }
        val totalBoard = if (b1Tasks.isNotEmpty()) b1Tasks.sumOf { it.boardQuestionCount } else (53 * 8)

        val actualPlannedDays = SscSyllabusData.getSubject("bangla_1")?.chapters?.sumOf { it.defaultDays } ?: 81

        Bangla1ProgressSummary(
            proseTotal = 25,
            proseCompleted = proseDone,
            poetryTotal = 28,
            poetryCompleted = poetryDone,
            totalChapters = totalChapters,
            completedChapters = totalDone,
            remainingChapters = remaining,
            percentage = percent,
            plannedDays = actualPlannedDays,
            mcqCompleted = mcqDone,
            mcqTotal = totalMcq,
            cqCompleted = cqDone,
            cqTotal = totalCq,
            boardCompleted = boardDone,
            boardTotal = totalBoard
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Bangla1ProgressSummary())

    // --- Mathematics Priority Metrics (31 Chapters: General Math 17 + Higher Math 14) ---
    val mathPriorityMetrics: StateFlow<MathPriorityMetrics> = allChapters.map { chapters ->
        val gmChapters = chapters.filter { it.subjectId == "general_math" }
        val hmChapters = chapters.filter { it.subjectId == "higher_math" }

        val gmDone = gmChapters.count { it.isCompleted }
        val hmDone = hmChapters.count { it.isCompleted }
        val totalDone = gmDone + hmDone

        val gmTotal = SscSyllabusData.getSubject("general_math")?.chapters?.size ?: 17
        val hmTotal = SscSyllabusData.getSubject("higher_math")?.chapters?.size ?: 14
        val total = gmTotal + hmTotal

        val gmPct = if (gmTotal > 0) (gmDone * 100) / gmTotal else 0
        val hmPct = if (hmTotal > 0) (hmDone * 100) / hmTotal else 0
        val totalPct = if (total > 0) (totalDone * 100) / total else 0

        MathPriorityMetrics(
            generalMathTotal = gmTotal,
            generalMathCompleted = gmDone,
            generalMathPercent = gmPct,
            higherMathTotal = hmTotal,
            higherMathCompleted = hmDone,
            higherMathPercent = hmPct,
            totalChapters = total,
            totalCompleted = totalDone,
            totalPercent = totalPct,
            importantCount = 28,
            normalCount = 3,
            lowCount = 0
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MathPriorityMetrics())

    // --- Science Priority Metrics (39 Chapters: Physics 13 + Chemistry 12 + Biology 14) ---
    val sciencePriorityMetrics: StateFlow<SciencePriorityMetrics> = allChapters.map { chapters ->
        val phySubject = SscSyllabusData.getSubject("physics")
        val chemSubject = SscSyllabusData.getSubject("chemistry")
        val bioSubject = SscSyllabusData.getSubject("biology")

        val phyChapters = chapters.filter { it.subjectId == "physics" }
        val chemChapters = chapters.filter { it.subjectId == "chemistry" }
        val bioChapters = chapters.filter { it.subjectId == "biology" }

        val phyTotal = phySubject?.chapters?.size ?: 13
        val chemTotal = chemSubject?.chapters?.size ?: 12
        val bioTotal = bioSubject?.chapters?.size ?: 14

        val phyDone = phyChapters.count { it.isCompleted }.coerceAtMost(phyTotal)
        val chemDone = chemChapters.count { it.isCompleted }.coerceAtMost(chemTotal)
        val bioDone = bioChapters.count { it.isCompleted }.coerceAtMost(bioTotal)

        val total = phyTotal + chemTotal + bioTotal
        val totalDone = phyDone + chemDone + bioDone

        val allScienceChapters = phySubject?.chapters.orEmpty() +
            chemSubject?.chapters.orEmpty() +
            bioSubject?.chapters.orEmpty()

        SciencePriorityMetrics(
            physicsTotal = phyTotal,
            physicsCompleted = phyDone,
            physicsRemaining = (phyTotal - phyDone).coerceAtLeast(0),
            physicsPercent = if (phyTotal > 0) (phyDone * 100) / phyTotal else 0,
            chemistryTotal = chemTotal,
            chemistryCompleted = chemDone,
            chemistryRemaining = (chemTotal - chemDone).coerceAtLeast(0),
            chemistryPercent = if (chemTotal > 0) (chemDone * 100) / chemTotal else 0,
            biologyTotal = bioTotal,
            biologyCompleted = bioDone,
            biologyRemaining = (bioTotal - bioDone).coerceAtLeast(0),
            biologyPercent = if (bioTotal > 0) (bioDone * 100) / bioTotal else 0,
            totalChapters = total,
            totalCompleted = totalDone,
            totalRemaining = (total - totalDone).coerceAtLeast(0),
            totalPercent = if (total > 0) (totalDone * 100) / total else 0,
            importantCount = allScienceChapters.count { it.importanceTag == "⭐" },
            normalCount = allScienceChapters.count { it.importanceTag == "☆" },
            lowCount = allScienceChapters.count { it.importanceTag == "🟡" }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SciencePriorityMetrics())

    // --- Social Studies & ICT Priority Metrics (26 Chapters: BGS 14 + Islam 5 + ICT 7) ---
    val socialIctPriorityMetrics: StateFlow<SocialIctPriorityMetrics> = allChapters.map { chapters ->
        val bgsSubject = SscSyllabusData.getSubject("bgs")
        val islamSubject = SscSyllabusData.getSubject("islam_moral")
        val ictSubject = SscSyllabusData.getSubject("ict")

        val bgsChapters = chapters.filter { it.subjectId == "bgs" }
        val islamChapters = chapters.filter { it.subjectId == "islam_moral" }
        val ictChapters = chapters.filter { it.subjectId == "ict" }

        val bgsTotal = bgsSubject?.chapters?.size ?: 14
        val islamTotal = islamSubject?.chapters?.size ?: 5
        val ictTotal = ictSubject?.chapters?.size ?: 7

        val bgsDone = bgsChapters.count { it.isCompleted }.coerceAtMost(bgsTotal)
        val islamDone = islamChapters.count { it.isCompleted }.coerceAtMost(islamTotal)
        val ictDone = ictChapters.count { it.isCompleted }.coerceAtMost(ictTotal)

        val total = bgsTotal + islamTotal + ictTotal
        val totalDone = bgsDone + islamDone + ictDone

        val allSocialIctChapters = bgsSubject?.chapters.orEmpty() +
            islamSubject?.chapters.orEmpty() +
            ictSubject?.chapters.orEmpty()

        SocialIctPriorityMetrics(
            bgsTotal = bgsTotal,
            bgsCompleted = bgsDone,
            bgsRemaining = (bgsTotal - bgsDone).coerceAtLeast(0),
            bgsPercent = if (bgsTotal > 0) (bgsDone * 100) / bgsTotal else 0,
            islamTotal = islamTotal,
            islamCompleted = islamDone,
            islamRemaining = (islamTotal - islamDone).coerceAtLeast(0),
            islamPercent = if (islamTotal > 0) (islamDone * 100) / islamTotal else 0,
            ictTotal = ictTotal,
            ictCompleted = ictDone,
            ictRemaining = (ictTotal - ictDone).coerceAtLeast(0),
            ictPercent = if (ictTotal > 0) (ictDone * 100) / ictTotal else 0,
            totalChapters = total,
            totalCompleted = totalDone,
            totalRemaining = (total - totalDone).coerceAtLeast(0),
            totalPercent = if (total > 0) (totalDone * 100) / total else 0,
            importantCount = allSocialIctChapters.count { it.importanceTag == "⭐" },
            normalCount = allSocialIctChapters.count { it.importanceTag == "☆" },
            lowCount = allSocialIctChapters.count { it.importanceTag == "🟡" }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SocialIctPriorityMetrics())

    // --- Study Timer (Pomodoro) State ---
    private val _timerRemainingSeconds = MutableStateFlow(25 * 60)
    val timerRemainingSeconds: StateFlow<Int> = _timerRemainingSeconds.asStateFlow()

    private val _timerIsRunning = MutableStateFlow(false)
    val timerIsRunning: StateFlow<Boolean> = _timerIsRunning.asStateFlow()

    private val _selectedTimerSubject = MutableStateFlow("সাধারণ গণিত")
    val selectedTimerSubject: StateFlow<String> = _selectedTimerSubject.asStateFlow()

    private var timerJob: Job? = null

    // --- AI Chat State ---
    private val _isAiStreaming = MutableStateFlow(false)
    val isAiStreaming: StateFlow<Boolean> = _isAiStreaming.asStateFlow()

    private val _currentStreamingChunk = MutableStateFlow("")
    val currentStreamingChunk: StateFlow<String> = _currentStreamingChunk.asStateFlow()

    private val _aiError = MutableStateFlow<String?>(null)
    val aiError: StateFlow<String?> = _aiError.asStateFlow()

    // --- Quick AI Explanation Modal ---
    private val _quickExplainTitle = MutableStateFlow<String?>(null)
    val quickExplainTitle: StateFlow<String?> = _quickExplainTitle.asStateFlow()

    private val _quickExplainContent = MutableStateFlow<String?>(null)
    val quickExplainContent: StateFlow<String?> = _quickExplainContent.asStateFlow()

    private val _isQuickExplainLoading = MutableStateFlow(false)
    val isQuickExplainLoading: StateFlow<Boolean> = _isQuickExplainLoading.asStateFlow()

    // --- Active Exam State ---
    private val _isExamActive = MutableStateFlow(false)
    val isExamActive: StateFlow<Boolean> = _isExamActive.asStateFlow()

    private val _examQuestions = MutableStateFlow<List<BoardMcqQuestion>>(emptyList())
    val examQuestions: StateFlow<List<BoardMcqQuestion>> = _examQuestions.asStateFlow()

    private val _examUserAnswers = MutableStateFlow<Map<Int, Int>>(emptyMap())
    val examUserAnswers: StateFlow<Map<Int, Int>> = _examUserAnswers.asStateFlow()

    private val _examTimeRemaining = MutableStateFlow(10 * 60)
    val examTimeRemaining: StateFlow<Int> = _examTimeRemaining.asStateFlow()

    private val _examSubmitted = MutableStateFlow(false)
    val examSubmitted: StateFlow<Boolean> = _examSubmitted.asStateFlow()

    private val _lastExamScore = MutableStateFlow<Pair<Int, Int>?>(null)
    val lastExamScore: StateFlow<Pair<Int, Int>?> = _lastExamScore.asStateFlow()

    private var examTimerJob: Job? = null

    init {
        seedInitialDataIfEmpty()
    }

    private fun seedInitialDataIfEmpty() {
        viewModelScope.launch {
            // Seed chapters in chapter_progress
            val existingChapters = dao.getAllChapters().firstOrNull().orEmpty()
            val bangla1Existing = existingChapters.filter { it.subjectId == "bangla_1" }
            if (existingChapters.isEmpty() || bangla1Existing.size < 53) {
                // Delete any old bangla_1 placeholder chapters (do NOT touch bangla_2 or other subjects!)
                dao.deleteChaptersForSubject("bangla_1")
                val b1Subject = SscSyllabusData.getSubject("bangla_1")
                val b1Entities = b1Subject?.chapters?.map { chapter ->
                    ChapterProgressEntity(
                        id = "bangla_1_ch_${chapter.number}",
                        subjectId = "bangla_1",
                        chapterNumber = chapter.number,
                        chapterTitle = chapter.title,
                        isCompleted = false,
                        notes = ""
                    )
                } ?: emptyList()
                dao.insertInitialChapters(b1Entities)

                // Seed other subjects if completely empty
                if (existingChapters.isEmpty()) {
                    val otherEntities = mutableListOf<ChapterProgressEntity>()
                    SscSyllabusData.subjects.filter { it.id != "bangla_1" }.forEach { subject ->
                        subject.chapters.forEach { chapter ->
                            otherEntities.add(
                                ChapterProgressEntity(
                                    id = "${subject.id}_ch_${chapter.number}",
                                    subjectId = subject.id,
                                    chapterNumber = chapter.number,
                                    chapterTitle = chapter.title,
                                    isCompleted = false,
                                    notes = ""
                                )
                            )
                        }
                    }
                    dao.insertInitialChapters(otherEntities)
                }
            }

            // Ensure General Math (17) and Higher Math (14) chapters match exact updated titles without duplication
            val expectedGmTitles = SscSyllabusData.getSubject("general_math")?.chapters?.map { it.title }.orEmpty()
            val expectedHmTitles = SscSyllabusData.getSubject("higher_math")?.chapters?.map { it.title }.orEmpty()
            val existingGmTitles = existingChapters
                .filter { it.subjectId == "general_math" }
                .sortedBy { it.chapterNumber }
                .map { it.chapterTitle }
            val existingHmTitles = existingChapters
                .filter { it.subjectId == "higher_math" }
                .sortedBy { it.chapterNumber }
                .map { it.chapterTitle }

            val mathChaptersNeedReplace = existingGmTitles != expectedGmTitles || existingHmTitles != expectedHmTitles
            if (mathChaptersNeedReplace) {
                dao.deleteChaptersForSubject("general_math")
                dao.deleteChaptersForSubject("higher_math")
                val mathEntities = mutableListOf<ChapterProgressEntity>()
                listOf("general_math", "higher_math").forEach { subId ->
                    SscSyllabusData.getSubject(subId)?.chapters?.forEach { ch ->
                        mathEntities.add(
                            ChapterProgressEntity(
                                id = "${subId}_ch_${ch.number}",
                                subjectId = subId,
                                chapterNumber = ch.number,
                                chapterTitle = ch.title,
                                isCompleted = false,
                                notes = ""
                            )
                        )
                    }
                }
                dao.insertInitialChapters(mathEntities)
            }

            // Ensure Physics (13), Chemistry (12), Biology (14) match exact updated titles without duplication
            val expectedPhyTitles = SscSyllabusData.getSubject("physics")?.chapters?.map { it.title }.orEmpty()
            val expectedChemTitles = SscSyllabusData.getSubject("chemistry")?.chapters?.map { it.title }.orEmpty()
            val expectedBioTitles = SscSyllabusData.getSubject("biology")?.chapters?.map { it.title }.orEmpty()

            val existingPhyTitles = existingChapters
                .filter { it.subjectId == "physics" }
                .sortedBy { it.chapterNumber }
                .map { it.chapterTitle }
            val existingChemTitles = existingChapters
                .filter { it.subjectId == "chemistry" }
                .sortedBy { it.chapterNumber }
                .map { it.chapterTitle }
            val existingBioTitles = existingChapters
                .filter { it.subjectId == "biology" }
                .sortedBy { it.chapterNumber }
                .map { it.chapterTitle }

            val scienceChaptersNeedReplace = existingPhyTitles != expectedPhyTitles ||
                existingChemTitles != expectedChemTitles ||
                existingBioTitles != expectedBioTitles
            if (scienceChaptersNeedReplace) {
                listOf("physics", "chemistry", "biology").forEach { dao.deleteChaptersForSubject(it) }
                val scienceEntities = mutableListOf<ChapterProgressEntity>()
                listOf("physics", "chemistry", "biology").forEach { subId ->
                    SscSyllabusData.getSubject(subId)?.chapters?.forEach { ch ->
                        scienceEntities.add(
                            ChapterProgressEntity(
                                id = "${subId}_ch_${ch.number}",
                                subjectId = subId,
                                chapterNumber = ch.number,
                                chapterTitle = ch.title,
                                isCompleted = false,
                                notes = ""
                            )
                        )
                    }
                }
                dao.insertInitialChapters(scienceEntities)
            }

            // Ensure BGS (14), Islam Education (5), ICT (7) match exact updated titles without duplication
            val expectedBgsTitles = SscSyllabusData.getSubject("bgs")?.chapters?.map { it.title }.orEmpty()
            val expectedIslamTitles = SscSyllabusData.getSubject("islam_moral")?.chapters?.map { it.title }.orEmpty()
            val expectedIctTitles = SscSyllabusData.getSubject("ict")?.chapters?.map { it.title }.orEmpty()

            val existingBgsTitles = existingChapters
                .filter { it.subjectId == "bgs" }
                .sortedBy { it.chapterNumber }
                .map { it.chapterTitle }
            val existingIslamTitles = existingChapters
                .filter { it.subjectId == "islam_moral" }
                .sortedBy { it.chapterNumber }
                .map { it.chapterTitle }
            val existingIctTitles = existingChapters
                .filter { it.subjectId == "ict" }
                .sortedBy { it.chapterNumber }
                .map { it.chapterTitle }

            val socialIctNeedReplace = existingBgsTitles != expectedBgsTitles ||
                existingIslamTitles != expectedIslamTitles ||
                existingIctTitles != expectedIctTitles
            if (socialIctNeedReplace) {
                listOf("bgs", "islam_moral", "ict").forEach { dao.deleteChaptersForSubject(it) }
                val socialIctEntities = mutableListOf<ChapterProgressEntity>()
                listOf("bgs", "islam_moral", "ict").forEach { subId ->
                    SscSyllabusData.getSubject(subId)?.chapters?.forEach { ch ->
                        socialIctEntities.add(
                            ChapterProgressEntity(
                                id = "${subId}_ch_${ch.number}",
                                subjectId = subId,
                                chapterNumber = ch.number,
                                chapterTitle = ch.title,
                                isCompleted = false,
                                notes = ""
                            )
                        )
                    }
                }
                dao.insertInitialChapters(socialIctEntities)
            }

            // Seed initial greeting message from MRH STUDY AI
            val existingChat = dao.getChatMessages().firstOrNull().orEmpty()
            if (existingChat.isEmpty()) {
                dao.insertChatMessage(
                    ChatMessageEntity(
                        id = "welcome_ai_msg",
                        sender = "ai",
                        messageText = "আসসালামু আলাইকুম! আমি তোমার SSC 2028 AI Study Coach — COMPLETE MRH 🚀\n\nআমাদের মূল লক্ষ্য: **SSC 2028 COMEBACK!**\n\nগণিত (৩১), বিজ্ঞান (৩৯) এবং বাংলাদেশ ও বিশ্বপরিচয় (১৪), ইসলাম শিক্ষা (৫) ও ICT (৭) সহ সকল বিষয়ের পূর্ণাঙ্গ গাইড, সৃজনশীল (CQ), MCQ ও অধ্যায়ভিত্তিক প্রস্তুতি নিতে আমাকে বাংলায় নির্দ্বিধায় প্রশ্ন করো!",
                        timestamp = System.currentTimeMillis()
                    )
                )
            }

            // Seed or refresh Future Study Plan if empty or containing stale chapter titles
            val existingConfig = dao.getActivePlanConfig().firstOrNull()
            val existingTasks = dao.getAllScheduledTasks().firstOrNull().orEmpty()
            val b1ScheduledCount = existingTasks.count { it.subjectId == "bangla_1" }
            val gmTitleSet = expectedGmTitles.toSet()
            val hmTitleSet = expectedHmTitles.toSet()
            val phyTitleSet = expectedPhyTitles.toSet()
            val chemTitleSet = expectedChemTitles.toSet()
            val bioTitleSet = expectedBioTitles.toSet()
            val bgsTitleSet = expectedBgsTitles.toSet()
            val islamTitleSet = expectedIslamTitles.toSet()
            val ictTitleSet = expectedIctTitles.toSet()
            val hasStaleMathTasks = existingTasks.any { task ->
                (task.subjectId == "general_math" && task.chapterTitle !in gmTitleSet) ||
                    (task.subjectId == "higher_math" && task.chapterTitle !in hmTitleSet)
            }
            val hasStaleScienceTasks = existingTasks.any { task ->
                (task.subjectId == "physics" && task.chapterTitle !in phyTitleSet) ||
                    (task.subjectId == "chemistry" && task.chapterTitle !in chemTitleSet) ||
                    (task.subjectId == "biology" && task.chapterTitle !in bioTitleSet)
            }
            val hasStaleSocialIctTasks = existingTasks.any { task ->
                (task.subjectId == "bgs" && task.chapterTitle !in bgsTitleSet) ||
                    (task.subjectId == "islam_moral" && task.chapterTitle !in islamTitleSet) ||
                    (task.subjectId == "ict" && task.chapterTitle !in ictTitleSet)
            }
            if (existingConfig == null || b1ScheduledCount < 40 || hasStaleMathTasks || hasStaleScienceTasks || hasStaleSocialIctTasks) {
                val months = existingConfig?.durationMonths ?: 4
                val hours = existingConfig?.dailyStudyHours ?: 4
                val (config, tasks) = StudyPlanGenerator.generateCompleteSchedule(
                    durationMonths = months,
                    dailyHours = hours,
                    startDateMillis = existingConfig?.startDateMillis ?: System.currentTimeMillis()
                )
                dao.clearAllScheduledTasks()
                dao.insertPlanConfig(config)
                dao.insertScheduledTasks(tasks)
            }

            // Seed today's goals
            val existingGoals = dao.getGoalsForDate(todayString).firstOrNull().orEmpty()
            if (existingGoals.isEmpty()) {
                val defaultGoals = listOf(
                    DailyGoalEntity(
                        id = "goal_math_${todayString}",
                        title = "গণিত: ৩য় অধ্যায়ের ৫টি বীজগাণিতিক মান নির্ণয় সমাধান",
                        targetMinutes = 45,
                        isCompleted = false,
                        dateString = todayString
                    ),
                    DailyGoalEntity(
                        id = "goal_phy_${todayString}",
                        title = "পদার্থবিজ্ঞান: গতির সমীকরণ ও গ্রাফ রিভিশন",
                        targetMinutes = 40,
                        isCompleted = false,
                        dateString = todayString
                    ),
                    DailyGoalEntity(
                        id = "goal_eng_${todayString}",
                        title = "ইংরেজি ২য়: Right Form of Verbs-এর ৫টি নিয়ম",
                        targetMinutes = 30,
                        isCompleted = false,
                        dateString = todayString
                    )
                )
                defaultGoals.forEach { dao.insertGoal(it) }
            }
        }
    }

    // --- Future Study Plan Generator Actions ---
    fun generateNewStudyPlan(
        durationMonths: Int,
        dailyHours: Int,
        startDateMillis: Long,
        easyDays: Int = 1,
        normalDays: Int = 2,
        difficultDays: Int = 3,
        veryDifficultDays: Int = 5
    ) {
        viewModelScope.launch {
            val (config, tasks) = StudyPlanGenerator.generateCompleteSchedule(
                durationMonths = durationMonths,
                dailyHours = dailyHours,
                startDateMillis = startDateMillis,
                easyDays = easyDays,
                normalDays = normalDays,
                difficultDays = difficultDays,
                veryDifficultDays = veryDifficultDays
            )
            dao.clearAllScheduledTasks()
            dao.insertPlanConfig(config)
            dao.insertScheduledTasks(tasks)
        }
    }

    // --- Feature 3: 8-Phase Study System Checklists ---
    fun toggleTaskStep(task: ScheduledTaskEntity, stepIndex: Int) {
        viewModelScope.launch {
            var textbook = task.textbookRead
            var concept = task.conceptUnderstood
            var notes = task.notesCreated
            var mcq = task.mcqPracticeCompleted
            var cq = task.cqPracticeCompleted
            var board = task.boardQuestionsSolved
            var test = task.chapterTestCompleted
            var mistakes = task.mistakesReviewed

            when (stepIndex) {
                1 -> textbook = !textbook
                2 -> concept = !concept
                3 -> notes = !notes
                4 -> mcq = !mcq
                5 -> cq = !cq
                6 -> board = !board
                7 -> test = !test
                8 -> mistakes = !mistakes
            }

            val allCompleted = textbook && concept && notes && mcq && cq && board && test && mistakes

            dao.updateTaskPhases(
                id = task.id,
                textbookRead = textbook,
                conceptUnderstood = concept,
                notesCreated = notes,
                mcqCompleted = mcq,
                cqCompleted = cq,
                boardSolved = board,
                testCompleted = test,
                mistakesReviewed = mistakes,
                isCompleted = allCompleted
            )

            // If chapter completed, also update chapter_progress entity
            if (allCompleted && task.subjectId.isNotBlank()) {
                val chapterId = "${task.subjectId}_ch_${task.chapterNumber}"
                dao.updateChapterCompletion(chapterId, true)
            }
        }
    }

    fun updateTaskTimeAllocations(
        taskId: String,
        textbook: Int,
        mcq: Int,
        cq: Int,
        board: Int,
        revision: Int
    ) {
        viewModelScope.launch {
            dao.updateTaskPhaseTimes(taskId, textbook, mcq, cq, board, revision)
        }
    }

    // --- Feature 4: Custom Time Extension ---
    fun extendChapterTime(chapterTitle: String, extraDays: Int) {
        viewModelScope.launch {
            val currentConfig = activePlanConfig.value ?: return@launch
            val tasks = allScheduledTasks.value
            val (updatedConfig, updatedTasks) = StudyPlanGenerator.extendChapterTasks(
                targetChapterTitle = chapterTitle,
                extraDays = extraDays,
                allTasks = tasks,
                currentConfig = currentConfig
            )
            dao.updatePlanConfig(updatedConfig)
            dao.clearAllScheduledTasks()
            dao.insertScheduledTasks(updatedTasks)
        }
    }

    // --- Feature 5: Missed Study Recovery ---
    fun recoverAllMissedTasks() {
        viewModelScope.launch {
            val tasks = allScheduledTasks.value
            val recoveredTasks = StudyPlanGenerator.recoverMissedTasks(tasks)
            dao.clearAllScheduledTasks()
            dao.insertScheduledTasks(recoveredTasks)
        }
    }

    fun markTaskRecovered(taskId: String) {
        viewModelScope.launch {
            dao.markTaskRecovered(taskId)
        }
    }

    fun toggleTaskCompleteDirectly(taskId: String, currentStatus: Boolean) {
        viewModelScope.launch {
            dao.updateTaskCompletion(taskId, !currentStatus)
        }
    }

    // --- Syllabus Actions ---
    fun toggleChapterCompletion(chapterId: String, currentStatus: Boolean) {
        viewModelScope.launch {
            dao.updateChapterCompletion(chapterId, !currentStatus)
        }
    }

    fun saveChapterNote(chapterId: String, note: String) {
        viewModelScope.launch {
            dao.updateChapterNotes(chapterId, note)
        }
    }

    /**
     * Resets completion progress for all 31 Mathematics chapters while preserving personal notes
     */
    fun resetMathProgress() {
        viewModelScope.launch {
            dao.resetSubjectCompletion("general_math")
            dao.resetSubjectCompletion("higher_math")
        }
    }

    /**
     * Resets completion progress for Science chapters (all 39 or a specific subject) while preserving personal notes
     */
    fun resetScienceProgress(subjectId: String? = null) {
        viewModelScope.launch {
            if (subjectId in listOf("physics", "chemistry", "biology")) {
                dao.resetSubjectCompletion(subjectId!!)
            } else {
                dao.resetSubjectCompletion("physics")
                dao.resetSubjectCompletion("chemistry")
                dao.resetSubjectCompletion("biology")
            }
        }
    }

    /**
     * Resets completion progress for BGS, Islam Education, and ICT chapters (all 26 or a specific subject) while preserving personal notes
     */
    fun resetSocialIctProgress(subjectId: String? = null) {
        viewModelScope.launch {
            if (subjectId in listOf("bgs", "islam_moral", "ict")) {
                dao.resetSubjectCompletion(subjectId!!)
            } else {
                dao.resetSubjectCompletion("bgs")
                dao.resetSubjectCompletion("islam_moral")
                dao.resetSubjectCompletion("ict")
            }
        }
    }

    // --- Study Timer Actions ---
    fun selectTimerSubject(subject: String) {
        _selectedTimerSubject.value = subject
    }

    fun setTimerDurationMinutes(minutes: Int) {
        if (!_timerIsRunning.value) {
            _timerRemainingSeconds.value = minutes * 60
        }
    }

    fun startTimer() {
        if (_timerIsRunning.value) return
        _timerIsRunning.value = true
        timerJob = viewModelScope.launch {
            while (_timerRemainingSeconds.value > 0 && _timerIsRunning.value) {
                delay(1000L)
                _timerRemainingSeconds.value -= 1
            }
            if (_timerRemainingSeconds.value <= 0) {
                _timerIsRunning.value = false
                dao.insertStudySession(
                    StudySessionEntity(
                        subjectName = _selectedTimerSubject.value,
                        durationMinutes = 25
                    )
                )
                _timerRemainingSeconds.value = 25 * 60
            }
        }
    }

    fun pauseTimer() {
        _timerIsRunning.value = false
        timerJob?.cancel()
    }

    fun resetTimer(minutes: Int = 25) {
        pauseTimer()
        _timerRemainingSeconds.value = minutes * 60
    }

    // --- Daily Goal Actions ---
    fun toggleGoal(goalId: String, currentStatus: Boolean) {
        viewModelScope.launch {
            dao.toggleGoalCompletion(goalId, !currentStatus)
        }
    }

    fun addNewGoal(title: String, targetMinutes: Int) {
        viewModelScope.launch {
            dao.insertGoal(
                DailyGoalEntity(
                    title = title,
                    targetMinutes = targetMinutes,
                    isCompleted = false,
                    dateString = todayString
                )
            )
        }
    }

    fun deleteGoal(goalId: String) {
        viewModelScope.launch {
            dao.deleteGoal(goalId)
        }
    }

    // --- AI Chat Actions ---
    fun sendChatMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank() || _isAiStreaming.value) return

        viewModelScope.launch {
            // Snapshot prior valid messages before inserting the new one
            val priorHistory = chatMessages.value
                .filter { !it.isError && it.messageText.isNotBlank() }
                .map { it.sender to it.messageText }

            val userMsg = ChatMessageEntity(
                sender = "user",
                messageText = trimmed,
                timestamp = System.currentTimeMillis()
            )
            dao.insertChatMessage(userMsg)

            _isAiStreaming.value = true
            _aiError.value = null
            _currentStreamingChunk.value = ""

            val accumulated = StringBuilder()

            try {
                aiRepository.streamChatResponse(trimmed, priorHistory).collect { chunk ->
                    accumulated.append(chunk)
                    _currentStreamingChunk.value = accumulated.toString()
                }

                val fullResponse = accumulated.toString().trim()
                if (fullResponse.isNotEmpty()) {
                    val aiMsg = ChatMessageEntity(
                        sender = "ai",
                        messageText = fullResponse,
                        timestamp = System.currentTimeMillis()
                    )
                    dao.insertChatMessage(aiMsg)
                }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException && e !is kotlinx.coroutines.TimeoutCancellationException) {
                    throw e
                }
                val partial = accumulated.toString().trim()
                if (partial.isNotEmpty()) {
                    dao.insertChatMessage(
                        ChatMessageEntity(
                            sender = "ai",
                            messageText = partial,
                            timestamp = System.currentTimeMillis()
                        )
                    )
                } else {
                    val errorMsg = if (e is kotlinx.coroutines.TimeoutCancellationException) {
                        "ইন্টারনেট সংযোগের কারণে উত্তর আসতে বিলম্ব হচ্ছে। পুনরায় চেষ্টা করুন।"
                    } else {
                        e.localizedMessage ?: "AI সংযোগে ত্রুটি ঘটেছে।"
                    }
                    _aiError.value = errorMsg
                    dao.insertChatMessage(
                        ChatMessageEntity(
                            sender = "ai",
                            messageText = "দুঃখিত: $errorMsg। পুনরায় চেষ্টা বাটনে ট্যাপ করুন।",
                            timestamp = System.currentTimeMillis(),
                            isError = true
                        )
                    )
                }
            } finally {
                _isAiStreaming.value = false
                _currentStreamingChunk.value = ""
            }
        }
    }

    fun retryLastMessage() {
        val lastUserMsg = chatMessages.value.lastOrNull { it.sender == "user" }?.messageText
        if (!lastUserMsg.isNullOrBlank()) {
            _aiError.value = null
            sendChatMessage(lastUserMsg)
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            dao.clearChatHistory()
            dao.insertChatMessage(
                ChatMessageEntity(
                    id = UUID.randomUUID().toString(),
                    sender = "ai",
                    messageText = "নতুন সেশন শুরু হয়েছে! SSC 2028-এর কোন টপিকটি আজ আলোচনা করতে চাও?",
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    // --- Quick AI Explanation Modal ---
    fun requestQuickExplanation(title: String, prompt: String) {
        _quickExplainTitle.value = title
        _quickExplainContent.value = null
        _isQuickExplainLoading.value = true

        viewModelScope.launch {
            when (val result = aiRepository.getQuickExplanation(prompt)) {
                is AiResult.Success -> {
                    _quickExplainContent.value = result.text
                    _isQuickExplainLoading.value = false
                }
                is AiResult.Error -> {
                    _quickExplainContent.value = "ত্রুটি: ${result.message}"
                    _isQuickExplainLoading.value = false
                }
                is AiResult.Loading -> {}
            }
        }
    }

    fun closeQuickExplanation() {
        _quickExplainTitle.value = null
        _quickExplainContent.value = null
        _isQuickExplainLoading.value = false
    }

    // --- Exam & Practice Actions ---
    fun startExam(questions: List<BoardMcqQuestion>, durationMinutes: Int = 10) {
        _examQuestions.value = questions
        _examUserAnswers.value = emptyMap()
        _examTimeRemaining.value = durationMinutes * 60
        _examSubmitted.value = false
        _lastExamScore.value = null
        _isExamActive.value = true

        examTimerJob?.cancel()
        examTimerJob = viewModelScope.launch {
            while (_examTimeRemaining.value > 0 && _isExamActive.value && !_examSubmitted.value) {
                delay(1000L)
                _examTimeRemaining.value -= 1
            }
            if (_examTimeRemaining.value <= 0 && !_examSubmitted.value) {
                submitExam()
            }
        }
    }

    fun answerExamQuestion(questionIndex: Int, optionIndex: Int) {
        if (_examSubmitted.value) return
        val current = _examUserAnswers.value.toMutableMap()
        current[questionIndex] = optionIndex
        _examUserAnswers.value = current
    }

    fun submitExam() {
        examTimerJob?.cancel()
        _examSubmitted.value = true
        var correctCount = 0
        val questions = _examQuestions.value
        val answers = _examUserAnswers.value
        val weakTopics = mutableListOf<String>()

        questions.forEachIndexed { index, question ->
            val selected = answers[index]
            if (selected == question.correctIndex) {
                correctCount++
            } else {
                weakTopics.add(question.chapterName)
                viewModelScope.launch {
                    dao.insertMistake(
                        MistakeEntity(
                            subjectName = question.subjectName,
                            chapterTitle = question.chapterName,
                            questionText = question.question,
                            studentAnswer = if (selected != null && selected in question.options.indices) question.options[selected] else "উত্তর দেওয়া হয়নি",
                            correctAnswer = question.options[question.correctIndex],
                            explanation = question.explanation
                        )
                    )
                }
            }
        }

        _lastExamScore.value = correctCount to questions.size
        val accuracy = if (questions.isNotEmpty()) (correctCount.toFloat() / questions.size) * 100f else 0f

        viewModelScope.launch {
            dao.insertExamResult(
                ExamResultEntity(
                    examTitle = "বোর্ড প্র্যাকটিস মডেল টেস্ট",
                    subjectName = questions.firstOrNull()?.subjectName ?: "সাধারণ বিষয়",
                    score = correctCount,
                    totalQuestions = questions.size,
                    accuracyPercentage = accuracy,
                    weakTopics = weakTopics.distinct().joinToString(", ")
                )
            )
        }
    }

    fun closeExam() {
        examTimerJob?.cancel()
        _isExamActive.value = false
        _examQuestions.value = emptyList()
        _examUserAnswers.value = emptyMap()
    }

    // --- Mistakes Notebook Actions ---
    fun toggleMistakeResolved(id: String, currentResolved: Boolean) {
        viewModelScope.launch {
            dao.updateMistakeStatus(id, !currentResolved)
        }
    }

    fun deleteMistake(id: String) {
        viewModelScope.launch {
            dao.deleteMistake(id)
        }
    }

    fun recordQuizMistake(
        subjectName: String,
        chapterTitle: String,
        question: String,
        studentAnswer: String,
        correctAnswer: String,
        explanation: String
    ) {
        viewModelScope.launch {
            dao.insertMistake(
                MistakeEntity(
                    subjectName = subjectName,
                    chapterTitle = chapterTitle,
                    questionText = question,
                    studentAnswer = studentAnswer,
                    correctAnswer = correctAnswer,
                    explanation = explanation
                )
            )
        }
    }
}
