package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MistakeEntity
import com.example.data.model.BoardMcqQuestion
import com.example.data.model.BoardQuestionsData
import com.example.data.model.CreativeQuestion
import com.example.ui.components.CyberCard
import com.example.ui.components.QuickExplanationDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyberGradient
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MainViewModel

@Composable
fun PracticeExamScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("বোর্ড প্রশ্ন ব্যাংক", "মডেল টেস্ট এক্সাম", "ভুল প্রশ্নের খাতা")

    val quickExplainTitle by viewModel.quickExplainTitle.collectAsState()
    val quickExplainContent by viewModel.quickExplainContent.collectAsState()
    val isQuickExplainLoading by viewModel.isQuickExplainLoading.collectAsState()

    val isExamActive by viewModel.isExamActive.collectAsState()
    val examQuestions by viewModel.examQuestions.collectAsState()
    val examUserAnswers by viewModel.examUserAnswers.collectAsState()
    val examTimeRemaining by viewModel.examTimeRemaining.collectAsState()
    val examSubmitted by viewModel.examSubmitted.collectAsState()
    val lastScore by viewModel.lastExamScore.collectAsState()
    val mistakesList by viewModel.mistakes.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurface,
            contentColor = NeonCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = NeonCyan
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) NeonCyan else TextSecondary
                        )
                    }
                )
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            when (selectedTab) {
                0 -> BoardQuestionBankTab(
                    onAskAi = { title, prompt ->
                        viewModel.requestQuickExplanation(title, prompt)
                    }
                )
                1 -> ModelTestExamTab(
                    isExamActive = isExamActive,
                    questions = examQuestions,
                    userAnswers = examUserAnswers,
                    timeRemaining = examTimeRemaining,
                    isSubmitted = examSubmitted,
                    lastScore = lastScore,
                    onStartExam = {
                        viewModel.startExam(BoardQuestionsData.sampleMcqs, durationMinutes = 10)
                    },
                    onSelectAnswer = { qIdx, optIdx ->
                        viewModel.answerExamQuestion(qIdx, optIdx)
                    },
                    onSubmitExam = { viewModel.submitExam() },
                    onCloseExam = { viewModel.closeExam() }
                )
                2 -> MistakesNotebookTab(
                    mistakes = mistakesList,
                    onToggleResolved = { id, current -> viewModel.toggleMistakeResolved(id, current) },
                    onDelete = { id -> viewModel.deleteMistake(id) },
                    onAskAi = { title, prompt -> viewModel.requestQuickExplanation(title, prompt) }
                )
            }
        }
    }

    // Quick AI Explanation Dialog
    QuickExplanationDialog(
        title = quickExplainTitle,
        content = quickExplainContent,
        isLoading = isQuickExplainLoading,
        onDismiss = { viewModel.closeQuickExplanation() }
    )
}

@Composable
fun BoardQuestionBankTab(
    onAskAi: (String, String) -> Unit
) {
    val selectedOptions = remember { mutableStateMapOf<String, Int>() }
    var showCqStimulus by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "বোর্ড স্ট্যান্ডার্ড MCQ ও সৃজনশীল প্র্যাকটিস",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "সরাসরি বিগত বছরের শীর্ষ বোর্ড প্রশ্ন ও ইনস্ট্যান্ট সমাধান",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        // MCQ Questions List
        items(BoardQuestionsData.sampleMcqs) { mcq ->
            val selectedIndex = selectedOptions[mcq.id]
            val isAnswered = selectedIndex != null

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF162032))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = mcq.boardTag,
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "${mcq.subjectName} • ${mcq.chapterName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = mcq.question,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Options
                    mcq.options.forEachIndexed { optIndex, optionText ->
                        val isSelected = selectedIndex == optIndex
                        val isCorrect = optIndex == mcq.correctIndex

                        val containerColor = when {
                            !isAnswered -> DarkSurfaceVariant
                            isSelected && isCorrect -> Color(0xFF064E3B)
                            isSelected && !isCorrect -> Color(0xFF4C0519)
                            isAnswered && isCorrect -> Color(0xFF064E3B)
                            else -> DarkSurfaceVariant
                        }

                        val borderColor = when {
                            !isAnswered -> BorderGlow
                            isCorrect -> EmeraldSuccess
                            isSelected -> NeonPink
                            else -> BorderGlow
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(containerColor)
                                .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                                .clickable {
                                    if (!isAnswered) {
                                        selectedOptions[mcq.id] = optIndex
                                    }
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val optionLabel = listOf("ক", "খ", "গ", "ঘ").getOrElse(optIndex) { "${optIndex + 1}" }
                            Text(
                                text = "($optionLabel)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isAnswered && isCorrect) EmeraldSuccess else TextSecondary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = optionText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Explanation Box
                    if (isAnswered) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0C1322))
                                .border(1.dp, BorderGlow, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(
                                    text = "💡 সঠিক উত্তর ব্যাখ্যা:",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = mcq.explanation,
                                    style = MaterialTheme.typography.bodySmall,
                                    lineHeight = 20.sp,
                                    color = TextPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = {
                                onAskAi(
                                    "MCQ ব্যাখ্যা: ${mcq.question}",
                                    "প্রশ্ন: ${mcq.question}\nঅপশনসমূহ: ${mcq.options.joinToString(", ")}\nসঠিক উত্তর: ${mcq.options[mcq.correctIndex]}\n\nএই প্রশ্নের পদার্থ/গণিত/বিজ্ঞানের মূল সূত্রটি বাংলায় বিস্তারিত বুঝিয়ে দিন এবং এই ধরণের অন্যান্য প্রশ্নে যাতে ভুল না হয় সেই টেকনিক শেখান।"
                                )
                            }
                        ) {
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "AI", tint = NeonCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("MRH AI দিয়ে বুঝিয়ে দাও", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                        }
                    }
                }
            }
        }

        // Creative Question (CQ) Section
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "বোর্ড সৃজনশীল প্রশ্ন (CQ) অনুশীলন",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        items(BoardQuestionsData.sampleCreativeQuestions) { cq ->
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${cq.subjectName} • ${cq.boardTag}",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonPurple,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = cq.chapterName, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    // Stimulus
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF131D2E))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "উদ্দীপক: ${cq.stimulus}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    var expandKa by remember { mutableStateOf(false) }
                    var expandKha by remember { mutableStateOf(false) }
                    var expandGa by remember { mutableStateOf(false) }
                    var expandGha by remember { mutableStateOf(false) }

                    CqItemPart(label = "ক. ${cq.questionKa} (১ নম্বর)", answer = cq.answerKa, isExpanded = expandKa, onToggle = { expandKa = !expandKa })
                    Spacer(modifier = Modifier.height(6.dp))
                    CqItemPart(label = "খ. ${cq.questionKha} (২ নম্বর)", answer = cq.answerKha, isExpanded = expandKha, onToggle = { expandKha = !expandKha })
                    Spacer(modifier = Modifier.height(6.dp))
                    CqItemPart(label = "গ. ${cq.questionGa} (৩ নম্বর)", answer = cq.answerGa, isExpanded = expandGa, onToggle = { expandGa = !expandGa })
                    Spacer(modifier = Modifier.height(6.dp))
                    CqItemPart(label = "ঘ. ${cq.questionGha} (৪ নম্বর)", answer = cq.answerGha, isExpanded = expandGha, onToggle = { expandGha = !expandGha })
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun CqItemPart(
    label: String,
    answer: String,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceVariant)
            .clickable(onClick = onToggle)
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = NeonCyan,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = "Toggle",
                tint = TextSecondary
            )
        }
        AnimatedVisibility(visible = isExpanded) {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                Text(
                    text = answer,
                    style = MaterialTheme.typography.bodySmall,
                    lineHeight = 21.sp,
                    color = TextPrimary
                )
            }
        }
    }
}

@Composable
fun ModelTestExamTab(
    isExamActive: Boolean,
    questions: List<BoardMcqQuestion>,
    userAnswers: Map<Int, Int>,
    timeRemaining: Int,
    isSubmitted: Boolean,
    lastScore: Pair<Int, Int>?,
    onStartExam: () -> Unit,
    onSelectAnswer: (Int, Int) -> Unit,
    onSubmitExam: () -> Unit,
    onCloseExam: () -> Unit
) {
    if (!isExamActive) {
        // Exam Start Landing
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CyberCard(
                borderBrush = CyberGradient,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "🏆 এসএসসি ২০২৮ সাপ্তাহিক মডেল টেস্ট",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• মোট প্রশ্ন: ৮টি বোর্ড স্ট্যান্ডার্ড MCQ\n• সময়: ১০ মিনিট\n• নেগেটিভ মার্কিং নেই\n• ফলাফল বিশ্লেষণ ও দুর্বল অধ্যায় চিহ্নিতকরণ স্বয়ংক্রিয়ভাবে হবে।",
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onStartExam,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("start_model_test_button")
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Start", tint = Color(0xFF031A24))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("পরীক্ষা শুরু করো", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (lastScore != null) {
                Spacer(modifier = Modifier.height(16.dp))
                val (correct, total) = lastScore
                val percent = if (total > 0) (correct * 100) / total else 0

                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "সর্বশেষ পরীক্ষার ফলাফল", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "$correct / $total ($percent%)",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (percent >= 70) EmeraldSuccess else NeonPink
                        )
                        Text(
                            text = if (percent >= 80) "দারুণ প্রস্তুতি! এগিয়ে চলো।" else "দুর্বল অধ্যায়গুলো আবার রিভিশন করো।",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    } else {
        // Active Timed Exam
        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(8.dp))
            // Countdown Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF162032))
                    .border(1.dp, if (timeRemaining < 120) NeonPink else NeonCyan, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = "Timer",
                        tint = if (timeRemaining < 120) NeonPink else NeonCyan
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val mins = timeRemaining / 60
                    val secs = timeRemaining % 60
                    Text(
                        text = String.format("বাকি সময়: %02d:%02d", mins, secs),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (timeRemaining < 120) NeonPink else TextPrimary
                    )
                }

                if (!isSubmitted) {
                    Button(
                        onClick = onSubmitExam,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("জমা দাও", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = onCloseExam,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("শেষ করো", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Questions List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(questions.size) { index ->
                    val question = questions[index]
                    val selected = userAnswers[index]

                    CyberCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "প্রশ্ন ${index + 1}: ${question.question}",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            question.options.forEachIndexed { optIndex, option ->
                                val isOptionSelected = selected == optIndex
                                val isCorrectOption = optIndex == question.correctIndex

                                val bgColor = when {
                                    !isSubmitted -> if (isOptionSelected) Color(0xFF083344) else DarkSurfaceVariant
                                    isSubmitted && isCorrectOption -> Color(0xFF064E3B)
                                    isSubmitted && isOptionSelected && !isCorrectOption -> Color(0xFF4C0519)
                                    else -> DarkSurfaceVariant
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(bgColor)
                                        .border(
                                            1.dp,
                                            if (isOptionSelected) NeonCyan else BorderGlow,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable(enabled = !isSubmitted) {
                                            onSelectAnswer(index, optIndex)
                                        }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${optIndex + 1}.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = option,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun MistakesNotebookTab(
    mistakes: List<MistakeEntity>,
    onToggleResolved: (String, Boolean) -> Unit,
    onDelete: (String) -> Unit,
    onAskAi: (String, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "ভুল প্রশ্নের খাতা (Mistakes Notebook)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "পরীক্ষায় ভুল করা প্রশ্নগুলো এখানে জমা হয়। রিভিশন করে দুর্বলতা দূর করুন।",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        if (mistakes.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "None", tint = EmeraldSuccess, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("এখনো কোনো ভুল প্রশ্ন নেই! খুব ভালো!", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    }
                }
            }
        } else {
            items(mistakes) { mistake ->
                CyberCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${mistake.subjectName} • ${mistake.chapterTitle}",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonPurple,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { onDelete(mistake.id) }, modifier = Modifier.size(24.dp)) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = TextTertiary, modifier = Modifier.size(16.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = mistake.questionText,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(text = "❌ তোমার উত্তর: ", style = MaterialTheme.typography.bodySmall, color = NeonPink)
                            Text(text = mistake.studentAnswer, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        }
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(text = "✓ সঠিক উত্তর: ", style = MaterialTheme.typography.bodySmall, color = EmeraldSuccess)
                            Text(text = mistake.correctAnswer, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        }

                        if (mistake.explanation.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "ব্যাখ্যা: ${mistake.explanation}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = { onToggleResolved(mistake.id, mistake.isResolved) }
                            ) {
                                Icon(
                                    imageVector = if (mistake.isResolved) Icons.Default.CheckCircle else Icons.Default.Check,
                                    contentDescription = "Resolve",
                                    tint = if (mistake.isResolved) EmeraldSuccess else TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (mistake.isResolved) "সমাধান সম্পন্ন" else "সমাধান চিহ্নিত করো",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (mistake.isResolved) EmeraldSuccess else TextSecondary
                                )
                            }

                            TextButton(
                                onClick = {
                                    onAskAi(
                                        "ভুল সংশোধন: ${mistake.questionText}",
                                        "আমি এই প্রশ্নে ভুল উত্তর দিয়েছিলাম:\nপ্রশ্ন: ${mistake.questionText}\nআমার ভুল উত্তর: ${mistake.studentAnswer}\nসঠিক উত্তর: ${mistake.correctAnswer}\n\nদয়া করে এই টপিকটির কনসেপ্ট সহজ বাংলায় বুঝিয়ে দিন যাতে পরবর্তী পরীক্ষায় আর কোনো ভুল না হয়।"
                                    )
                                }
                            ) {
                                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "AI", tint = NeonCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("MRH AI সমাধান", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
