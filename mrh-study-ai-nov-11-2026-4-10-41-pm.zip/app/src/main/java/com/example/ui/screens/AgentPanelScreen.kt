package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.McqQuestionRecord
import com.example.data.model.RemoteUiState
import com.example.data.model.SscSyllabusData
import com.example.ui.components.CyberCard
import com.example.ui.components.TextbookMathFormatter
import com.example.ui.theme.AmberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AgentViewModel

@Composable
fun AgentPanelScreen(
    agentViewModel: AgentViewModel,
    onSwitchAccount: () -> Unit = {},
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val myAccountState by agentViewModel.myAgentAccount.collectAsStateWithLifecycle()
    val isAuthorized by agentViewModel.isAuthorizedAgent.collectAsStateWithLifecycle()
    val agentMcqsState by agentViewModel.agentMcqs.collectAsStateWithLifecycle()
    val pendingMcqs by agentViewModel.pendingReviewMcqs.collectAsStateWithLifecycle()
    val agentQuizzesState by agentViewModel.agentQuizzes.collectAsStateWithLifecycle()
    val agentUploadsState by agentViewModel.agentUploads.collectAsStateWithLifecycle()
    val allAgentsState by agentViewModel.allAgents.collectAsStateWithLifecycle()
    val actionStatus by agentViewModel.actionStatus.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 860.dp)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("agent_panel_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ফিরে যান",
                            tint = NeonCyan
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "এজেন্ট প্যানেল • MRH",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        val accountHandle = (myAccountState as? RemoteUiState.Success)?.data?.username
                            ?: if (agentViewModel.isBootstrappedAdmin) "Mr1122 (Primary)" else "RBAC Verification"
                        Text(
                            text = "$accountHandle • ${agentViewModel.currentUserEmail}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isAuthorized) EmeraldSuccess else AmberGold
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Agent Role",
                    tint = if (isAuthorized) EmeraldSuccess else NeonPurple,
                    modifier = Modifier.size(26.dp)
                )
            }

            if (actionStatus.isBusy) {
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = NeonCyan,
                    trackColor = DarkSurfaceVariant
                )
                Text(
                    text = actionStatus.busyLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = NeonCyan,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (!actionStatus.message.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (actionStatus.isError) Color(0xFF33101A) else Color(0xFF0A2E25)
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (actionStatus.isError) NeonPink else EmeraldSuccess
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = actionStatus.message ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { agentViewModel.clearStatusMessage() }) {
                            Text("ঠিক আছে", color = NeonCyan, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Role-Based Access Gate
            if (myAccountState is RemoteUiState.Loading && !agentViewModel.isBootstrappedAdmin) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = NeonCyan)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("এজেন্ট অনুমতি যাচাই করা হচ্ছে...", color = TextSecondary)
                    }
                }
                return@Column
            }

            if (!isAuthorized) {
                AgentUnauthorizedGate(
                    userEmail = agentViewModel.currentUserEmail,
                    userUid = agentViewModel.currentUserId,
                    onCopyUid = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Agent UID", agentViewModel.currentUserId))
                    },
                    onSwitchAccount = onSwitchAccount,
                    onBack = onBack
                )
                return@Column
            }

            // Authorized Agent Tabs
            val tabTitles = listOf(
                "ম্যানুয়াল / বই MCQ",
                "ছবি / PDF OCR",
                "রিভিউ কিউ (${pendingMcqs.size})",
                "কুইজ বিল্ডার ও রোল"
            )
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = DarkSurface,
                contentColor = NeonCyan,
                edgePadding = 4.dp
            ) {
                tabTitles.forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedTabIndex == idx,
                        onClick = { selectedTabIndex = idx },
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("agent_tab_$idx"),
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == idx) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedTabIndex == idx) NeonCyan else TextSecondary
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val allMcqs = (agentMcqsState as? RemoteUiState.Success)?.data.orEmpty()
            val reviewedMcqs = allMcqs.filter { it.ocrReviewed && it.status != "pending_review" }
            val allQuizzes = (agentQuizzesState as? RemoteUiState.Success)?.data.orEmpty()
            val allUploads = (agentUploadsState as? RemoteUiState.Success)?.data.orEmpty()
            val allAgents = (allAgentsState as? RemoteUiState.Success)?.data.orEmpty()

            Box(modifier = Modifier.weight(1f)) {
                when (selectedTabIndex) {
                    0 -> ManualBookMcqTab(
                        reviewedMcqs = reviewedMcqs,
                        isBusy = actionStatus.isBusy,
                        onSaveMcq = { editId, subId, chNum, q, a, b, c, d, corr, exp, diff, src, pub, onDone ->
                            agentViewModel.saveManualOrBookMcq(
                                editingMcqId = editId,
                                subjectId = subId,
                                chapterNumber = chNum,
                                question = q,
                                optionA = a,
                                optionB = b,
                                optionC = c,
                                optionD = d,
                                correctIndex = corr,
                                explanation = exp,
                                difficulty = diff,
                                sourceType = src,
                                publishNow = pub,
                                onComplete = onDone
                            )
                        },
                        onDeleteMcq = { agentViewModel.deleteMcq(it) }
                    )

                    1 -> AgentOcrUploadTab(
                        uploads = allUploads,
                        isBusy = actionStatus.isBusy,
                        onUploadImage = { uri, subId, chNum ->
                            agentViewModel.processImageUpload(uri, subId, chNum)
                        },
                        onUploadPdf = { uri, subId, chNum ->
                            agentViewModel.processPdfUpload(uri, subId, chNum)
                        }
                    )

                    2 -> AgentReviewQueueTab(
                        pendingMcqs = pendingMcqs,
                        isBusy = actionStatus.isBusy,
                        onApproveAndSave = { orig, subId, chNum, q, opts, corr, exp, diff, pub ->
                            agentViewModel.approveOcrMcq(orig, subId, chNum, q, opts, corr, exp, diff, pub)
                        },
                        onDeletePending = { agentViewModel.deleteMcq(it) }
                    )

                    3 -> AgentQuizBuilderTab(
                        reviewedMcqs = reviewedMcqs,
                        quizzes = allQuizzes,
                        agents = allAgents,
                        isBootstrappedAdmin = agentViewModel.isBootstrappedAdmin,
                        isBusy = actionStatus.isBusy,
                        onSaveQuiz = { editId, t, desc, subId, chNum, type, diff, dur, ids, pub, onDone ->
                            agentViewModel.saveQuizCollection(
                                editingQuizId = editId,
                                title = t,
                                description = desc,
                                subjectId = subId,
                                chapterNumber = chNum,
                                quizType = type,
                                difficulty = diff,
                                durationMinutes = dur,
                                selectedMcqIds = ids,
                                publishNow = pub,
                                onComplete = onDone
                            )
                        },
                        onToggleQuizPublish = { agentViewModel.toggleQuizPublishStatus(it) },
                        onDeleteQuiz = { agentViewModel.deleteQuiz(it) },
                        onUpsertAgent = { uid, user, name, email, active ->
                            agentViewModel.upsertAgentRole(uid, user, name, email, active)
                        },
                        onDeleteAgent = { agentViewModel.deleteAgentRole(it) }
                    )
                }
            }
        }
    }
}

@Composable
private fun AgentUnauthorizedGate(
    userEmail: String,
    userUid: String,
    onCopyUid: () -> Unit,
    onSwitchAccount: () -> Unit,
    onBack: () -> Unit
) {
    var copiedNotice by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        CyberCard(
            borderBrush = Brush.horizontalGradient(listOf(NeonPink, NeonPurple)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Restricted Agent Access",
                    tint = NeonPink,
                    modifier = Modifier.size(44.dp)
                )
                Text(
                    text = "এজেন্ট প্যানেল সংরক্ষিত (Role-Based Access)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "নিরাপত্তার জন্য এজেন্ট পাসওয়ার্ড APK-তে রাখা হয় না। শুধুমাত্র অনুমোদিত Firebase এজেন্ট অ্যাকাউন্ট ('Mr1122' প্রোফাইল) দিয়েই এখানে প্রবেশ করা যায়।",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 19.sp
                )
                Text(
                    text = "বর্তমান অ্যাকাউন্ট: $userEmail\nUID: $userUid",
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonCyan
                )
                OutlinedButton(
                    onClick = {
                        onCopyUid()
                        copiedNotice = true
                    },
                    border = BorderStroke(1.dp, NeonCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("copy_agent_uid_button")
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy UID", tint = NeonCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (copiedNotice) "UID কপি হয়েছে!" else "আপনার Agent UID কপি করুন",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
                Button(
                    onClick = onSwitchAccount,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("switch_admin_account_button")
                ) {
                    Text("অ্যাডমিন Google অ্যাকাউন্টে সুইচ করুন", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                ) {
                    Text("ড্যাশবোর্ডে ফিরে যান", color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ManualBookMcqTab(
    reviewedMcqs: List<McqQuestionRecord>,
    isBusy: Boolean,
    onSaveMcq: (
        editId: String?,
        subjectId: String,
        chapterNumber: Int,
        question: String,
        optA: String,
        optB: String,
        optC: String,
        optD: String,
        correctIndex: Int,
        explanation: String,
        difficulty: String,
        sourceType: String,
        publishNow: Boolean,
        onDone: () -> Unit
    ) -> Unit,
    onDeleteMcq: (String) -> Unit
) {
    var editingId by remember { mutableStateOf<String?>(null) }
    var subjectId by remember { mutableStateOf("general_math") }
    var chapterNum by remember { mutableIntStateOf(1) }
    var question by remember { mutableStateOf("") }
    var optA by remember { mutableStateOf("") }
    var optB by remember { mutableStateOf("") }
    var optC by remember { mutableStateOf("") }
    var optD by remember { mutableStateOf("") }
    var correctIdx by remember { mutableIntStateOf(0) }
    var explanation by remember { mutableStateOf("") }
    var difficulty by remember { mutableStateOf("medium") }
    var sourceType by remember { mutableStateOf("manual") }

    val resetForm = {
        editingId = null
        question = ""
        optA = ""
        optB = ""
        optC = ""
        optD = ""
        correctIdx = 0
        explanation = ""
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            CyberCard(
                borderBrush = Brush.horizontalGradient(listOf(NeonCyan, NeonPurple)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (editingId == null) "নতুন MCQ / বইয়ের প্রশ্ন যোগ করুন" else "MCQ এডিট করুন",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    SubjectChapterSelectorRow(
                        selectedSubjectId = subjectId,
                        selectedChapterNumber = chapterNum,
                        onSelectSubject = {
                            subjectId = it
                            chapterNum = SscSyllabusData.getSubject(it)?.chapters?.firstOrNull()?.number ?: 1
                        },
                        onSelectChapter = { chapterNum = it }
                    )

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = sourceType == "manual",
                            onClick = { sourceType = "manual" },
                            modifier = Modifier.heightIn(min = 48.dp),
                            label = { Text("ম্যানুয়াল MCQ") }
                        )
                        FilterChip(
                            selected = sourceType == "book",
                            onClick = { sourceType = "book" },
                            modifier = Modifier.heightIn(min = 48.dp),
                            label = { Text("বইয়ের MCQ") }
                        )
                    }

                    OutlinedTextField(
                        value = question,
                        onValueChange = { question = it },
                        label = { Text("প্রশ্ন লিখুন (গণিতের জন্য √, π, ², ³ ব্যবহারযোগ্য)") },
                        colors = agentFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("agent_mcq_question_input")
                    )
                    OutlinedTextField(
                        value = optA,
                        onValueChange = { optA = it },
                        label = { Text("অপশন (ক)") },
                        colors = agentFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("agent_mcq_opt_a_input")
                    )
                    OutlinedTextField(
                        value = optB,
                        onValueChange = { optB = it },
                        label = { Text("অপশন (খ)") },
                        colors = agentFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("agent_mcq_opt_b_input")
                    )
                    OutlinedTextField(
                        value = optC,
                        onValueChange = { optC = it },
                        label = { Text("অপশন (গ)") },
                        colors = agentFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("agent_mcq_opt_c_input")
                    )
                    OutlinedTextField(
                        value = optD,
                        onValueChange = { optD = it },
                        label = { Text("অপশন (ঘ)") },
                        colors = agentFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("agent_mcq_opt_d_input")
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("সঠিক উত্তর:", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                        listOf("ক", "খ", "গ", "ঘ").forEachIndexed { idx, lbl ->
                            FilterChip(
                                selected = correctIdx == idx,
                                onClick = { correctIdx = idx },
                                modifier = Modifier.heightIn(min = 48.dp),
                                label = { Text(lbl) }
                            )
                        }
                        listOf("easy", "medium", "hard").forEach { diff ->
                            FilterChip(
                                selected = difficulty == diff,
                                onClick = { difficulty = diff },
                                modifier = Modifier.heightIn(min = 48.dp),
                                label = { Text(diff) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = explanation,
                        onValueChange = { explanation = it },
                        label = { Text("সঠিক উত্তরের ব্যাখ্যা") },
                        colors = agentFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("agent_mcq_explanation_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                onSaveMcq(
                                    editingId,
                                    subjectId,
                                    chapterNum,
                                    question,
                                    optA,
                                    optB,
                                    optC,
                                    optD,
                                    correctIdx,
                                    explanation,
                                    difficulty,
                                    sourceType,
                                    false,
                                    resetForm
                                )
                            },
                            enabled = !isBusy,
                            border = BorderStroke(1.dp, NeonCyan),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("save_mcq_draft_button")
                        ) {
                            Icon(imageVector = Icons.Default.Save, contentDescription = "Save Draft", tint = NeonCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ড্রাফট", color = NeonCyan, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                onSaveMcq(
                                    editingId,
                                    subjectId,
                                    chapterNum,
                                    question,
                                    optA,
                                    optB,
                                    optC,
                                    optD,
                                    correctIdx,
                                    explanation,
                                    difficulty,
                                    sourceType,
                                    true,
                                    resetForm
                                )
                            },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            modifier = Modifier
                                .weight(1.3f)
                                .heightIn(min = 48.dp)
                                .testTag("publish_mcq_button")
                        ) {
                            Icon(imageVector = Icons.Default.Publish, contentDescription = "Publish MCQ", tint = Color(0xFF031A24), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("MCQ পাবলিশ করুন", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "যাচাইকৃত MCQ তালিকা (${reviewedMcqs.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        items(reviewedMcqs, key = { it.id }) { item ->
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = TextbookMathFormatter.format(item.question),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            maxLines = 2
                        )
                        Text(
                            text = "${item.subjectName} • অধ্যায় ${item.chapterNumber} • ${item.status} (${item.sourceType})",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (item.status == "published") EmeraldSuccess else AmberGold
                        )
                    }
                    IconButton(
                        onClick = {
                            editingId = item.id
                            subjectId = item.subjectId.ifBlank { "general_math" }
                            chapterNum = item.chapterNumber.toInt().coerceAtLeast(1)
                            question = item.question
                            optA = item.options.getOrElse(0) { "" }
                            optB = item.options.getOrElse(1) { "" }
                            optC = item.options.getOrElse(2) { "" }
                            optD = item.options.getOrElse(3) { "" }
                            correctIdx = item.correctIndex.toInt().coerceIn(0, 3)
                            explanation = item.explanation
                            difficulty = item.difficulty.ifBlank { "medium" }
                            sourceType = if (item.sourceType == "book") "book" else "manual"
                        },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit MCQ", tint = NeonCyan)
                    }
                    IconButton(
                        onClick = { onDeleteMcq(item.id) },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete MCQ", tint = NeonPink)
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}
