package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChapterInfo
import com.example.data.model.SciencePriorityMetrics
import com.example.data.model.SscSyllabusData
import com.example.ui.components.QuickExplanationDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.HindSiliguriFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MainViewModel

private data class ScienceSubjectTheme(
    val id: String,
    val nameBn: String,
    val nameEn: String,
    val accent: Color,
    val deepTint: Color,
    val borderTint: Color,
    val pillBg: Color,
    val pillText: Color,
    val icon: ImageVector
)

private val PhysicsTheme = ScienceSubjectTheme(
    id = "physics",
    nameBn = "পদার্থবিজ্ঞান",
    nameEn = "Physics",
    accent = Color(0xFF38BDF8),
    deepTint = Color(0xFF0A1F38),
    borderTint = Color(0xFF0284C7),
    pillBg = Color(0xFF0C2D48),
    pillText = Color(0xFF7DD3FC),
    icon = Icons.Default.Bolt
)

private val ChemistryTheme = ScienceSubjectTheme(
    id = "chemistry",
    nameBn = "রসায়ন",
    nameEn = "Chemistry",
    accent = Color(0xFFA855F7),
    deepTint = Color(0xFF1F1135),
    borderTint = Color(0xFF7C3AED),
    pillBg = Color(0xFF2E1065),
    pillText = Color(0xFFD8B4FE),
    icon = Icons.Default.Science
)

private val BiologyTheme = ScienceSubjectTheme(
    id = "biology",
    nameBn = "জীববিজ্ঞান",
    nameEn = "Biology",
    accent = Color(0xFF10B981),
    deepTint = Color(0xFF092420),
    borderTint = Color(0xFF059669),
    pillBg = Color(0xFF064E3B),
    pillText = Color(0xFF6EE7B7),
    icon = Icons.Default.Biotech
)

private fun themeForScienceSubject(subjectId: String): ScienceSubjectTheme = when (subjectId) {
    "physics" -> PhysicsTheme
    "chemistry" -> ChemistryTheme
    else -> BiologyTheme
}

private data class SciencePriorityStyle(
    val bg: Color,
    val border: Color,
    val text: Color,
    val label: String,
    val fullLabel: String
)

private fun styleForPriority(tag: String): SciencePriorityStyle = when (tag) {
    "⭐" -> SciencePriorityStyle(
        bg = Color(0xFF064E3B),
        border = Color(0xFF10B981),
        text = Color(0xFF34D399),
        label = "⭐ গুরুত্বপূর্ণ",
        fullLabel = "⭐ অত্যন্ত গুরুত্বপূর্ণ অধ্যায়"
    )
    "☆" -> SciencePriorityStyle(
        bg = Color(0xFF3B0764),
        border = Color(0xFFA855F7),
        text = Color(0xFFE9D5FF),
        label = "☆ সাধারণ",
        fullLabel = "☆ সাধারণ অগ্রাধিকার অধ্যায়"
    )
    else -> SciencePriorityStyle(
        bg = Color(0xFF451A03),
        border = Color(0xFFF59E0B),
        text = Color(0xFFFDE68A),
        label = "🟡 স্বল্প অগ্রাধিকার",
        fullLabel = "🟡 স্বল্প অগ্রাধিকার অধ্যায়"
    )
}

/**
 * SSC 2028 Science Chapter Priority Dashboard
 * App Name: COMPLETE MRH
 *
 * Covers all 39 science chapters strictly in syllabus order without duplication:
 * - Physics (13 chapters, Blue theme): 10 ⭐ Important, 3 ☆ Normal
 * - Chemistry (12 chapters, Purple theme): 10 ⭐ Important, 2 ☆ Normal
 * - Biology (14 chapters, Green theme): 11 ⭐ Important, 3 ☆ Normal
 */
@Composable
fun SciencePriorityScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onAskAi: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val chaptersProgress by viewModel.allChapters.collectAsState()
    val scienceMetrics by viewModel.sciencePriorityMetrics.collectAsState()

    val quickExplainTitle by viewModel.quickExplainTitle.collectAsState()
    val quickExplainContent by viewModel.quickExplainContent.collectAsState()
    val isQuickExplainLoading by viewModel.isQuickExplainLoading.collectAsState()

    // Navigation inside Science Dashboard: null -> Dashboard List, Pair(subjectId, chapterNumber) -> Full Chapter Detail Page
    var selectedChapterTarget by remember { mutableStateOf<Pair<String, Int>?>(null) }

    // Dashboard Filters & Search State
    var searchQuery by remember { mutableStateOf("") }
    var selectedSubjectFilter by remember { mutableStateOf("ALL") } // ALL, physics, chemistry, biology
    var selectedPriorityFilter by remember { mutableStateOf("ALL") } // ALL, IMPORTANT, NORMAL, LOW
    var selectedStatusFilter by remember { mutableStateOf("ALL") } // ALL, COMPLETED, INCOMPLETE
    var showResetConfirmationDialog by remember { mutableStateOf(false) }

    BackHandler {
        if (selectedChapterTarget != null) {
            selectedChapterTarget = null
        } else {
            onBack()
        }
    }

    val physicsSubject = SscSyllabusData.getSubject("physics")
    val chemistrySubject = SscSyllabusData.getSubject("chemistry")
    val biologySubject = SscSyllabusData.getSubject("biology")

    val allScienceChapters = remember(physicsSubject, chemistrySubject, biologySubject) {
        buildList {
            physicsSubject?.chapters?.forEach { add("physics" to it) }
            chemistrySubject?.chapters?.forEach { add("chemistry" to it) }
            biologySubject?.chapters?.forEach { add("biology" to it) }
        }
    }

    val filteredChapters = allScienceChapters.filter { (subId, chapter) ->
        val matchSubject = selectedSubjectFilter == "ALL" || subId == selectedSubjectFilter
        val matchPriority = when (selectedPriorityFilter) {
            "IMPORTANT" -> chapter.importanceTag == "⭐"
            "NORMAL" -> chapter.importanceTag == "☆"
            "LOW" -> chapter.importanceTag == "🟡"
            else -> true
        }
        val entity = chaptersProgress.find { it.id == "${subId}_ch_${chapter.number}" }
        val isDone = entity?.isCompleted == true
        val matchStatus = when (selectedStatusFilter) {
            "COMPLETED" -> isDone
            "INCOMPLETE" -> !isDone
            else -> true
        }
        val q = searchQuery.trim().lowercase()
        val matchSearch = if (q.isBlank()) {
            true
        } else {
            val theme = themeForScienceSubject(subId)
            chapter.title.lowercase().contains(q) ||
                chapter.keyTopics.lowercase().contains(q) ||
                theme.nameBn.lowercase().contains(q) ||
                theme.nameEn.lowercase().contains(q) ||
                chapter.number.toString().contains(q)
        }
        matchSubject && matchPriority && matchStatus && matchSearch
    }

    val backgroundGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF060D1E),
            Color(0xFF0A1931),
            Color(0xFF050A16)
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundGradient)
    ) {
        AnimatedContent(
            targetState = selectedChapterTarget,
            transitionSpec = {
                if (targetState != null) {
                    (slideInHorizontally(tween(240)) { it / 3 } + fadeIn(tween(220))) togetherWith
                        (slideOutHorizontally(tween(220)) { -it / 4 } + fadeOut(tween(180)))
                } else {
                    (slideInHorizontally(tween(240)) { -it / 3 } + fadeIn(tween(220))) togetherWith
                        (slideOutHorizontally(tween(220)) { it / 4 } + fadeOut(tween(180)))
                }
            },
            label = "science_dashboard_detail_transition"
        ) { target ->
            if (target != null) {
                val (subjectId, chapterNumber) = target
                val chapter = SscSyllabusData.getChapter(subjectId, chapterNumber)
                if (chapter != null) {
                    val entityId = "${subjectId}_ch_${chapter.number}"
                    val entity = chaptersProgress.find { it.id == entityId }
                    val isCompleted = entity?.isCompleted == true
                    val note = entity?.notes.orEmpty()

                    ScienceChapterDetailPage(
                        subjectId = subjectId,
                        chapter = chapter,
                        isCompleted = isCompleted,
                        savedNote = note,
                        onBack = { selectedChapterTarget = null },
                        onToggleComplete = {
                            viewModel.toggleChapterCompletion(entityId, isCompleted)
                        },
                        onSaveNote = { updatedNote ->
                            viewModel.saveChapterNote(entityId, updatedNote)
                            Toast.makeText(context, "অধ্যায়ের নোট সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                        },
                        onQuickAiSummary = {
                            val subName = themeForScienceSubject(subjectId).nameBn
                            viewModel.requestQuickExplanation(
                                title = "$subName: ${chapter.title}",
                                prompt = "$subName এর '${chapter.title}' (মূল টপিক: ${chapter.keyTopics}) অধ্যায়টির এসএসসি ২০২৮ পরীক্ষার জন্য সবচেয়ে গুরুত্বপূর্ণ সূত্র, সংজ্ঞা, সৃজনশীল (CQ) ও MCQ সাজেশন বাংলায় বিস্তারিত বুঝিয়ে দিন।"
                            )
                        },
                        onOpenFullAiTutor = {
                            val subName = themeForScienceSubject(subjectId).nameBn
                            val prompt = "$subName এর অধ্যায় ${chapter.number}: '${chapter.title}' (টপিক: ${chapter.keyTopics}) আমাকে এসএসসি ২০২৮ বোর্ড পরীক্ষার উপযোগী করে ধাপে ধাপে, উদাহরণ, সূত্র এবং গুরুত্বপূর্ণ ক, খ, গ, ঘ সৃজনশীল প্রশ্নসহ বুঝিয়ে দাও।"
                            selectedChapterTarget = null
                            onAskAi(prompt)
                        }
                    )
                }
            } else {
                // Main Science Priority Dashboard View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .systemBarsPadding()
                        .padding(horizontal = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 650.dp)
                            .fillMaxSize()
                    ) {
                        Spacer(modifier = Modifier.height(6.dp))

                        // Top App Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                IconButton(
                                    onClick = onBack,
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("science_priority_back_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Back",
                                        tint = NeonCyan
                                    )
                                }
                                Column {
                                    Text(
                                        text = "COMPLETE MRH",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = NeonCyan,
                                        fontFamily = HindSiliguriFontFamily
                                    )
                                    Text(
                                        text = "SSC 2028 বিজ্ঞান চ্যাপ্টার প্রায়োরিটি ড্যাশবোর্ড",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        fontSize = 12.sp,
                                        fontFamily = HindSiliguriFontFamily
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        val copyText = buildString {
                                            appendLine("=== COMPLETE MRH: SSC 2028 বিজ্ঞান সিলেবাস (৩৯টি অধ্যায়) ===")
                                            appendLine("\n[SUBJECT 1: পদার্থবিজ্ঞান (১৩টি অধ্যায়)]")
                                            physicsSubject?.chapters?.forEach { ch ->
                                                appendLine("${ch.number}. ${ch.title} ${ch.importanceTag}")
                                            }
                                            appendLine("\n[SUBJECT 2: রসায়ন (১২টি অধ্যায়)]")
                                            chemistrySubject?.chapters?.forEach { ch ->
                                                appendLine("${ch.number}. ${ch.title} ${ch.importanceTag}")
                                            }
                                            appendLine("\n[SUBJECT 3: জীববিজ্ঞান (১৪টি অধ্যায়)]")
                                            biologySubject?.chapters?.forEach { ch ->
                                                appendLine("${ch.number}. ${ch.title} ${ch.importanceTag}")
                                            }
                                        }
                                        clipboardManager.setText(AnnotatedString(copyText))
                                        Toast.makeText(context, "৩৯টি বিজ্ঞান অধ্যায়ের তালিকা কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("science_copy_list_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy Science Chapters",
                                        tint = NeonCyan
                                    )
                                }

                                IconButton(
                                    onClick = { showResetConfirmationDialog = true },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("science_reset_progress_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Reset Science Progress",
                                        tint = NeonPink
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Combined Science Hero Dashboard + 3 Subject Sub-Dashboards
                            item {
                                ScienceCombinedHeroCard(
                                    metrics = scienceMetrics,
                                    selectedSubjectFilter = selectedSubjectFilter,
                                    onSelectSubject = { clickedSubject ->
                                        selectedSubjectFilter = if (selectedSubjectFilter == clickedSubject) {
                                            "ALL"
                                        } else {
                                            clickedSubject
                                        }
                                    }
                                )
                            }

                            // Selected Subject Spotlight Card when Physics / Chemistry / Biology Dashboard is active
                            if (selectedSubjectFilter != "ALL") {
                                item {
                                    IndividualSubjectSpotlightCard(
                                        subjectId = selectedSubjectFilter,
                                        metrics = scienceMetrics,
                                        chapters = when (selectedSubjectFilter) {
                                            "physics" -> physicsSubject?.chapters.orEmpty()
                                            "chemistry" -> chemistrySubject?.chapters.orEmpty()
                                            else -> biologySubject?.chapters.orEmpty()
                                        },
                                        onShowAll = { selectedSubjectFilter = "ALL" }
                                    )
                                }
                            }

                            // Search & Filter Controls
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = searchQuery,
                                        onValueChange = { searchQuery = it },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("science_search_input"),
                                        placeholder = {
                                            Text(
                                                "অধ্যায় বা টপিক খুঁজুন (যেমন: গতি, মোল, কোষ, বিদ্যুৎ)...",
                                                color = TextTertiary,
                                                fontSize = 13.sp,
                                                fontFamily = HindSiliguriFontFamily
                                            )
                                        },
                                        leadingIcon = {
                                            Icon(Icons.Default.Search, contentDescription = "Search", tint = NeonCyan)
                                        },
                                        trailingIcon = {
                                            if (searchQuery.isNotEmpty()) {
                                                IconButton(onClick = { searchQuery = "" }) {
                                                    Icon(Icons.Default.Clear, contentDescription = "Clear Search", tint = TextSecondary)
                                                }
                                            }
                                        },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedContainerColor = Color(0xFF0C1A30),
                                            unfocusedContainerColor = Color(0xFF0C1A30),
                                            focusedBorderColor = NeonCyan,
                                            unfocusedBorderColor = Color(0xFF1E3A5F),
                                            focusedTextColor = TextPrimary,
                                            unfocusedTextColor = TextPrimary
                                        )
                                    )

                                    // Subject Tabs: Combined + Individual Physics / Chemistry / Biology
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        val subjectTabs = listOf(
                                            Triple("ALL", "সকল বিজ্ঞান (৩৯)", NeonCyan),
                                            Triple("physics", "পদার্থবিজ্ঞান (১৩)", PhysicsTheme.accent),
                                            Triple("chemistry", "রসায়ন (১২)", ChemistryTheme.accent),
                                            Triple("biology", "জীববিজ্ঞান (১৪)", BiologyTheme.accent)
                                        )
                                        items(subjectTabs) { (key, label, accent) ->
                                            val isSelected = selectedSubjectFilter == key
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = { selectedSubjectFilter = key },
                                                modifier = Modifier.testTag("science_tab_$key"),
                                                label = {
                                                    Text(
                                                        label,
                                                        fontSize = 12.sp,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                        fontFamily = HindSiliguriFontFamily
                                                    )
                                                },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = accent,
                                                    selectedLabelColor = Color(0xFF04111E),
                                                    containerColor = Color(0xFF0F1E33),
                                                    labelColor = TextSecondary
                                                ),
                                                border = FilterChipDefaults.filterChipBorder(
                                                    borderColor = accent.copy(alpha = 0.35f),
                                                    selectedBorderColor = accent,
                                                    enabled = true,
                                                    selected = isSelected
                                                )
                                            )
                                        }
                                    }

                                    // Priority & Completion Filters
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        val priorityOptions = listOf(
                                            Triple("ALL", "সকল প্রায়োরিটি", NeonCyan),
                                            Triple("IMPORTANT", "⭐ গুরুত্বপূর্ণ (${scienceMetrics.importantCount})", Color(0xFF10B981)),
                                            Triple("NORMAL", "☆ সাধারণ (${scienceMetrics.normalCount})", Color(0xFFA855F7)),
                                            Triple("LOW", "🟡 স্বল্প (${scienceMetrics.lowCount})", Color(0xFFF59E0B))
                                        )
                                        items(priorityOptions) { (key, label, color) ->
                                            val selected = selectedPriorityFilter == key
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(14.dp))
                                                    .background(if (selected) color.copy(alpha = 0.24f) else Color(0xFF0C1A30))
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (selected) color else Color(0xFF1E3A5F),
                                                        shape = RoundedCornerShape(14.dp)
                                                    )
                                                    .clickable { selectedPriorityFilter = key }
                                                    .padding(horizontal = 11.dp, vertical = 7.dp)
                                                    .testTag("science_priority_filter_$key")
                                            ) {
                                                Text(
                                                    text = label,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (selected) color else TextSecondary,
                                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                                    fontFamily = HindSiliguriFontFamily,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }

                                    // Completion Status Filter Row
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf(
                                            "ALL" to "সব অধ্যায়",
                                            "INCOMPLETE" to "বাকি (${scienceMetrics.totalRemaining})",
                                            "COMPLETED" to "সম্পন্ন (${scienceMetrics.totalCompleted})"
                                        ).forEach { (statusKey, statusLabel) ->
                                            val isSelected = selectedStatusFilter == statusKey
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(if (isSelected) Color(0xFF163252) else Color(0xFF0B1628))
                                                    .border(
                                                        1.dp,
                                                        if (isSelected) NeonCyan else Color(0xFF1E3A5F),
                                                        RoundedCornerShape(10.dp)
                                                    )
                                                    .clickable { selectedStatusFilter = statusKey }
                                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                                            ) {
                                                Text(
                                                    text = statusLabel,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSelected) NeonCyan else TextSecondary,
                                                    fontFamily = HindSiliguriFontFamily
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // List Header Counter
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "অধ্যায় তালিকা (${filteredChapters.size}টি প্রদর্শিত)",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFE2E8F0),
                                        fontFamily = HindSiliguriFontFamily
                                    )
                                    Text(
                                        text = "ট্যাপ করে অধ্যায় পেজ দেখুন",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextTertiary,
                                        fontSize = 11.sp,
                                        fontFamily = HindSiliguriFontFamily
                                    )
                                }
                            }

                            if (filteredChapters.isEmpty()) {
                                item {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1D34)),
                                        border = BorderStroke(1.dp, Color(0xFF1E3A5F))
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(22.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Search,
                                                contentDescription = "Empty",
                                                tint = NeonCyan,
                                                modifier = Modifier.size(34.dp)
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "কোনো বিজ্ঞান অধ্যায় পাওয়া যায়নি",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary,
                                                fontFamily = HindSiliguriFontFamily
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "ফিল্টার রিসেট করুন অথবা অন্য শব্দ দিয়ে অনুসন্ধান করুন।",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = TextSecondary,
                                                fontFamily = HindSiliguriFontFamily
                                            )
                                        }
                                    }
                                }
                            } else {
                                items(
                                    items = filteredChapters,
                                    key = { "${it.first}_${it.second.number}" }
                                ) { (subId, chapter) ->
                                    val entityId = "${subId}_ch_${chapter.number}"
                                    val progressEntity = chaptersProgress.find { it.id == entityId }
                                    val isCompleted = progressEntity?.isCompleted == true
                                    val hasNote = !progressEntity?.notes.isNullOrBlank()

                                    ScienceChapterCard(
                                        subjectId = subId,
                                        chapter = chapter,
                                        isCompleted = isCompleted,
                                        hasNote = hasNote,
                                        onToggleComplete = {
                                            viewModel.toggleChapterCompletion(entityId, isCompleted)
                                        },
                                        onOpenDetail = {
                                            selectedChapterTarget = subId to chapter.number
                                        }
                                    )
                                }
                            }

                            item {
                                Spacer(modifier = Modifier.height(28.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Reset Progress Confirmation Dialog
    if (showResetConfirmationDialog) {
        val activeSubjectLabel = when (selectedSubjectFilter) {
            "physics" -> "পদার্থবিজ্ঞান (১৩টি অধ্যায়)"
            "chemistry" -> "রসায়ন (১২টি অধ্যায়)"
            "biology" -> "জীববিজ্ঞান (১৪টি অধ্যায়)"
            else -> "পদার্থবিজ্ঞান (১৩), রসায়ন (১২) ও জীববিজ্ঞান (১৪) সহ সকল ৩৯টি অধ্যায়"
        }
        AlertDialog(
            onDismissRequest = { showResetConfirmationDialog = false },
            containerColor = Color(0xFF101C32),
            icon = {
                Icon(Icons.Default.Warning, contentDescription = "Reset Warning", tint = NeonPink, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "বিজ্ঞান অগ্রগতি রিসেট নিশ্চিতকরণ",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontFamily = HindSiliguriFontFamily
                )
            },
            text = {
                Text(
                    text = "আপনি কি $activeSubjectLabel-এর সমাপ্তি অগ্রগতি রিসেট করতে চান? আপনার লেখা ব্যক্তিগত নোটগুলি নিরাপদে সংরক্ষিত থাকবে।",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    fontFamily = HindSiliguriFontFamily
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetScienceProgress(
                            if (selectedSubjectFilter in listOf("physics", "chemistry", "biology")) {
                                selectedSubjectFilter
                            } else {
                                null
                            }
                        )
                        showResetConfirmationDialog = false
                        Toast.makeText(context, "বিজ্ঞান অগ্রগতি সফলভাবে রিসেট করা হয়েছে!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink)
                ) {
                    Text("হ্যাঁ, রিসেট করুন", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = HindSiliguriFontFamily)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmationDialog = false }) {
                    Text("বাতিল", color = TextSecondary, fontFamily = HindSiliguriFontFamily)
                }
            }
        )
    }

    // Quick AI Explanation Modal
    QuickExplanationDialog(
        title = quickExplainTitle,
        content = quickExplainContent,
        isLoading = isQuickExplainLoading,
        onDismiss = { viewModel.closeQuickExplanation() }
    )
}

@Composable
private fun ScienceCombinedHeroCard(
    metrics: SciencePriorityMetrics,
    selectedSubjectFilter: String,
    onSelectSubject: (String) -> Unit
) {
    val overallProgress by animateFloatAsState(
        targetValue = (metrics.totalPercent / 100f).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "science_overall_progress"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1A31)),
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.horizontalGradient(
                listOf(PhysicsTheme.accent, ChemistryTheme.accent, BiologyTheme.accent)
            )
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "সমন্বিত বিজ্ঞান প্রস্তুতি ড্যাশবোর্ড",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontFamily = HindSiliguriFontFamily
                    )
                    Text(
                        text = "সম্পন্ন: ${metrics.totalCompleted}/${metrics.totalChapters} • বাকি: ${metrics.totalRemaining}টি অধ্যায়",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCyan,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = HindSiliguriFontFamily
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF064E3B))
                        .border(1.dp, EmeraldSuccess, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${metrics.totalPercent}%",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF34D399)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { overallProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(9.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = NeonCyan,
                trackColor = Color(0xFF17263D)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Separate Subject Dashboards: Blue Physics, Purple Chemistry, Green Biology
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SubjectMiniDashboardCard(
                    theme = PhysicsTheme,
                    completed = metrics.physicsCompleted,
                    total = metrics.physicsTotal,
                    remaining = metrics.physicsRemaining,
                    percent = metrics.physicsPercent,
                    isSelected = selectedSubjectFilter == "physics",
                    onClick = { onSelectSubject("physics") },
                    modifier = Modifier.weight(1f)
                )
                SubjectMiniDashboardCard(
                    theme = ChemistryTheme,
                    completed = metrics.chemistryCompleted,
                    total = metrics.chemistryTotal,
                    remaining = metrics.chemistryRemaining,
                    percent = metrics.chemistryPercent,
                    isSelected = selectedSubjectFilter == "chemistry",
                    onClick = { onSelectSubject("chemistry") },
                    modifier = Modifier.weight(1f)
                )
                SubjectMiniDashboardCard(
                    theme = BiologyTheme,
                    completed = metrics.biologyCompleted,
                    total = metrics.biologyTotal,
                    remaining = metrics.biologyRemaining,
                    percent = metrics.biologyPercent,
                    isSelected = selectedSubjectFilter == "biology",
                    onClick = { onSelectSubject("biology") },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Priority Summary Footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF064E3B))
                            .border(0.8.dp, Color(0xFF10B981), RoundedCornerShape(8.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "⭐ গুরুত্বপূর্ণ: ${metrics.importantCount}টি",
                            fontSize = 10.sp,
                            color = Color(0xFF34D399),
                            fontWeight = FontWeight.Bold,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF3B0764))
                            .border(0.8.dp, Color(0xFFA855F7), RoundedCornerShape(8.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "☆ সাধারণ: ${metrics.normalCount}টি",
                            fontSize = 10.sp,
                            color = Color(0xFFE9D5FF),
                            fontWeight = FontWeight.Bold,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }
                Text(
                    text = "মোট ৩৯ অধ্যায়",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary,
                    fontSize = 11.sp,
                    fontFamily = HindSiliguriFontFamily
                )
            }
        }
    }
}

@Composable
private fun SubjectMiniDashboardCard(
    theme: ScienceSubjectTheme,
    completed: Int,
    total: Int,
    remaining: Int,
    percent: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = (percent / 100f).coerceIn(0f, 1f),
        animationSpec = tween(400),
        label = "sub_mini_prog_${theme.id}"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) theme.deepTint else Color(0xFF091326))
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) theme.accent else theme.borderTint.copy(alpha = 0.55f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(9.dp)
            .testTag("science_mini_card_${theme.id}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = theme.icon,
                    contentDescription = theme.nameEn,
                    tint = theme.accent,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "$percent%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = theme.accent
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = theme.nameBn,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
                fontFamily = HindSiliguriFontFamily
            )
            Text(
                text = "$completed/$total • বাকি $remaining",
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1,
                fontFamily = HindSiliguriFontFamily
            )
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = theme.accent,
                trackColor = Color(0xFF17263D)
            )
        }
    }
}

@Composable
private fun IndividualSubjectSpotlightCard(
    subjectId: String,
    metrics: SciencePriorityMetrics,
    chapters: List<ChapterInfo>,
    onShowAll: () -> Unit
) {
    val theme = themeForScienceSubject(subjectId)
    val (done, total, remaining, percent) = when (subjectId) {
        "physics" -> listOf(metrics.physicsCompleted, metrics.physicsTotal, metrics.physicsRemaining, metrics.physicsPercent)
        "chemistry" -> listOf(metrics.chemistryCompleted, metrics.chemistryTotal, metrics.chemistryRemaining, metrics.chemistryPercent)
        else -> listOf(metrics.biologyCompleted, metrics.biologyTotal, metrics.biologyRemaining, metrics.biologyPercent)
    }
    val impCount = chapters.count { it.importanceTag == "⭐" }
    val normCount = chapters.count { it.importanceTag == "☆" }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = theme.deepTint),
        border = BorderStroke(1.2.dp, theme.accent)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(theme.accent.copy(alpha = 0.2f))
                            .border(1.dp, theme.accent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(theme.icon, contentDescription = theme.nameEn, tint = theme.accent)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${theme.nameBn} (${theme.nameEn}) ড্যাশবোর্ড",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontFamily = HindSiliguriFontFamily
                        )
                        Text(
                            text = "মোট $total অধ্যায় • ⭐ গুরুত্বপূর্ণ: $impCount • ☆ সাধারণ: $normCount",
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.pillText,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }
                TextButton(onClick = onShowAll) {
                    Text(
                        text = "সব দেখুন",
                        color = theme.accent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = HindSiliguriFontFamily
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "সম্পন্ন: $done/$total ($percent%)",
                    style = MaterialTheme.typography.labelMedium,
                    color = EmeraldSuccess,
                    fontWeight = FontWeight.Bold,
                    fontFamily = HindSiliguriFontFamily
                )
                Text(
                    text = "অবশিষ্ট: ${remaining}টি অধ্যায়",
                    style = MaterialTheme.typography.labelMedium,
                    color = AmberGold,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = HindSiliguriFontFamily
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { (percent / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = theme.accent,
                trackColor = Color(0xFF0A1426)
            )
        }
    }
}

@Composable
private fun ScienceChapterCard(
    subjectId: String,
    chapter: ChapterInfo,
    isCompleted: Boolean,
    hasNote: Boolean,
    onToggleComplete: () -> Unit,
    onOpenDetail: () -> Unit
) {
    val theme = themeForScienceSubject(subjectId)
    val pStyle = styleForPriority(chapter.importanceTag)

    val cardBg by animateColorAsState(
        targetValue = if (isCompleted) theme.deepTint else Color(0xFF0D1B32),
        animationSpec = tween(250),
        label = "science_card_bg_${subjectId}_${chapter.number}"
    )
    val cardBorder by animateColorAsState(
        targetValue = if (isCompleted) theme.accent else theme.borderTint.copy(alpha = 0.45f),
        animationSpec = tween(250),
        label = "science_card_border_${subjectId}_${chapter.number}"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("science_chapter_card_${subjectId}_${chapter.number}")
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onOpenDetail),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = BorderStroke(1.dp, cardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Index Badge themed in Blue/Purple/Green
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (isCompleted) theme.accent else theme.pillBg)
                    .border(1.dp, theme.accent.copy(alpha = 0.7f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = String.format("%02d", chapter.number),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isCompleted) Color(0xFF04101D) else theme.pillText
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Priority Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(pStyle.bg)
                            .border(0.8.dp, pStyle.border, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = pStyle.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = pStyle.text,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }

                    // Subject Pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(theme.pillBg)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = theme.nameBn,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = theme.pillText,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }

                    if (hasNote) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "Saved Note",
                            tint = AmberGold,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = chapter.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isCompleted) TextSecondary else TextPrimary,
                    fontFamily = HindSiliguriFontFamily
                )

                Text(
                    text = chapter.keyTopics,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 2,
                    fontSize = 11.5.sp,
                    fontFamily = HindSiliguriFontFamily
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${chapter.defaultDays} দিন • অধ্যায় পেজ খুলুন",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = theme.accent,
                        fontFamily = HindSiliguriFontFamily
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = theme.accent,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            IconButton(
                onClick = onToggleComplete,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("science_chapter_toggle_${subjectId}_${chapter.number}")
            ) {
                Icon(
                    imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = if (isCompleted) "Mark incomplete" else "Mark completed",
                    tint = if (isCompleted) theme.accent else Color(0xFF64748B),
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

/**
 * Full-page dedicated Chapter Detail Page for Physics, Chemistry, and Biology chapters
 */
@Composable
private fun ScienceChapterDetailPage(
    subjectId: String,
    chapter: ChapterInfo,
    isCompleted: Boolean,
    savedNote: String,
    onBack: () -> Unit,
    onToggleComplete: () -> Unit,
    onSaveNote: (String) -> Unit,
    onQuickAiSummary: () -> Unit,
    onOpenFullAiTutor: () -> Unit
) {
    val theme = themeForScienceSubject(subjectId)
    val pStyle = styleForPriority(chapter.importanceTag)
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var noteDraft by remember(subjectId, chapter.number, savedNote) { mutableStateOf(savedNote) }
    LaunchedEffect(savedNote) {
        noteDraft = savedNote
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 650.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(modifier = Modifier.height(6.dp))

            // Top Detail Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("science_detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Dashboard",
                            tint = theme.accent
                        )
                    }
                    Column {
                        Text(
                            text = "${theme.nameBn} • অধ্যায় ${chapter.number}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = theme.accent,
                            fontFamily = HindSiliguriFontFamily
                        )
                        Text(
                            text = "অধ্যায় বিস্তারিত পৃষ্ঠা — COMPLETE MRH",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.5.sp,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }

                IconButton(
                    onClick = {
                        val copyStr = "${theme.nameBn} — অধ্যায় ${chapter.number}: ${chapter.title} (${pStyle.label})\nমূল টপিক: ${chapter.keyTopics}"
                        clipboardManager.setText(AnnotatedString(copyStr))
                        Toast.makeText(context, "অধ্যায়ের তথ্য কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy chapter details",
                        tint = theme.accent
                    )
                }
            }

            // Hero Chapter Title Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = theme.deepTint),
                border = BorderStroke(1.3.dp, theme.accent)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(pStyle.bg)
                                .border(0.9.dp, pStyle.border, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = pStyle.fullLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = pStyle.text,
                                fontFamily = HindSiliguriFontFamily
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0A1426))
                                .border(0.8.dp, theme.borderTint, RoundedCornerShape(8.dp))
                                .padding(horizontal = 9.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = "Study Days",
                                    tint = theme.accent,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "প্রস্তুতি সময়: ${chapter.defaultDays} দিন",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    fontFamily = HindSiliguriFontFamily
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = chapter.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = HindSiliguriFontFamily
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "এসএসসি ২০২৮ বোর্ড পরীক্ষা • ${theme.nameBn} (${theme.nameEn})",
                        style = MaterialTheme.typography.bodySmall,
                        color = theme.pillText,
                        fontFamily = HindSiliguriFontFamily
                    )
                }
            }

            // Completion Toggle Action Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(onClick = onToggleComplete)
                    .testTag("science_detail_completion_toggle"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCompleted) Color(0xFF064E3B).copy(alpha = 0.5f) else Color(0xFF0D1B32)
                ),
                border = BorderStroke(
                    1.2.dp,
                    if (isCompleted) EmeraldSuccess else theme.borderTint
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isCompleted) "অধ্যায়টি সম্পন্ন হিসেবে চিহ্নিত" else "অধ্যায়টি এখনও বাকি আছে",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isCompleted) Color(0xFF34D399) else TextPrimary,
                            fontFamily = HindSiliguriFontFamily
                        )
                        Text(
                            text = if (isCompleted) "আবার ট্যাপ করলে বাকি তালিকায় ফিরে যাবে" else "পড়া শেষ হলে এখানে ট্যাপ করে সম্পন্ন করুন",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                    Icon(
                        imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Completion status",
                        tint = if (isCompleted) EmeraldSuccess else TextTertiary,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            // Core Topics & Study Roadmap Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B32)),
                border = BorderStroke(1.dp, theme.borderTint.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MenuBook, contentDescription = "Topics", tint = theme.accent, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "মূল আলোচ্য বিষয় ও সূত্রাবলি",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = theme.accent,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = chapter.keyTopics,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        lineHeight = 22.sp,
                        fontFamily = HindSiliguriFontFamily
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF081424))
                            .border(0.8.dp, Color(0xFF1E3A5F), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "স্মার্ট অধ্যয়ন চেকলিস্ট:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = AmberGold,
                                fontFamily = HindSiliguriFontFamily
                            )
                            Text(
                                text = "১. মূল পাঠ্যবইয়ের সংজ্ঞা ও সূত্রগুলো নোট করুন\n২. প্রতিটি সূত্রের গাণিতিক উদাহরণ ও চিত্র অনুশীলন করুন\n৩. বিগত ৫ বছরের বোর্ড CQ ও অন্তত ২৫টি MCQ সমাধান করুন",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                lineHeight = 19.sp,
                                fontFamily = HindSiliguriFontFamily
                            )
                        }
                    }
                }
            }

            // Personal Notes Inline Editor Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B32)),
                border = BorderStroke(1.dp, Color(0xFF1E3A5F))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Edit, contentDescription = "Personal Notes", tint = AmberGold, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ব্যক্তিগত নোট ও গুরুত্বপূর্ণ পয়েন্ট",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = AmberGold,
                                fontFamily = HindSiliguriFontFamily
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = noteDraft,
                        onValueChange = { noteDraft = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("science_detail_note_input"),
                        placeholder = {
                            Text(
                                "এই অধ্যায়ের সূত্র, গুরুত্বপূর্ণ লাইন বা ভুল হওয়ার জায়গা লিখে সংরক্ষণ করুন...",
                                fontSize = 12.5.sp,
                                color = TextTertiary,
                                fontFamily = HindSiliguriFontFamily
                            )
                        },
                        minLines = 3,
                        maxLines = 6,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF081424),
                            unfocusedContainerColor = Color(0xFF081424),
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = Color(0xFF1E3A5F),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { onSaveNote(noteDraft.trim()) },
                        colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("science_detail_save_note_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = Color(0xFF1A1002), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ব্যক্তিগত নোট সংরক্ষণ করুন",
                            color = Color(0xFF1A1002),
                            fontWeight = FontWeight.Bold,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }
            }

            // AI Learning Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onQuickAiSummary,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.2.dp, theme.accent),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "দ্রুত AI সারাংশ",
                        color = theme.accent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        fontFamily = HindSiliguriFontFamily
                    )
                }

                Button(
                    onClick = onOpenFullAiTutor,
                    colors = ButtonDefaults.buttonColors(containerColor = theme.accent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1.3f)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = "AI Tutor", tint = Color(0xFF04101D), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "MRH AI টিউটরে শিখুন",
                        color = Color(0xFF04101D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        fontFamily = HindSiliguriFontFamily
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}
