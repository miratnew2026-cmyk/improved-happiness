package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChapterProgressEntity
import com.example.data.model.ChapterInfo
import com.example.data.model.SscSyllabusData
import com.example.ui.components.ChapterNoteDialog
import com.example.ui.components.QuickExplanationDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.AppFontFamily
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.HindSiliguriFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MainViewModel

/**
 * SSC 2028 Mathematics Chapter Priority Interface
 * App Name: COMPLETE MRH
 *
 * Covers all 31 mathematics chapters without duplication:
 * - Subject 1: General Mathematics (17 chapters: 15 ⭐ Important, 2 ☆ Normal)
 * - Subject 2: Higher Mathematics (14 chapters: 13 ⭐ Important, 1 ☆ Normal)
 */
@Composable
fun MathPriorityScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onAskAi: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val chaptersProgress by viewModel.allChapters.collectAsState()
    val mathMetrics by viewModel.mathPriorityMetrics.collectAsState()

    val quickExplainTitle by viewModel.quickExplainTitle.collectAsState()
    val quickExplainContent by viewModel.quickExplainContent.collectAsState()
    val isQuickExplainLoading by viewModel.isQuickExplainLoading.collectAsState()

    // Filters and Search State
    var searchQuery by remember { mutableStateOf("") }
    var selectedSubjectFilter by remember { mutableStateOf("ALL") } // ALL, general_math, higher_math
    var selectedPriorityFilter by remember { mutableStateOf("ALL") } // ALL, IMPORTANT (⭐), NORMAL (☆), LOW (🟡)
    var selectedStatusFilter by remember { mutableStateOf("ALL") } // ALL, COMPLETED, INCOMPLETE

    // Dialogs state
    var selectedChapterForDetail by remember { mutableStateOf<Triple<ChapterInfo, String, Boolean>?>(null) } // chapter, subjectName, isCompleted
    var editingChapterNote by remember { mutableStateOf<Pair<String, String>?>(null) } // id to current note
    var editingChapterTitle by remember { mutableStateOf("") }
    var showResetConfirmationDialog by remember { mutableStateOf(false) }

    // Aggregate all 31 chapters
    val genMathSubject = SscSyllabusData.getSubject("general_math")
    val highMathSubject = SscSyllabusData.getSubject("higher_math")

    val allMathChapters = remember(genMathSubject, highMathSubject) {
        val list = mutableListOf<Pair<String, ChapterInfo>>() // subjectId to ChapterInfo
        genMathSubject?.chapters?.forEach { ch -> list.add("general_math" to ch) }
        highMathSubject?.chapters?.forEach { ch -> list.add("higher_math" to ch) }
        list
    }

    // Filtered list
    val filteredChapters = allMathChapters.filter { (subId, chapter) ->
        // Subject Filter
        val matchSubject = when (selectedSubjectFilter) {
            "general_math" -> subId == "general_math"
            "higher_math" -> subId == "higher_math"
            else -> true
        }

        // Priority Filter
        val matchPriority = when (selectedPriorityFilter) {
            "IMPORTANT" -> chapter.importanceTag == "⭐"
            "NORMAL" -> chapter.importanceTag == "☆"
            "LOW" -> chapter.importanceTag == "🟡"
            else -> true
        }

        // Status Filter
        val chProgress = chaptersProgress.find { it.id == "${subId}_ch_${chapter.number}" }
        val isDone = chProgress?.isCompleted == true
        val matchStatus = when (selectedStatusFilter) {
            "COMPLETED" -> isDone
            "INCOMPLETE" -> !isDone
            else -> true
        }

        // Search Query
        val query = searchQuery.trim().lowercase()
        val matchSearch = if (query.isBlank()) {
            true
        } else {
            val title = chapter.title.lowercase()
            val topics = chapter.keyTopics.lowercase()
            val subName = if (subId == "general_math") "সাধারণ গণিত general math" else "উচ্চতর গণিত higher math"
            title.contains(query) || topics.contains(query) || subName.contains(query) ||
                    chapter.number.toString().contains(query)
        }

        matchSubject && matchPriority && matchStatus && matchSearch
    }

    // Navy & Blue background gradient
    val backgroundGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF070F1E),
            Color(0xFF0B172B),
            Color(0xFF070C18)
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundGradient)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 14.dp)
        ) {
            Spacer(modifier = Modifier.height(6.dp))

        // Top App Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("math_priority_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = NeonCyan
                    )
                }
                Column {
                    Text(
                        text = "COMPLETE MRH",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan,
                        fontFamily = HindSiliguriFontFamily
                    )
                    Text(
                        text = "SSC 2028 গণিত চ্যাপ্টার প্রায়োরিটি ড্যাশবোর্ড",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontFamily = HindSiliguriFontFamily
                    )
                }
            }

            Row {
                // Copy Chapter List Button
                IconButton(
                    onClick = {
                        val textToCopy = buildString {
                            appendLine("=== COMPLETE MRH: SSC 2028 গণিত সিলেবাস (৩১টি অধ্যায়) ===")
                            appendLine("\n[বিষয় ১: সাধারণ গণিত (১৭টি অধ্যায়)]")
                            genMathSubject?.chapters?.forEach { ch ->
                                appendLine("${ch.number}. ${ch.title} ${ch.importanceTag}")
                            }
                            appendLine("\n[বিষয় ২: উচ্চতর গণিত (১৪টি অধ্যায়)]")
                            highMathSubject?.chapters?.forEach { ch ->
                                appendLine("${ch.number}. ${ch.title} ${ch.importanceTag}")
                            }
                        }
                        clipboardManager.setText(AnnotatedString(textToCopy))
                        Toast.makeText(context, "৩১টি গণিত অধ্যায়ের তালিকা কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("math_copy_list_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy List",
                        tint = NeonCyan
                    )
                }

                // Reset Progress Button
                IconButton(
                    onClick = { showResetConfirmationDialog = true },
                    modifier = Modifier.testTag("math_reset_progress_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset Progress",
                        tint = NeonPink
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Dashboard Progress Hero Card
            item {
                MathHeroDashboardCard(
                    metrics = mathMetrics,
                    totalFiltered = filteredChapters.size
                )
            }

            // Search Bar & Filter Controls
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Search Input
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("math_search_input"),
                        placeholder = {
                            Text(
                                "অধ্যায়ের নাম বা টপিক খুঁজুন (যেমন: বীজগণিত, স্থানাঙ্ক, ত্রিকোণমিতি)...",
                                color = TextTertiary,
                                fontSize = 13.sp,
                                fontFamily = HindSiliguriFontFamily
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = NeonCyan)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF0D1B2E),
                            unfocusedContainerColor = Color(0xFF0D1B2E),
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = Color(0xFF1E3A5F),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    // Subject Filter Chips
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val subjects = listOf(
                            "ALL" to "উভয় বিষয় (৩১)",
                            "general_math" to "সাধারণ গণিত (১৭)",
                            "higher_math" to "উচ্চতর গণিত (১৪)"
                        )
                        items(subjects) { (key, label) ->
                            FilterChip(
                                selected = selectedSubjectFilter == key,
                                onClick = { selectedSubjectFilter = key },
                                label = {
                                    Text(
                                        label,
                                        fontSize = 12.sp,
                                        fontWeight = if (selectedSubjectFilter == key) FontWeight.Bold else FontWeight.Normal,
                                        fontFamily = HindSiliguriFontFamily
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonCyan,
                                    selectedLabelColor = Color(0xFF021722),
                                    containerColor = Color(0xFF0F1E33),
                                    labelColor = TextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = Color(0xFF1E3A5F),
                                    selectedBorderColor = NeonCyan,
                                    enabled = true,
                                    selected = selectedSubjectFilter == key
                                )
                            )
                        }
                    }

                    // Priority Filter Badges
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val priorities = listOf(
                            "ALL" to "সকল প্রায়োরিটি",
                            "IMPORTANT" to "⭐ গুরুত্বপূর্ণ (২৮)",
                            "NORMAL" to "☆ সাধারণ (৩)",
                            "LOW" to "🟡 স্বল্প অগ্রাধিকার (০)"
                        )
                        items(priorities) { (key, label) ->
                            val isSelected = selectedPriorityFilter == key
                            val badgeColor = when (key) {
                                "IMPORTANT" -> Color(0xFF10B981)
                                "NORMAL" -> Color(0xFFA855F7)
                                "LOW" -> Color(0xFFF59E0B)
                                else -> NeonCyan
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) badgeColor.copy(alpha = 0.25f) else Color(0xFF0D1B2E))
                                    .border(
                                        1.dp,
                                        if (isSelected) badgeColor else Color(0xFF1E3A5F),
                                        RoundedCornerShape(14.dp)
                                    )
                                    .clickable { selectedPriorityFilter = key }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) badgeColor else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontFamily = HindSiliguriFontFamily,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Section Header & Counter
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "অধ্যায়ের তালিকা (${filteredChapters.size}টি প্রদর্শিত)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE2E8F0),
                        fontFamily = HindSiliguriFontFamily
                    )
                    Text(
                        text = "ক্লিক করে বিস্তারিত দেখুন",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary,
                        fontSize = 11.sp,
                        fontFamily = HindSiliguriFontFamily
                    )
                }
            }

            if (filteredChapters.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E33)),
                        border = BorderStroke(1.dp, Color(0xFF1E3A5F))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "কোনো অধ্যায় খুঁজে পাওয়া যায়নি",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontFamily = HindSiliguriFontFamily
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "অনুসন্ধান শব্দ বা ফিল্টার পরিবর্তন করে আবার চেষ্টা করুন।",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontFamily = HindSiliguriFontFamily
                            )
                        }
                    }
                }
            } else {
                // Chapter Cards
                items(filteredChapters, key = { "${it.first}_${it.second.number}" }) { (subId, chapter) ->
                    val entityId = "${subId}_ch_${chapter.number}"
                    val progressEntity = chaptersProgress.find { it.id == entityId }
                    val isCompleted = progressEntity?.isCompleted == true
                    val hasNote = !progressEntity?.notes.isNullOrBlank()

                    MathChapterCard(
                        chapter = chapter,
                        subjectId = subId,
                        isCompleted = isCompleted,
                        hasNote = hasNote,
                        onToggleComplete = {
                            viewModel.toggleChapterCompletion(entityId, isCompleted)
                        },
                        onClick = {
                            val subName = if (subId == "general_math") "সাধারণ গণিত" else "উচ্চতর গণিত"
                            selectedChapterForDetail = Triple(chapter, subName, isCompleted)
                        }
                    )
                }
            }

                item {
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }

    // Chapter Detail Modal Dialog
    if (selectedChapterForDetail != null) {
        val (chapter, subjectName, initialIsCompleted) = selectedChapterForDetail!!
        val entityId = if (subjectName == "সাধারণ গণিত") "general_math_ch_${chapter.number}" else "higher_math_ch_${chapter.number}"
        val currentProgress = chaptersProgress.find { it.id == entityId }
        val currentIsCompleted = currentProgress?.isCompleted ?: initialIsCompleted
        val currentNote = currentProgress?.notes.orEmpty()

        MathChapterDetailDialog(
            chapter = chapter,
            subjectName = subjectName,
            isCompleted = currentIsCompleted,
            note = currentNote,
            onDismiss = { selectedChapterForDetail = null },
            onToggleComplete = {
                viewModel.toggleChapterCompletion(entityId, currentIsCompleted)
            },
            onEditNote = {
                editingChapterTitle = "$subjectName: ${chapter.title}"
                editingChapterNote = entityId to currentNote
                selectedChapterForDetail = null
            },
            onAskAi = {
                selectedChapterForDetail = null
                viewModel.requestQuickExplanation(
                    title = "$subjectName: ${chapter.title}",
                    prompt = "$subjectName এর '${chapter.title}' অধ্যায়ের SSC 2028 বোর্ড পরীক্ষার জন্য সবচেয়ে গুরুত্বপূর্ণ সূত্র, গাণিতিক সমাধান এবং বহুনির্বাচনী (MCQ) ও সৃজনশীল (CQ) প্রশ্নের সম্পূর্ণ গাইডলাইন পরিষ্কার পাঠ্যবইয়ের গণিত প্রতীক (√, π, ×, ÷, ±, x², x³) সহ বাংলায় বিস্তারিত বুঝিয়ে দিন।"
                )
            }
        )
    }

    // Note Editor Dialog
    if (editingChapterNote != null) {
        val (id, note) = editingChapterNote!!
        ChapterNoteDialog(
            chapterTitle = editingChapterTitle,
            initialNote = note,
            onDismiss = { editingChapterNote = null },
            onSaveNote = { newNote ->
                viewModel.saveChapterNote(id, newNote)
                editingChapterNote = null
            }
        )
    }

    // Reset Confirmation Dialog
    if (showResetConfirmationDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmationDialog = false },
            containerColor = Color(0xFF131D2E),
            icon = {
                Icon(Icons.Default.Warning, contentDescription = "Warning", tint = NeonPink, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "গণিত অগ্রগতি রিসেট নিশ্চিতকরণ",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontFamily = HindSiliguriFontFamily
                )
            },
            text = {
                Text(
                    text = "আপনি কি সাধারণ গণিত (১৭টি) ও উচ্চতর গণিতের (১৪টি) সমাপ্তি ট্র্যাকিং সম্পূর্ণ রিসেট করতে চান? আপনার সংরক্ষিত ব্যক্তিগত নোটগুলি মুছে যাবে না।",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    fontFamily = HindSiliguriFontFamily
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetMathProgress()
                        showResetConfirmationDialog = false
                        Toast.makeText(context, "গণিতের সমাপ্তি অগ্রগতি সফলভাবে রিসেট করা হয়েছে!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink)
                ) {
                    Text("হ্যাঁ, রিসেট করুন", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = HindSiliguriFontFamily)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmationDialog = false }) {
                    Text("বাতিল", color = TextSecondary, fontFamily = HindSiliguriFontFamily)
                }
            }
        )
    }

    // Quick AI Explanation Dialog
    QuickExplanationDialog(
        title = quickExplainTitle,
        content = quickExplainContent,
        isLoading = isQuickExplainLoading,
        onDismiss = { viewModel.closeQuickExplanation() }
    )
}

/**
 * Modern premium education dashboard card showing overall & subject-wise metrics
 */
@Composable
private fun MathHeroDashboardCard(
    metrics: com.example.data.model.MathPriorityMetrics,
    totalFiltered: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E33)),
        border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.6f), NeonPurple.copy(alpha = 0.6f))))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color(0xFF0284C7), Color(0xFF0369A1)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = "Math",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "গণিত প্রস্তুতি অগ্রগতি",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontFamily = HindSiliguriFontFamily
                        )
                        Text(
                            text = "মোট সম্পন্ন: ${metrics.totalCompleted} / ${metrics.totalChapters} (${metrics.totalPercent}%)",
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonCyan,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }

                // Overall Percentage Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF064E3B))
                        .border(1.dp, Color(0xFF10B981), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${metrics.totalPercent}%",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF34D399)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Progress Bar
            LinearProgressIndicator(
                progress = { metrics.totalPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = NeonCyan,
                trackColor = Color(0xFF1E293B)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Subject-wise Breakdown Rows
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // General Math Box
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0B1728))
                        .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "সাধারণ গণিত",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8),
                                fontFamily = HindSiliguriFontFamily
                            )
                            Text(
                                text = "${metrics.generalMathCompleted}/${metrics.generalMathTotal}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { metrics.generalMathPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFF38BDF8),
                            trackColor = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${metrics.generalMathPercent}% সম্পন্ন",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }

                // Higher Math Box
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0B1728))
                        .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "উচ্চতর গণিত",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFC084FC),
                                fontFamily = HindSiliguriFontFamily
                            )
                            Text(
                                text = "${metrics.higherMathCompleted}/${metrics.higherMathTotal}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { metrics.higherMathPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFFC084FC),
                            trackColor = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${metrics.higherMathPercent}% সম্পন্ন",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Priority Legend Badges Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF064E3B))
                            .border(1.dp, Color(0xFF10B981), RoundedCornerShape(8.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("⭐ গুরুত্বপূর্ণ: ২৮টি", fontSize = 10.sp, color = Color(0xFF34D399), fontWeight = FontWeight.Bold, fontFamily = HindSiliguriFontFamily)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF3B0764))
                            .border(1.dp, Color(0xFFA855F7), RoundedCornerShape(8.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("☆ সাধারণ: ৩টি", fontSize = 10.sp, color = Color(0xFFE9D5FF), fontWeight = FontWeight.Bold, fontFamily = HindSiliguriFontFamily)
                    }
                }

                Text(
                    text = "মোট ৩১ অধ্যায়",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary,
                    fontSize = 11.sp,
                    fontFamily = HindSiliguriFontFamily
                )
            }
        }
    }
}

/**
 * Chapter Item Card with Priority Badge, Number, Completion Checkbox
 */
@Composable
private fun MathChapterCard(
    chapter: ChapterInfo,
    subjectId: String,
    isCompleted: Boolean,
    hasNote: Boolean,
    onToggleComplete: () -> Unit,
    onClick: () -> Unit
) {
    val isGenMath = subjectId == "general_math"
    val subjectLabel = if (isGenMath) "সাধারণ গণিত" else "উচ্চতর গণিত"
    val subjectBadgeColor = if (isGenMath) Color(0xFF0284C7) else Color(0xFF7C3AED)

    val priorityTag = chapter.importanceTag
    val (badgeBg, badgeBorder, badgeText, badgeLabel) = when (priorityTag) {
        "⭐" -> Quadruple(Color(0xFF064E3B), Color(0xFF10B981), Color(0xFF34D399), "⭐ গুরুত্বপূর্ণ")
        "☆" -> Quadruple(Color(0xFF3B0764), Color(0xFFA855F7), Color(0xFFE9D5FF), "☆ সাধারণ")
        else -> Quadruple(Color(0xFF451A03), Color(0xFFF59E0B), Color(0xFFFDE68A), "🟡 স্বল্প অগ্রাধিকার")
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("math_chapter_card_${subjectId}_${chapter.number}")
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) Color(0xFF0B2129) else Color(0xFF0F1E33)
        ),
        border = BorderStroke(
            1.dp,
            if (isCompleted) NeonCyan.copy(alpha = 0.5f) else Color(0xFF1E3A5F)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Chapter Number Badge
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (isCompleted) NeonCyan else Color(0xFF162A45))
                    .border(1.dp, if (isCompleted) NeonCyan else Color(0xFF2B4C77), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = String.format("%02d", chapter.number),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isCompleted) Color(0xFF021722) else Color(0xFFE2E8F0)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Chapter Title & Topic Information
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Priority Badge (Green ⭐ or Purple ☆)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(badgeBg)
                            .border(0.8.dp, badgeBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badgeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = badgeText,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }

                    // Subject Tag
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(subjectBadgeColor.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = subjectLabel,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isGenMath) Color(0xFF7DD3FC) else Color(0xFFD8B4FE),
                            fontFamily = HindSiliguriFontFamily
                        )
                    }

                    if (hasNote) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Has Note",
                            tint = AmberGold,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Chapter Name
                Text(
                    text = chapter.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isCompleted) Color(0xFFE2E8F0) else TextPrimary,
                    fontSize = 15.sp,
                    fontFamily = HindSiliguriFontFamily
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Key topics summary
                Text(
                    text = chapter.keyTopics,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 1,
                    fontSize = 12.sp,
                    fontFamily = HindSiliguriFontFamily
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Completion Checkbox Button (48.dp minimum accessibility target)
            IconButton(
                onClick = onToggleComplete,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("math_chapter_checkbox_${subjectId}_${chapter.number}")
            ) {
                if (isCompleted) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Completed",
                        tint = NeonCyan,
                        modifier = Modifier.size(26.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Incomplete",
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    }
}

/**
 * Chapter Detail Modal Dialog
 */
@Composable
private fun MathChapterDetailDialog(
    chapter: ChapterInfo,
    subjectName: String,
    isCompleted: Boolean,
    note: String,
    onDismiss: () -> Unit,
    onToggleComplete: () -> Unit,
    onEditNote: () -> Unit,
    onAskAi: () -> Unit
) {
    val priorityTag = chapter.importanceTag
    val (badgeBg, badgeBorder, badgeText, badgeLabel) = when (priorityTag) {
        "⭐" -> Quadruple(Color(0xFF064E3B), Color(0xFF10B981), Color(0xFF34D399), "⭐ অত্যন্ত গুরুত্বপূর্ণ অধ্যায়")
        "☆" -> Quadruple(Color(0xFF3B0764), Color(0xFFA855F7), Color(0xFFE9D5FF), "☆ সাধারণ অধ্যায়")
        else -> Quadruple(Color(0xFF451A03), Color(0xFFF59E0B), Color(0xFFFDE68A), "🟡 স্বল্প অগ্রাধিকার অধ্যায়")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F1E33),
        title = {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$subjectName: অধ্যায় ${chapter.number}",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontFamily = HindSiliguriFontFamily
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(badgeBg)
                            .border(0.8.dp, badgeBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = badgeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = badgeText,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = chapter.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontFamily = HindSiliguriFontFamily
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Key Topics Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF081424))
                        .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Functions, contentDescription = "Topics", tint = NeonCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "এসএসসি ২০২৮ মূল টপিক ও সূত্রাবলি:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF93C5FD),
                                fontFamily = HindSiliguriFontFamily
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = chapter.keyTopics,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            lineHeight = 20.sp,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }

                // Completion Toggle Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isCompleted) Color(0xFF064E3B).copy(alpha = 0.3f) else Color(0xFF081424))
                        .border(1.dp, if (isCompleted) Color(0xFF10B981) else Color(0xFF1E3A5F), RoundedCornerShape(10.dp))
                        .clickable(onClick = onToggleComplete)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isCompleted) "✓ অধ্যায়টি সম্পন্ন হয়েছে" else "অধ্যায়টি এখনও অসম্পূর্ণ",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isCompleted) Color(0xFF34D399) else TextSecondary,
                        fontFamily = HindSiliguriFontFamily
                    )
                    Icon(
                        imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Status",
                        tint = if (isCompleted) Color(0xFF10B981) else Color(0xFF64748B)
                    )
                }

                // Notes Preview / Edit Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF081424))
                        .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(10.dp))
                        .clickable(onClick = onEditNote)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ব্যক্তিগত নোট:",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberGold,
                            fontWeight = FontWeight.Bold,
                            fontFamily = HindSiliguriFontFamily
                        )
                        Text(
                            text = if (note.isBlank()) "কোনো নোট লেখা নেই (ক্লিক করে লিখুন)" else note,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (note.isBlank()) TextTertiary else TextPrimary,
                            maxLines = 2,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                    Icon(Icons.Default.Edit, contentDescription = "Edit Note", tint = AmberGold)
                }

                // Ask AI Button
                Button(
                    onClick = onAskAi,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = "AI", tint = Color(0xFF031A24))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI-এর কাছে এই অধ্যায়টি শিখুন",
                        color = Color(0xFF031A24),
                        fontWeight = FontWeight.Bold,
                        fontFamily = HindSiliguriFontFamily
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("বন্ধ করুন", color = NeonCyan, fontWeight = FontWeight.Bold, fontFamily = HindSiliguriFontFamily)
            }
        }
    )
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
