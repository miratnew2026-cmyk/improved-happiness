package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AgentAccount
import com.example.data.model.McqQuestionRecord
import com.example.data.model.McqUploadRecord
import com.example.data.model.QuizCollectionRecord
import com.example.data.model.QuizModeType
import com.example.data.model.SscSyllabusData
import com.example.ui.components.CyberCard
import com.example.ui.components.TextbookMathFormatter
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
internal fun agentFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedBorderColor = NeonCyan,
    unfocusedBorderColor = BorderGlow,
    focusedContainerColor = DarkBg,
    unfocusedContainerColor = DarkBg,
    focusedLabelColor = NeonCyan,
    unfocusedLabelColor = TextSecondary
)

@Composable
fun SubjectChapterSelectorRow(
    selectedSubjectId: String,
    selectedChapterNumber: Int,
    onSelectSubject: (String) -> Unit,
    onSelectChapter: (Int) -> Unit
) {
    val subject = SscSyllabusData.getSubject(selectedSubjectId) ?: SscSyllabusData.subjects.first()

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "বিষয় নির্বাচন:",
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SscSyllabusData.subjects.forEach { sub ->
                val sel = sub.id == selectedSubjectId
                FilterChip(
                    selected = sel,
                    onClick = { onSelectSubject(sub.id) },
                    modifier = Modifier.heightIn(min = 48.dp),
                    label = { Text(sub.nameBn) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonCyan.copy(alpha = 0.22f),
                        selectedLabelColor = NeonCyan,
                        containerColor = DarkSurfaceVariant,
                        labelColor = TextSecondary
                    )
                )
            }
        }

        Text(
            text = "${subject.nameBn} — অধ্যায়:",
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            subject.chapters.forEach { ch ->
                val sel = ch.number == selectedChapterNumber
                FilterChip(
                    selected = sel,
                    onClick = { onSelectChapter(ch.number) },
                    modifier = Modifier.heightIn(min = 48.dp),
                    label = { Text("${ch.number}. ${ch.title}") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonPurple.copy(alpha = 0.25f),
                        selectedLabelColor = NeonPurple,
                        containerColor = DarkSurfaceVariant,
                        labelColor = TextSecondary
                    )
                )
            }
        }
    }
}

@Composable
fun AgentOcrUploadTab(
    uploads: List<McqUploadRecord>,
    isBusy: Boolean,
    onUploadImage: (uri: Uri, subjectId: String, chapterNumber: Int) -> Unit,
    onUploadPdf: (uri: Uri, subjectId: String, chapterNumber: Int) -> Unit
) {
    var selectedSubjectId by remember { mutableStateOf("general_math") }
    var selectedChapterNumber by remember { mutableIntStateOf(1) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onUploadImage(uri, selectedSubjectId, selectedChapterNumber)
        }
    }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onUploadPdf(uri, selectedSubjectId, selectedChapterNumber)
        }
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            CyberCard(
                borderBrush = Brush.horizontalGradient(listOf(NeonCyan, NeonPurple)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "বইয়ের ছবি / PDF প্রশ্নপত্র OCR আপলোড",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Android Photo Picker ও PDF সিলেক্টর থেকে ফাইল বেছে নিন। OCR প্রশ্ন সরাসরি প্রকাশিত হবে না — প্রথমে 'রিভিউ কিউ'-তে জমা থাকবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = AmberGold,
                        lineHeight = 18.sp
                    )

                    SubjectChapterSelectorRow(
                        selectedSubjectId = selectedSubjectId,
                        selectedChapterNumber = selectedChapterNumber,
                        onSelectSubject = {
                            selectedSubjectId = it
                            selectedChapterNumber = SscSyllabusData.getSubject(it)?.chapters?.firstOrNull()?.number ?: 1
                        },
                        onSelectChapter = { selectedChapterNumber = it }
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                imagePickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp)
                                .testTag("upload_mcq_image_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = "Upload MCQ Image",
                                tint = Color(0xFF031A24)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ছবি OCR",
                                color = Color(0xFF031A24),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { pdfPickerLauncher.launch(arrayOf("application/pdf")) },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp)
                                .testTag("upload_mcq_pdf_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = "Upload PDF",
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "PDF প্রশ্ন OCR",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "সাম্প্রতিক OCR আপলোড তালিকা (${uploads.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        if (uploads.isEmpty()) {
            item {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "এখনো কোনো ছবি বা PDF আপলোড করা হয়নি।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        } else {
            items(uploads, key = { it.id }) { upload ->
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = upload.fileName,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${upload.subjectName} • ${upload.chapterTitle} • ${upload.extractedCount} প্রশ্ন",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(DarkSurfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (upload.fileType == "pdf") "PDF" else "IMG",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
fun AgentReviewQueueTab(
    pendingMcqs: List<McqQuestionRecord>,
    isBusy: Boolean,
    onApproveAndSave: (
        original: McqQuestionRecord,
        subjectId: String,
        chapterNumber: Int,
        question: String,
        options: List<String>,
        correctIndex: Int,
        explanation: String,
        difficulty: String,
        publishNow: Boolean
    ) -> Unit,
    onDeletePending: (String) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF281912)),
                border = BorderStroke(1.dp, AmberGold),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "বাধ্যতামূলক এজেন্ট রিভিউ গেট: OCR থেকে প্রাপ্ত প্রশ্ন যাচাই ও ত্রুটি সংশোধন না করে কখনোই পাবলিশ করা যাবে না (${pendingMcqs.size}টি অপেক্ষমাণ)।",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    modifier = Modifier.padding(12.dp),
                    lineHeight = 19.sp
                )
            }
        }

        if (pendingMcqs.isEmpty()) {
            item {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "কোনো অনির্ণীত OCR প্রশ্ন বাকি নেই। নতুন ছবি বা PDF আপলোড করলে এখানে দেখাবে।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = EmeraldSuccess,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(pendingMcqs, key = { it.id }) { mcq ->
                OcrPendingReviewCard(
                    mcq = mcq,
                    isBusy = isBusy,
                    onApproveAndSave = onApproveAndSave,
                    onDelete = { onDeletePending(mcq.id) }
                )
            }
        }
        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
private fun OcrPendingReviewCard(
    mcq: McqQuestionRecord,
    isBusy: Boolean,
    onApproveAndSave: (
        original: McqQuestionRecord,
        subjectId: String,
        chapterNumber: Int,
        question: String,
        options: List<String>,
        correctIndex: Int,
        explanation: String,
        difficulty: String,
        publishNow: Boolean
    ) -> Unit,
    onDelete: () -> Unit
) {
    var questionText by remember(mcq.id) { mutableStateOf(TextbookMathFormatter.format(mcq.question)) }
    var optA by remember(mcq.id) { mutableStateOf(TextbookMathFormatter.format(mcq.options.getOrElse(0) { "" })) }
    var optB by remember(mcq.id) { mutableStateOf(TextbookMathFormatter.format(mcq.options.getOrElse(1) { "" })) }
    var optC by remember(mcq.id) { mutableStateOf(TextbookMathFormatter.format(mcq.options.getOrElse(2) { "" })) }
    var optD by remember(mcq.id) { mutableStateOf(TextbookMathFormatter.format(mcq.options.getOrElse(3) { "" })) }
    var correctIdx by remember(mcq.id) { mutableIntStateOf(mcq.correctIndex.toInt().coerceIn(0, 3)) }
    var explanation by remember(mcq.id) { mutableStateOf(TextbookMathFormatter.format(mcq.explanation)) }
    var difficulty by remember(mcq.id) { mutableStateOf(mcq.difficulty.ifBlank { "medium" }) }
    var subjectId by remember(mcq.id) { mutableStateOf(mcq.subjectId.ifBlank { "general_math" }) }
    var chapterNum by remember(mcq.id) { mutableIntStateOf(mcq.chapterNumber.toInt().coerceAtLeast(1)) }

    CyberCard(
        borderBrush = Brush.horizontalGradient(listOf(AmberGold, NeonCyan)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "পেন্ডিং রিভিউ (${mcq.sourceType})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = AmberGold
                )
                IconButton(
                    onClick = onDelete,
                    enabled = !isBusy,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "প্রশ্ন বাদ দিন",
                        tint = NeonPink
                    )
                }
            }

            SubjectChapterSelectorRow(
                selectedSubjectId = subjectId,
                selectedChapterNumber = chapterNum,
                onSelectSubject = {
                    subjectId = it
                    chapterNum = SscSyllabusData.getSubject(it)?.chapters?.firstOrNull()?.number ?: 1
                },
                onSelectChapter = { chapterNum = it }
            )

            OutlinedTextField(
                value = questionText,
                onValueChange = { questionText = it },
                label = { Text("প্রশ্ন") },
                colors = agentFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = optA,
                onValueChange = { optA = it },
                label = { Text("অপশন (ক)") },
                colors = agentFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = optB,
                onValueChange = { optB = it },
                label = { Text("অপশন (খ)") },
                colors = agentFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = optC,
                onValueChange = { optC = it },
                label = { Text("অপশন (গ)") },
                colors = agentFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = optD,
                onValueChange = { optD = it },
                label = { Text("অপশন (ঘ)") },
                colors = agentFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("সঠিক উত্তর:", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                listOf("ক", "খ", "গ", "ঘ").forEachIndexed { idx, label ->
                    FilterChip(
                        selected = correctIdx == idx,
                        onClick = { correctIdx = idx },
                        modifier = Modifier.heightIn(min = 48.dp),
                        label = { Text(label) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("কঠিনতা:", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                listOf("easy", "medium", "hard").forEach { diff ->
                    FilterChip(
                        selected = difficulty == diff,
                        onClick = { difficulty = diff },
                        modifier = Modifier.heightIn(min = 48.dp),
                        label = { Text(diff) }
                    )
                }
            }

            OutlinedTextField(
                value = explanation,
                onValueChange = { explanation = it },
                label = { Text("ব্যাখ্যা / সমাধান") },
                colors = agentFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onApproveAndSave(
                            mcq,
                            subjectId,
                            chapterNum,
                            questionText,
                            listOf(optA, optB, optC, optD),
                            correctIdx,
                            explanation,
                            difficulty,
                            false
                        )
                    },
                    enabled = !isBusy,
                    border = BorderStroke(1.dp, NeonCyan),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = "Save draft", tint = NeonCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ড্রাফট", color = NeonCyan, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        onApproveAndSave(
                            mcq,
                            subjectId,
                            chapterNum,
                            questionText,
                            listOf(optA, optB, optC, optD),
                            correctIdx,
                            explanation,
                            difficulty,
                            true
                        )
                    },
                    enabled = !isBusy,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    modifier = Modifier
                        .weight(1.3f)
                        .heightIn(min = 48.dp)
                        .testTag("approve_publish_ocr_${mcq.id}")
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = "Approve", tint = Color(0xFF031A24), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("অনুমোদন ও পাবলিশ", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AgentQuizBuilderTab(
    reviewedMcqs: List<McqQuestionRecord>,
    quizzes: List<QuizCollectionRecord>,
    agents: List<AgentAccount>,
    isBootstrappedAdmin: Boolean,
    isBusy: Boolean,
    onSaveQuiz: (
        editingQuizId: String?,
        title: String,
        description: String,
        subjectId: String,
        chapterNumber: Int,
        quizType: String,
        difficulty: String,
        durationMinutes: Long,
        selectedMcqIds: List<String>,
        publishNow: Boolean,
        onComplete: () -> Unit
    ) -> Unit,
    onToggleQuizPublish: (QuizCollectionRecord) -> Unit,
    onDeleteQuiz: (String) -> Unit,
    onUpsertAgent: (uid: String, username: String, displayName: String, email: String, active: Boolean) -> Unit,
    onDeleteAgent: (String) -> Unit
) {
    var editingQuizId by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var subjectId by remember { mutableStateOf("general_math") }
    var chapterNum by remember { mutableIntStateOf(1) }
    var quizType by remember { mutableStateOf(QuizModeType.AGENT_UPLOADED.wireKey) }
    var difficulty by remember { mutableStateOf("mixed") }
    var durationStr by remember { mutableStateOf("10") }
    val selectedIds = remember { mutableStateListOf<String>() }

    // Agent delegation form fields (Admin only)
    var agentUidInput by remember { mutableStateOf("") }
    var agentUsernameInput by remember { mutableStateOf("") }
    var agentDisplayNameInput by remember { mutableStateOf("") }
    var agentEmailInput by remember { mutableStateOf("") }
    var agentActiveToggle by remember { mutableStateOf(true) }

    val matchingSubjectMcqs = reviewedMcqs.filter { it.subjectId == subjectId }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            CyberCard(
                borderBrush = Brush.horizontalGradient(listOf(NeonCyan, EmeraldSuccess)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (editingQuizId == null) "নতুন কুইজ তৈরি / পাবলিশ" else "কুইজ এডিট করুন",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("কুইজের শিরোনাম") },
                        colors = agentFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quiz_builder_title_input")
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("সংক্ষিপ্ত বিবরণ (ঐচ্ছিক)") },
                        colors = agentFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    SubjectChapterSelectorRow(
                        selectedSubjectId = subjectId,
                        selectedChapterNumber = chapterNum,
                        onSelectSubject = {
                            subjectId = it
                            chapterNum = SscSyllabusData.getSubject(it)?.chapters?.firstOrNull()?.number ?: 1
                        },
                        onSelectChapter = { chapterNum = it }
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = durationStr,
                            onValueChange = { durationStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("সময় (মিনিট)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = agentFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("mixed", "easy", "medium", "hard").forEach { diff ->
                            FilterChip(
                                selected = difficulty == diff,
                                onClick = { difficulty = diff },
                                modifier = Modifier.heightIn(min = 48.dp),
                                label = { Text(diff) }
                            )
                        }
                    }

                    Text(
                        text = "যাচাইকৃত MCQ থেকে প্রশ্ন বেছে নিন (${selectedIds.size}টি নির্বাচিত):",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonCyan
                    )

                    if (matchingSubjectMcqs.isEmpty()) {
                        Text(
                            text = "এই বিষয়ে এখনো কোনো যাচাইকৃত MCQ নেই। 'ম্যানুয়াল/বই' বা 'রিভিউ কিউ' থেকে প্রশ্ন যোগ করুন।",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    } else {
                        matchingSubjectMcqs.take(15).forEach { mcq ->
                            val checked = mcq.id in selectedIds
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DarkSurfaceVariant)
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { isChecked ->
                                        if (isChecked) {
                                            if (mcq.id !in selectedIds) selectedIds.add(mcq.id)
                                        } else {
                                            selectedIds.remove(mcq.id)
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = NeonCyan)
                                )
                                Text(
                                    text = TextbookMathFormatter.format(mcq.question),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    maxLines = 2,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val mins = durationStr.toLongOrNull() ?: 10L
                                onSaveQuiz(
                                    editingQuizId,
                                    title,
                                    description,
                                    subjectId,
                                    chapterNum,
                                    quizType,
                                    difficulty,
                                    mins,
                                    selectedIds.toList(),
                                    false
                                ) {
                                    editingQuizId = null
                                    title = ""
                                    description = ""
                                    selectedIds.clear()
                                }
                            },
                            enabled = !isBusy,
                            border = BorderStroke(1.dp, NeonCyan),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("save_quiz_draft_button")
                        ) {
                            Text("ড্রাফট সেভ", color = NeonCyan, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val mins = durationStr.toLongOrNull() ?: 10L
                                onSaveQuiz(
                                    editingQuizId,
                                    title,
                                    description,
                                    subjectId,
                                    chapterNum,
                                    quizType,
                                    difficulty,
                                    mins,
                                    selectedIds.toList(),
                                    true
                                ) {
                                    editingQuizId = null
                                    title = ""
                                    description = ""
                                    selectedIds.clear()
                                }
                            },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            modifier = Modifier
                                .weight(1.2f)
                                .heightIn(min = 48.dp)
                                .testTag("publish_quiz_button")
                        ) {
                            Icon(imageVector = Icons.Default.Publish, contentDescription = "Publish", tint = Color(0xFF031A24), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("পাবলিশ কুইজ", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "সংরক্ষিত কুইজ সমূহ (${quizzes.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        items(quizzes, key = { it.id }) { quiz ->
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = quiz.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${quiz.subjectName} • ${quiz.questionCount} প্রশ্ন • ${quiz.durationMinutes}মি. • ${quiz.status}",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (quiz.status == "published") EmeraldSuccess else AmberGold
                            )
                        }
                        Row {
                            IconButton(
                                onClick = {
                                    editingQuizId = quiz.id
                                    title = quiz.title
                                    description = quiz.description
                                    subjectId = quiz.subjectId.ifBlank { "general_math" }
                                    chapterNum = quiz.chapterNumber.toInt().coerceAtLeast(1)
                                    difficulty = quiz.difficulty.ifBlank { "mixed" }
                                    durationStr = quiz.durationMinutes.toString()
                                    selectedIds.clear()
                                    selectedIds.addAll(quiz.mcqIds)
                                },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Quiz", tint = NeonCyan)
                            }
                            IconButton(
                                onClick = { onDeleteQuiz(quiz.id) },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Quiz", tint = NeonPink)
                            }
                        }
                    }
                    OutlinedButton(
                        onClick = { onToggleQuizPublish(quiz) },
                        border = BorderStroke(1.dp, if (quiz.status == "published") AmberGold else EmeraldSuccess),
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(
                            text = if (quiz.status == "published") "ড্রাফটে নামান" else "পাবলিশ করুন",
                            color = if (quiz.status == "published") AmberGold else EmeraldSuccess,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Admin-only Role Delegation Section
        if (isBootstrappedAdmin) {
            item {
                CyberCard(
                    borderBrush = Brush.horizontalGradient(listOf(NeonPurple, NeonCyan)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = "RBAC", tint = NeonPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "এজেন্ট রোল ও অ্যাক্সেস নিয়ন্ত্রণ (Admin)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "Mr1122 প্রাইমারি প্রোফাইল ও অতিরিক্ত অনুমোদিত এজেন্টদের Firebase Auth UID এখানে যোগ করুন। কোনো পাসওয়ার্ড APK-তে সংরক্ষিত থাকে না।",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        OutlinedTextField(
                            value = agentUidInput,
                            onValueChange = { agentUidInput = it },
                            label = { Text("Agent Firebase UID") },
                            colors = agentFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = agentUsernameInput,
                            onValueChange = { agentUsernameInput = it },
                            label = { Text("হ্যান্ডেল / ইউজারনেম") },
                            colors = agentFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = agentDisplayNameInput,
                            onValueChange = { agentDisplayNameInput = it },
                            label = { Text("প্রদর্শন নাম") },
                            colors = agentFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = agentEmailInput,
                            onValueChange = { agentEmailInput = it },
                            label = { Text("Google ইমেইল") },
                            colors = agentFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("সক্রিয় অ্যাক্সেস", color = TextPrimary)
                            Switch(checked = agentActiveToggle, onCheckedChange = { agentActiveToggle = it })
                        }
                        Button(
                            onClick = {
                                onUpsertAgent(
                                    agentUidInput,
                                    agentUsernameInput,
                                    agentDisplayNameInput,
                                    agentEmailInput,
                                    agentActiveToggle
                                )
                                agentUidInput = ""
                                agentUsernameInput = ""
                                agentDisplayNameInput = ""
                                agentEmailInput = ""
                            },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("save_agent_role_button")
                        ) {
                            Text("এজেন্ট অনুমতি সেভ করুন", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        agents.forEach { agent ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DarkSurfaceVariant)
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${agent.displayName} (@${agent.username})",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "${agent.email} • Active: ${agent.active}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteAgent(agent.uid) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove Agent", tint = NeonPink)
                                }
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}
