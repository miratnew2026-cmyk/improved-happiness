package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.data.ai.OcrQuestionExtractor
import com.example.data.remote.QuizAgentRepository
import com.example.ui.screens.AgentPanelScreen
import com.example.ui.screens.AiChatScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.MathPriorityScreen
import com.example.ui.screens.PlannerGrammarScreen
import com.example.ui.screens.PracticeExamScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.SciencePriorityScreen
import com.example.ui.screens.SocialIctPriorityScreen
import com.example.ui.screens.SyllabusScreen
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextSecondary
import com.example.util.attemptAutoSignIn
import com.example.util.authStateFlow
import com.example.util.isBootstrappedAdminEmail
import com.example.util.onGoogleSignInClicked
import com.example.util.signOutFromGoogle
import com.example.viewmodel.AgentViewModel
import com.example.viewmodel.GuestQuizViewModel
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.QuizController
import com.example.viewmodel.QuizViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow

enum class AppScreen(val route: String, val title: String, val icon: ImageVector) {
    DASHBOARD("dashboard", "হোম", Icons.Default.Dashboard),
    SYLLABUS("syllabus", "সিলেবাস", Icons.AutoMirrored.Filled.MenuBook),
    QUIZ("quiz", "QUIZ", Icons.Default.Quiz),
    AI_CHAT("ai_chat", "MRH AI", Icons.Default.AutoAwesome),
    PRACTICE("practice", "অনুশীলন", Icons.AutoMirrored.Filled.Assignment),
    PLANNER("planner", "প্ল্যানার", Icons.Default.CalendarMonth)
}

private class AuthenticatedControllers(
    val quizViewModel: QuizViewModel,
    val agentViewModel: AgentViewModel
)

@Composable
fun AppNavigation() {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val authScope = rememberCoroutineScope()

    val authFlow = remember { Firebase.auth.authStateFlow() }
    val currentUser by authFlow.collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

    // Non-blocking background silent sign-in if previously authorized; never blocks cold-start entry
    LaunchedEffect(Unit) {
        if (Firebase.auth.currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onUnauthenticated = {},
                scope = authScope
            )
        }
    }

    val mainViewModel: MainViewModel = viewModel()
    val guestQuizViewModel: GuestQuizViewModel = viewModel()

    var currentScreen by remember { mutableStateOf(AppScreen.DASHBOARD) }
    var chatInitialPrompt by remember { mutableStateOf<String?>(null) }
    var showingMathPriority by remember { mutableStateOf(false) }
    var showingSciencePriority by remember { mutableStateOf(false) }
    var showingSocialIctPriority by remember { mutableStateOf(false) }
    var showingAgentPanel by remember { mutableStateOf(false) }

    var isSigningInInline by remember { mutableStateOf(false) }
    var inlineAuthError by remember { mutableStateOf<String?>(null) }

    // Firestore-backed repositories/controllers are ONLY instantiated when authenticated
    val authControllers: AuthenticatedControllers? = currentUser?.let { user ->
        key(user.uid) {
            val quizRepository = remember(user.uid, appContext) {
                val dbId = appContext.getString(R.string.firestore_database_id)
                QuizAgentRepository(db = FirebaseFirestore.getInstance(dbId))
            }
            val ocrExtractor = remember(user.uid, appContext) {
                OcrQuestionExtractor(appContext)
            }
            val quizViewModel: QuizViewModel = viewModel(
                key = "quiz_${user.uid}",
                factory = viewModelFactory {
                    initializer {
                        QuizViewModel(
                            repository = quizRepository,
                            currentUserId = user.uid
                        )
                    }
                }
            )
            val agentViewModel: AgentViewModel = viewModel(
                key = "agent_${user.uid}",
                factory = viewModelFactory {
                    initializer {
                        AgentViewModel(
                            repository = quizRepository,
                            ocrExtractor = ocrExtractor,
                            currentUserId = user.uid,
                            currentUserEmail = user.email.orEmpty(),
                            currentDisplayName = user.displayName.orEmpty(),
                            isBootstrappedAdmin = user.isBootstrappedAdminEmail()
                        )
                    }
                }
            )
            AuthenticatedControllers(
                quizViewModel = quizViewModel,
                agentViewModel = agentViewModel
            )
        }
    }

    val emptyAgentFlow = remember { MutableStateFlow(false) }
    val isAgentAccess by (authControllers?.agentViewModel?.isAuthorizedAgent ?: emptyAgentFlow)
        .collectAsStateWithLifecycle()

    val activeQuizController: QuizController = authControllers?.quizViewModel ?: guestQuizViewModel

    val triggerGoogleSignIn: () -> Unit = {
        if (!isSigningInInline) {
            isSigningInInline = true
            inlineAuthError = null
            onGoogleSignInClicked(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {
                    isSigningInInline = false
                    inlineAuthError = null
                },
                onAuthError = { msg ->
                    isSigningInInline = false
                    inlineAuthError = msg
                },
                onAuthCancelled = {
                    isSigningInInline = false
                },
                scope = authScope
            )
        }
    }

    val selectScreen: (AppScreen) -> Unit = { screen ->
        if (screen != AppScreen.AI_CHAT) {
            chatInitialPrompt = null
        }
        currentScreen = screen
    }

    when {
        showingAgentPanel -> {
            if (authControllers != null) {
                BackHandler { showingAgentPanel = false }
                AgentPanelScreen(
                    agentViewModel = authControllers.agentViewModel,
                    onSwitchAccount = {
                        signOutFromGoogle(
                            credentialManager = credentialManager,
                            scope = authScope
                        )
                    },
                    onBack = { showingAgentPanel = false }
                )
            } else {
                AuthScreen(
                    showBackButton = true,
                    onBack = { showingAgentPanel = false },
                    onAuthenticated = { launchAgentPanel ->
                        if (launchAgentPanel) {
                            showingAgentPanel = true
                        }
                    }
                )
            }
        }

        showingMathPriority -> {
            BackHandler { showingMathPriority = false }
            MathPriorityScreen(
                viewModel = mainViewModel,
                onBack = { showingMathPriority = false },
                onAskAi = { prompt ->
                    chatInitialPrompt = prompt
                    currentScreen = AppScreen.AI_CHAT
                    showingMathPriority = false
                }
            )
        }

        showingSciencePriority -> {
            BackHandler { showingSciencePriority = false }
            SciencePriorityScreen(
                viewModel = mainViewModel,
                onBack = { showingSciencePriority = false },
                onAskAi = { prompt ->
                    chatInitialPrompt = prompt
                    currentScreen = AppScreen.AI_CHAT
                    showingSciencePriority = false
                }
            )
        }

        showingSocialIctPriority -> {
            BackHandler { showingSocialIctPriority = false }
            SocialIctPriorityScreen(
                viewModel = mainViewModel,
                onBack = { showingSocialIctPriority = false },
                onAskAi = { prompt ->
                    chatInitialPrompt = prompt
                    currentScreen = AppScreen.AI_CHAT
                    showingSocialIctPriority = false
                }
            )
        }

        else -> {
            if (currentScreen != AppScreen.DASHBOARD) {
                BackHandler { currentScreen = AppScreen.DASHBOARD }
            }

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBg)
            ) {
                val useNavigationRail = maxWidth >= 600.dp

                val destinationContent: @Composable (Modifier) -> Unit = { contentModifier ->
                    Box(modifier = contentModifier.fillMaxSize()) {
                        when (currentScreen) {
                            AppScreen.DASHBOARD -> DashboardScreen(
                                viewModel = mainViewModel,
                                onNavigateToAiChat = { prompt ->
                                    chatInitialPrompt = prompt
                                    currentScreen = AppScreen.AI_CHAT
                                },
                                onNavigateToSyllabus = { currentScreen = AppScreen.SYLLABUS },
                                onNavigateToExam = { currentScreen = AppScreen.PRACTICE },
                                onNavigateToPlanner = { currentScreen = AppScreen.PLANNER },
                                onNavigateToMathPriority = { showingMathPriority = true },
                                onNavigateToSciencePriority = { showingSciencePriority = true },
                                onNavigateToSocialIctPriority = { showingSocialIctPriority = true },
                                onNavigateToQuiz = { currentScreen = AppScreen.QUIZ },
                                onNavigateToAgentPanel = { showingAgentPanel = true }
                            )
                            AppScreen.SYLLABUS -> SyllabusScreen(
                                viewModel = mainViewModel,
                                onAskAiAboutChapter = { prompt ->
                                    chatInitialPrompt = prompt
                                    currentScreen = AppScreen.AI_CHAT
                                },
                                onNavigateToMathPriority = { showingMathPriority = true },
                                onNavigateToSciencePriority = { showingSciencePriority = true },
                                onNavigateToSocialIctPriority = { showingSocialIctPriority = true }
                            )
                            AppScreen.QUIZ -> QuizScreen(
                                quizController = activeQuizController,
                                isAuthenticated = currentUser != null,
                                isSigningIn = isSigningInInline,
                                userEmail = currentUser?.email.orEmpty(),
                                isAgentAccess = isAgentAccess,
                                externalBannerError = inlineAuthError,
                                onDismissExternalError = { inlineAuthError = null },
                                onGoogleSignIn = triggerGoogleSignIn,
                                onOpenAgentPanel = { showingAgentPanel = true },
                                onSignOut = {
                                    signOutFromGoogle(
                                        credentialManager = credentialManager,
                                        scope = authScope
                                    )
                                },
                                onRecordMistake = { subjectName, chapterTitle, question, studentAns, correctAns, explanation ->
                                    mainViewModel.recordQuizMistake(
                                        subjectName = subjectName,
                                        chapterTitle = chapterTitle,
                                        question = question,
                                        studentAnswer = studentAns,
                                        correctAnswer = correctAns,
                                        explanation = explanation
                                    )
                                }
                            )
                            AppScreen.AI_CHAT -> AiChatScreen(
                                viewModel = mainViewModel,
                                initialPrompt = chatInitialPrompt
                            )
                            AppScreen.PRACTICE -> PracticeExamScreen(
                                viewModel = mainViewModel
                            )
                            AppScreen.PLANNER -> PlannerGrammarScreen(
                                viewModel = mainViewModel
                            )
                        }
                    }
                }

                if (useNavigationRail) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .safeDrawingPadding()
                    ) {
                        NavigationRail(
                            containerColor = DarkSurface,
                            modifier = Modifier
                                .fillMaxHeight()
                                .border(width = 0.5.dp, color = BorderGlow)
                        ) {
                            Spacer(modifier = Modifier.weight(1f))
                            AppScreen.entries.forEach { screen ->
                                val isSelected = currentScreen == screen
                                val isAi = screen == AppScreen.AI_CHAT
                                NavigationRailItem(
                                    selected = isSelected,
                                    onClick = { selectScreen(screen) },
                                    modifier = Modifier.testTag("nav_tab_${screen.route}"),
                                    icon = {
                                        NavTabIcon(screen = screen, isSelected = isSelected, isAi = isAi)
                                    },
                                    label = {
                                        Text(
                                            text = screen.title,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) NeonCyan else TextSecondary,
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Ellipsis,
                                            fontSize = 11.sp
                                        )
                                    },
                                    colors = NavigationRailItemDefaults.colors(
                                        indicatorColor = Color.Transparent
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.width(1.dp))
                        destinationContent(Modifier.weight(1f))
                    }
                } else {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = DarkBg,
                        bottomBar = {
                            NavigationBar(
                                containerColor = DarkSurface,
                                tonalElevation = 8.dp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(width = 0.5.dp, color = BorderGlow)
                            ) {
                                AppScreen.entries.forEach { screen ->
                                    val isSelected = currentScreen == screen
                                    val isAi = screen == AppScreen.AI_CHAT

                                    NavigationBarItem(
                                        selected = isSelected,
                                        onClick = { selectScreen(screen) },
                                        modifier = Modifier.testTag("nav_tab_${screen.route}"),
                                        icon = {
                                            NavTabIcon(screen = screen, isSelected = isSelected, isAi = isAi)
                                        },
                                        label = {
                                            Text(
                                                text = screen.title,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) NeonCyan else TextSecondary,
                                                maxLines = 1,
                                                softWrap = false,
                                                overflow = TextOverflow.Ellipsis,
                                                fontSize = 10.sp
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            indicatorColor = Color.Transparent
                                        )
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        destinationContent(Modifier.padding(innerPadding))
                    }
                }
            }
        }
    }
}

@Composable
private fun NavTabIcon(
    screen: AppScreen,
    isSelected: Boolean,
    isAi: Boolean
) {
    if (isAi) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(if (isSelected) NeonCyan else Color(0xFF1E293B)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = screen.icon,
                contentDescription = screen.title,
                tint = if (isSelected) Color(0xFF031A24) else NeonCyan,
                modifier = Modifier.size(18.dp)
            )
        }
    } else {
        Icon(
            imageVector = screen.icon,
            contentDescription = screen.title,
            tint = if (isSelected) NeonCyan else TextSecondary
        )
    }
}
