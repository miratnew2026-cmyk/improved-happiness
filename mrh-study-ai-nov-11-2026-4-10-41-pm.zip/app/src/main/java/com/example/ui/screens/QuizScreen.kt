package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.QuizAttemptRecord
import com.example.data.model.QuizCollectionRecord
import com.example.data.model.QuizModeType
import com.example.data.model.RemoteUiState
import com.example.data.model.SscSyllabusData
import com.example.ui.components.CyberCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.QuizController

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuizScreen(
    quizController: QuizController,
    isAuthenticated: Boolean,
    isSigningIn: Boolean,
    userEmail: String,
    isAgentAccess: Boolean,
    externalBannerError: String?,
    onDismissExternalError: () -> Unit,
    onGoogleSignIn: () -> Unit,
    onOpenAgentPanel: () -> Unit,
    onSignOut: () -> Unit,
    onRecordMistake: (
        subjectName: String,
        chapterTitle: String,
        question: String,
        studentAnswer: String,
        correctAnswer: String,
        explanation: String
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectionState by quizController.selectionState.collectAsStateWithLifecycle()
    val sessionState by quizController.sessionState.collectAsStateWithLifecycle()
    val publishedQuizzesState by quizController.publishedQuizzes.collectAsStateWithLifecycle()
    val publishedMcqsState by quizController.publishedMcqs.collectAsStateWithLifecycle()
    val myAttemptsState by quizController.myAttempts.collectAsStateWithLifecycle()

    var inspectingAttempt by remember { mutableStateOf<QuizAttemptRecord?>(null) }
    var showSignOutConfirm by remember { mutableStateOf(false) }

    // If a quiz session is active, show full interactive QuizRunner
    if (sessionState.isActive) {
        QuizActiveRunnerScreen(
            session = sessionState,
            onSelectAnswer = { qIdx, oIdx -> quizController.selectAnswer(qIdx, oIdx) },
            onGoToQuestion = { idx -> quizController.goToQuestion(idx) },
            onPreviousQuestion = { quizController.previousQuestion() },
            onNextQuestion = { quizController.nextQuestion() },
            onSubmitQuiz = { quizController.submitActiveQuiz(onRecordMistake) },
            onCloseSession = { quizController.closeSession() }
        )
        return
    }

    val selectedSubject = SscSyllabusData.getSubject(selectionState.selectedSubjectId)
        ?: SscSyllabusData.subjects.first()

    // Trigger recomposition when publishedMcqs loads so badges update dynamically
    val publishedMcqCount = (publishedMcqsState as? RemoteUiState.Success)?.data?.size ?: 0

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 820.dp)
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "SSC 2028 কুইজ ও পরীক্ষা",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = if (isAuthenticated) {
                                "${userEmail.ifBlank { "Google সাইন-ইন সক্রিয়" }} • এজেন্ট MCQ: $publishedMcqCount টি"
                            } else {
                                "অফলাইন ও বইয়ের MCQ মোড (ক্লাউড সিঙ্ক অফলাইন)"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isAuthenticated) NeonCyan else AmberGold,
                            maxLines = 1
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = onOpenAgentPanel,
                            border = BorderStroke(
                                1.2.dp,
                                if (isAuthenticated && isAgentAccess) EmeraldSuccess else NeonPurple
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("open_agent_panel_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Agent Panel",
                                tint = if (isAuthenticated && isAgentAccess) EmeraldSuccess else NeonPurple,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "এজেন্ট প্যানেল",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                        if (isAuthenticated) {
                            Spacer(modifier = Modifier.width(4.dp))
                            IconButton(
                                onClick = { showSignOutConfirm = true },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("sign_out_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = "সাইন আউট",
                                    tint = TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            // Dismissible Banner Notice
            val activeBanner = externalBannerError?.takeIf { it.isNotBlank() }
                ?: selectionState.bannerMessage?.takeIf { it.isNotBlank() }
            if (activeBanner != null) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quiz_banner_notice"),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF281912)),
                        border = BorderStroke(1.dp, AmberGold.copy(alpha = 0.7f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = "Notice",
                                tint = AmberGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = activeBanner,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = {
                                    quizController.clearBannerMessage()
                                    onDismissExternalError()
                                },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text("ঠিক আছে", color = AmberGold, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Quiz Modes Selector Grid (All 8 Modes)
            item {
                CyberCard(
                    borderBrush = Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.6f), NeonPurple.copy(alpha = 0.6f))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "কুইজের ধরন বেছে নিন",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        val modeRows = QuizModeType.entries.chunked(2)
                        modeRows.forEach { pair ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                pair.forEach { mode ->
                                    val isSelected = selectionState.selectedMode == mode
                                    val accent = modeAccentColor(mode)
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 68.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { quizController.selectMode(mode) }
                                            .testTag("quiz_mode_${mode.wireKey}"),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) Color(0xFF0E293D) else DarkSurfaceVariant
                                        ),
                                        border = BorderStroke(
                                            width = if (isSelected) 1.5.dp else 1.dp,
                                            color = if (isSelected) accent else BorderGlow
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(CircleShape)
                                                    .background(accent.copy(alpha = 0.18f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = modeIcon(mode),
                                                    contentDescription = mode.labelBn,
                                                    tint = accent,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = mode.labelBn,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isSelected) accent else TextPrimary,
                                                    maxLines = 1
                                                )
                                                Text(
                                                    text = mode.subtitleBn,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = TextSecondary,
                                                    fontSize = 10.sp,
                                                    maxLines = 2,
                                                    lineHeight = 13.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Subject, Chapter & Parameter Selector Card
            item {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "বিষয় ও অধ্যায় নির্বাচন (১২টি বিষয়)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        // Subject Horizontal Selector
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SscSyllabusData.subjects.forEach { subject ->
                                val isSel = subject.id == selectionState.selectedSubjectId
                                val totalAvail = quizController.availableBookCountForSubject(subject.id) +
                                    quizController.availablePublishedAgentCountForSubject(subject.id)
                                FilterChip(
                                    selected = isSel,
                                    onClick = { quizController.selectSubject(subject.id) },
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("quiz_subject_${subject.id}"),
                                    label = {
                                        Text(
                                            text = "${subject.nameBn} ($totalAvail)",
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                        selectedLabelColor = NeonCyan,
                                        containerColor = DarkSurfaceVariant,
                                        labelColor = TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = isSel,
                                        borderColor = BorderGlow,
                                        selectedBorderColor = NeonCyan
                                    )
                                )
                            }
                        }

                        // Chapter Horizontal Selector (hidden if FULL_SUBJECT or RANDOM, otherwise helpful)
                        if (selectionState.selectedMode != QuizModeType.FULL_SUBJECT &&
                            selectionState.selectedMode != QuizModeType.RANDOM
                        ) {
                            Text(
                                text = "${selectedSubject.nameBn} — অধ্যায় ফিল্টার",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = selectionState.selectedChapterNumber == null,
                                    onClick = { quizController.selectChapter(null) },
                                    modifier = Modifier.heightIn(min = 48.dp),
                                    label = { Text("সব অধ্যায়") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NeonPurple.copy(alpha = 0.25f),
                                        selectedLabelColor = NeonPurple,
                                        containerColor = DarkSurfaceVariant,
                                        labelColor = TextSecondary
                                    )
                                )
                                selectedSubject.chapters.forEach { ch ->
                                    val chCount = quizController.availableCountForChapter(selectedSubject.id, ch.number)
                                    val isChSel = selectionState.selectedChapterNumber == ch.number
                                    FilterChip(
                                        selected = isChSel,
                                        onClick = { quizController.selectChapter(ch.number) },
                                        modifier = Modifier.heightIn(min = 48.dp),
                                        label = {
                                            Text(
                                                text = if (chCount > 0) "${ch.number}. ${ch.title} [$chCount]" else "${ch.number}. ${ch.title}"
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                            selectedLabelColor = NeonCyan,
                                            containerColor = DarkSurfaceVariant,
                                            labelColor = if (chCount > 0) TextPrimary else TextSecondary
                                        )
                                    )
                                }
                            }
                        }

                        // Question Count & Duration Chips
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf(5, 10, 15, 25).forEach { limit ->
                                val isSel = selectionState.questionLimit == limit
                                FilterChip(
                                    selected = isSel,
                                    onClick = { quizController.setQuestionLimit(limit) },
                                    modifier = Modifier.heightIn(min = 48.dp),
                                    label = { Text("$limit প্রশ্ন") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldSuccess.copy(alpha = 0.22f),
                                        selectedLabelColor = EmeraldSuccess,
                                        containerColor = DarkSurfaceVariant,
                                        labelColor = TextSecondary
                                    )
                                )
                            }
                            if (selectionState.selectedMode == QuizModeType.TIMED ||
                                selectionState.selectedMode == QuizModeType.EXAM_MODE
                            ) {
                                listOf(5, 10, 15, 25).forEach { mins ->
                                    val isSel = selectionState.customDurationMinutes == mins
                                    FilterChip(
                                        selected = isSel,
                                        onClick = { quizController.setDurationMinutes(mins) },
                                        modifier = Modifier.heightIn(min = 48.dp),
                                        label = { Text("$mins মিনিট") },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = AmberGold.copy(alpha = 0.22f),
                                            selectedLabelColor = AmberGold,
                                            containerColor = DarkSurfaceVariant,
                                            labelColor = TextSecondary
                                        )
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = { quizController.startConfiguredQuiz() },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 50.dp)
                                .testTag("start_quiz_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "শুরু করুন",
                                tint = Color(0xFF031A24),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${selectionState.selectedMode.labelBn} শুরু করুন",
                                color = Color(0xFF031A24),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }

            // Agent Published Quizzes Collection Feed
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Agent Quizzes",
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "এজেন্ট কর্তৃক প্রকাশিত কুইজ",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }
            }

            if (!isAuthenticated) {
                item {
                    CyberCard(
                        borderBrush = Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.65f), NeonPurple.copy(alpha = 0.65f))),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CloudDone,
                                    contentDescription = "Cloud Sync",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ক্লাউড কুইজ ও এজেন্ট আপলোড (ঐচ্ছিক)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }
                            Text(
                                text = "বইয়ের MCQ, র‍্যান্ডম, অধ্যায়ভিত্তিক ও টাইমড কুইজ এখনই সাইন-ইন ছাড়াই খেলতে পারবেন। এজেন্ট কর্তৃক প্রকাশিত নতুন কুইজ ও ক্লাউড স্কোর সিঙ্ক পেতে Google দিয়ে সাইন-ইন করুন।",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                lineHeight = 19.sp
                            )
                            Button(
                                onClick = onGoogleSignIn,
                                enabled = !isSigningIn,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonCyan,
                                    disabledContainerColor = DarkSurfaceVariant
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("quiz_google_sign_in_button")
                            ) {
                                if (isSigningIn) {
                                    CircularProgressIndicator(
                                        color = Color(0xFF031A24),
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "সাইন-ইন সম্পন্ন হচ্ছে...",
                                        color = Color(0xFF031A24),
                                        fontWeight = FontWeight.Bold
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.VerifiedUser,
                                        contentDescription = "Google Sign In",
                                        tint = Color(0xFF031A24),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Google দিয়ে সাইন-ইন করুন",
                                        color = Color(0xFF031A24),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                when (val quizzesState = publishedQuizzesState) {
                    is RemoteUiState.Loading -> {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(28.dp))
                            }
                        }
                    }
                    is RemoteUiState.Error -> {
                        item {
                            CyberCard(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = quizzesState.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NeonPink,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }
                    }
                    is RemoteUiState.Success -> {
                        if (quizzesState.data.isEmpty()) {
                            item {
                                CyberCard(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "এখনো কোনো বিশেষ এজেন্ট কুইজ প্রকাশিত হয়নি। এজেন্ট প্যানেল থেকে নতুন কুইজ পাবলিশ করতে পারেন অথবা উপরের 'বইয়ের MCQ' ও 'র‍্যান্ডম কুইজ' দিয়ে অনুশীলন শুরু করুন।",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        modifier = Modifier.padding(14.dp),
                                        lineHeight = 19.sp
                                    )
                                }
                            }
                        } else {
                            items(quizzesState.data, key = { it.id }) { quiz ->
                                PublishedQuizCard(
                                    quiz = quiz,
                                    onStart = { quizController.startPublishedQuizCollection(quiz) }
                                )
                            }
                        }
                    }
                }
            }

            // Recent Score & Results History Section
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "History",
                        tint = NeonPurple,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "সাম্প্রতিক স্কোর ও ফলাফল",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }

            if (!isAuthenticated) {
                item {
                    CyberCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "অফলাইন মোডে আপনার ভুল উত্তরগুলো স্বয়ংক্রিয়ভাবে 'ভুলের খাতা'-তে জমা হচ্ছে। ক্লাউডে কুইজ ইতিহাস সংরক্ষণের জন্য উপরে Google দিয়ে সাইন-ইন করুন।",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            modifier = Modifier.padding(14.dp),
                            lineHeight = 19.sp
                        )
                    }
                }
            } else {
                when (val attemptsState = myAttemptsState) {
                    is RemoteUiState.Loading -> {
                        item {
                            Text(
                                text = "ফলাফল লোড হচ্ছে...",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                    is RemoteUiState.Error -> {
                        item {
                            Text(
                                text = attemptsState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = NeonPink
                            )
                        }
                    }
                    is RemoteUiState.Success -> {
                        if (attemptsState.data.isEmpty()) {
                            item {
                                CyberCard(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "আপনার কোনো ক্লাউড কুইজ স্কোর এখনো জমা হয়নি। প্রথম কুইজ দিয়ে নিজের অগ্রগতি যাচাই করুন!",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        modifier = Modifier.padding(14.dp)
                                    )
                                }
                            }
                        } else {
                            items(attemptsState.data.take(10), key = { it.id }) { attempt ->
                                CyberCard(
                                    onClick = { inspectingAttempt = attempt },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("attempt_history_${attempt.id}")
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = attempt.quizTitle,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary
                                            )
                                            Text(
                                                text = "${attempt.subjectName} • সময়: ${attempt.timeTakenSeconds} সে." +
                                                    if (attempt.examMode) " • এক্সাম মোড" else "",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = TextSecondary
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(Color(0xFF0A2E25))
                                                .border(1.dp, EmeraldSuccess.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Text(
                                                text = "${attempt.score}/${attempt.totalQuestions} (${attempt.accuracyPercent.toInt()}%)",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = EmeraldSuccess
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }

    inspectingAttempt?.let { record ->
        QuizAttemptDetailDialog(
            attempt = record,
            onDismiss = { inspectingAttempt = null }
        )
    }

    if (showSignOutConfirm) {
        AlertDialog(
            onDismissRequest = { showSignOutConfirm = false },
            containerColor = DarkSurface,
            title = {
                Text("অ্যাকাউন্ট সাইন আউট", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "আপনি কি $userEmail থেকে সাইন আউট করতে চান?",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutConfirm = false
                        onSignOut()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink)
                ) {
                    Text("সাইন আউট", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutConfirm = false }) {
                    Text("বাতিল", color = NeonCyan)
                }
            }
        )
    }
}

@Composable
private fun PublishedQuizCard(
    quiz: QuizCollectionRecord,
    onStart: () -> Unit
) {
    CyberCard(
        borderBrush = Brush.horizontalGradient(listOf(EmeraldSuccess.copy(alpha = 0.6f), NeonCyan.copy(alpha = 0.5f))),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = quiz.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${quiz.subjectName} • ${quiz.chapterTitle}",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCyan
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${quiz.questionCount} প্রশ্ন • ${quiz.durationMinutes}মি.",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = AmberGold
                    )
                }
            }
            if (quiz.description.isNotBlank()) {
                Text(
                    text = quiz.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Button(
                onClick = onStart,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("start_agent_quiz_${quiz.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "শুরু করুন",
                    tint = Color(0xFF031A24),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "এজেন্ট কুইজ শুরু করুন (${quiz.difficulty.uppercase()})",
                    color = Color(0xFF031A24),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun modeIcon(mode: QuizModeType): ImageVector = when (mode) {
    QuizModeType.PRACTICE -> Icons.Default.CheckCircle
    QuizModeType.BOOK_MCQ -> Icons.AutoMirrored.Filled.MenuBook
    QuizModeType.AGENT_UPLOADED -> Icons.Default.VerifiedUser
    QuizModeType.RANDOM -> Icons.Default.Shuffle
    QuizModeType.CHAPTER_WISE -> Icons.Default.Quiz
    QuizModeType.FULL_SUBJECT -> Icons.Default.School
    QuizModeType.TIMED -> Icons.Default.Timer
    QuizModeType.EXAM_MODE -> Icons.Default.Bolt
}

private fun modeAccentColor(mode: QuizModeType): Color = when (mode) {
    QuizModeType.PRACTICE -> NeonCyan
    QuizModeType.BOOK_MCQ -> Color(0xFF38BDF8)
    QuizModeType.AGENT_UPLOADED -> EmeraldSuccess
    QuizModeType.RANDOM -> NeonPurple
    QuizModeType.CHAPTER_WISE -> AmberGold
    QuizModeType.FULL_SUBJECT -> Color(0xFF60A5FA)
    QuizModeType.TIMED -> NeonPink
    QuizModeType.EXAM_MODE -> Color(0xFFFB7185)
}
