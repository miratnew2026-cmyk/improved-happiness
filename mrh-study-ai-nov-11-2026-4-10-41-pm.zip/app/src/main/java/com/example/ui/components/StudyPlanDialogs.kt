package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ScheduledTaskEntity
import com.example.data.local.StudyPlanConfigEntity
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyberGradient
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

/**
 * Feature 1: Study Plan Setup Dialog
 */
@Composable
fun StudyPlanSetupDialog(
    currentConfig: StudyPlanConfigEntity?,
    onDismiss: () -> Unit,
    onGeneratePlan: (durationMonths: Int, dailyHours: Int, startDateMillis: Long, easyDays: Int, normalDays: Int, difficultDays: Int, veryDifficultDays: Int) -> Unit
) {
    var selectedDuration by remember { mutableIntStateOf(currentConfig?.durationMonths ?: 4) }
    var selectedHours by remember { mutableIntStateOf(currentConfig?.dailyStudyHours ?: 4) }
    var easyDays by remember { mutableIntStateOf(currentConfig?.easyChapterDays ?: 1) }
    var normalDays by remember { mutableIntStateOf(currentConfig?.normalChapterDays ?: 2) }
    var difficultDays by remember { mutableIntStateOf(currentConfig?.difficultChapterDays ?: 3) }
    var veryDifficultDays by remember { mutableIntStateOf(currentConfig?.veryDifficultChapterDays ?: 5) }
    var showCustomDifficulty by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = "Setup", tint = NeonCyan)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "SSC 2028 স্টাডি প্ল্যান সেটআপ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "সম্পূর্ণ ১২টি বিষয়ের অটোমেটিক ভবিষ্যৎ রুটিন",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Duration Choice
                Column {
                    Text(
                        text = "১. সিলেবাস শেষ করার সময়সীমা বেছে নিন:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            4 to "৪ মাস (১৬ সপ্তাহ)",
                            5 to "৫ মাস (২০ সপ্তাহ)",
                            6 to "৬ মাস (২৪ সপ্তাহ)"
                        ).forEach { (months, label) ->
                            val isSelected = selectedDuration == months
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) NeonCyan else DarkSurfaceVariant)
                                    .clickable { selectedDuration = months }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color(0xFF031A24) else TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // Daily Hours Choice
                Column {
                    Text(
                        text = "২. দৈনিক পড়ার সময় নির্বাচন করুন:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            4 to "৪ ঘণ্টা/দিন",
                            5 to "৫ ঘণ্টা/দিন",
                            6 to "৬ ঘণ্টা/দিন"
                        ).forEach { (hours, label) ->
                            val isSelected = selectedHours == hours
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) NeonPurple else DarkSurfaceVariant)
                                    .clickable { selectedHours = hours }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // Chapter Completion Times
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "৩. অধ্যায় সম্পন্ন করার সময় নির্ধারণ:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        TextButton(onClick = { showCustomDifficulty = !showCustomDifficulty }) {
                            Text(
                                text = if (showCustomDifficulty) "ডিফল্ট রাখো" else "কাস্টমাইজ",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonCyan
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceVariant)
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "• সহজ অধ্যায়: $easyDays দিন", style = MaterialTheme.typography.bodySmall, color = EmeraldSuccess)
                            Text(text = "• সাধারণ অধ্যায়: $normalDays দিন", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                            Text(text = "• কঠিন অধ্যায়: $difficultDays দিন", style = MaterialTheme.typography.bodySmall, color = AmberGold)
                            Text(text = "• খুব কঠিন অধ্যায়: $veryDifficultDays দিন", style = MaterialTheme.typography.bodySmall, color = NeonPink)
                        }
                    }

                    if (showCustomDifficulty) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("কঠিন অধ্যায় দিন:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { if (difficultDays > 1) difficultDays-- }) { Text("-", color = NeonCyan, fontSize = 18.sp) }
                                    Text("$difficultDays", color = TextPrimary, fontWeight = FontWeight.Bold)
                                    IconButton(onClick = { if (difficultDays < 7) difficultDays++ }) { Text("+", color = NeonCyan, fontSize = 18.sp) }
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("খুব কঠিন দিন:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { if (veryDifficultDays > 2) veryDifficultDays-- }) { Text("-", color = NeonPink, fontSize = 18.sp) }
                                    Text("$veryDifficultDays", color = TextPrimary, fontWeight = FontWeight.Bold)
                                    IconButton(onClick = { if (veryDifficultDays < 10) veryDifficultDays++ }) { Text("+", color = NeonPink, fontSize = 18.sp) }
                                }
                            }
                        }
                    }
                }

                // Summary Note
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0C1322))
                        .border(1.dp, BorderGlow, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "💡 এই প্ল্যান তৈরিতে NCTB-এর ১২টি বিষয়ের সম্পূর্ণ ১০৫টি অধ্যায় এবং বিগত ৫ বছরের বোর্ড প্রশ্ন স্বয়ংক্রিয়ভাবে দিনভিত্তিক সাজানো হবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCyan,
                        lineHeight = 18.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onGeneratePlan(
                        selectedDuration,
                        selectedHours,
                        System.currentTimeMillis(),
                        easyDays,
                        normalDays,
                        difficultDays,
                        veryDifficultDays
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                modifier = Modifier.testTag("generate_complete_study_plan_button")
            ) {
                Text("Generate My Complete Study Plan", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = TextSecondary)
            }
        }
    )
}

/**
 * Feature 3: Each Chapter Study System Dialog (8 Phases & Time Allocation)
 */
@Composable
fun ChapterStudySystemDialog(
    task: ScheduledTaskEntity,
    onDismiss: () -> Unit,
    onToggleStep: (stepIndex: Int) -> Unit,
    onUpdateTimeAllocations: (textbook: Int, mcq: Int, cq: Int, board: Int, revision: Int) -> Unit,
    onOpenExtendDialog: () -> Unit,
    onAskAi: (title: String, prompt: String) -> Unit
) {
    var textbookMin by remember { mutableIntStateOf(task.textbookMinutes) }
    var mcqMin by remember { mutableIntStateOf(task.mcqMinutes) }
    var cqMin by remember { mutableIntStateOf(task.cqMinutes) }
    var boardMin by remember { mutableIntStateOf(task.boardSolveMinutes) }
    var revisionMin by remember { mutableIntStateOf(task.revisionMinutes) }
    var showTimeSettings by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "দিন ${task.dayNumber} • ${task.subjectName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = task.dateString,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = task.chapterTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (task.subjectId == "bangla_1") "বাংলা ১ম পত্র ৮-ধাপের সাহিত্য অধ্যায় প্রস্তুতি:" else "৮-ধাপের স্বয়ংসম্পূর্ণ অধ্যায় প্রস্তুতি চেকলিস্ট:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                if (task.subjectId == "bangla_1") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0C2433))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "💡 ২-দিনের প্ল্যান: ১ম দিন রিডিং, লেখক/কবি পরিচিতি, শব্দার্থ ও MCQ। ২য় দিন CQ সৃজনশীল, বিগত বোর্ড প্রশ্ন ও উত্তর লেখার কৌশল।",
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonCyan,
                            fontSize = 11.sp
                        )
                    }
                }

                // The 8 Study Steps
                val isBangla = task.subjectId == "bangla_1"
                val steps = listOf(
                    1 to Triple("1. পাঠ্যবই সম্পূর্ণ রিডিং", if (isBangla) "লেখক/কবি পরিচিতি ও মূল সাহিত্য পাঠ" else "মূল ধারণার লাইন বাই লাইন পড়া", task.textbookRead),
                    2 to Triple(if (isBangla) "2. মূলভাব ও সারসংক্ষেপ" else "2. কনসেপ্ট ও সূত্রাবলি বোঝা", if (isBangla) "শব্দার্থ, টিকা ও গভীর ভাবার্থ আত্মস্থ করা" else "মূল সূত্র, একক ও ডেরিভেশন আত্মস্থ করা", task.conceptUnderstood),
                    3 to Triple("3. সংক্ষিপ্ত রিভিশন নোট তৈরি", if (isBangla) "জ্ঞানমূলক ও অনুধাবনমূলক প্রশ্নের বুলেট নোট" else "পরীক্ষার আগের রাতের জন্য নিজস্ব নোট", task.notesCreated),
                    4 to Triple("4. MCQ প্র্যাকটিস (${task.mcqCount}টি)", if (isBangla) "চরিত্র, উক্তি ও রূপকধর্মী নৈর্ব্যক্তিক সমাধান" else "টাইম ম্যানেজমেন্ট সহ নৈর্ব্যক্তিক সমাধান", task.mcqPracticeCompleted),
                    5 to Triple("5. CQ সৃজনশীল প্র্যাকটিস (${task.cqCount}টি)", if (isBangla) "ক, খ, গ, ঘ কাঠামোগত বোর্ড মানের অনুশীলন" else "ক, খ, গ, ঘ কাঠামোগত অনুশীলন", task.cqPracticeCompleted),
                    6 to Triple("6. বিগত বোর্ড প্রশ্ন সমাধান (${task.boardQuestionCount}টি)", if (isBangla) "বিগত ৫ বছরের শীর্ষ শিক্ষা বোর্ডের সৃজনশীল সমাধান" else "ঢাকা ও শীর্ষ বোর্ডের বিগত প্রশ্ন", task.boardQuestionsSolved),
                    7 to Triple("7. অধ্যায়ভিত্তিক সেলফ টেস্ট", if (isBangla) "নিজে নিজে মূল্যায়ন ও সময় ধরে সৃজনশীল লেখা" else "নিজে নিজে মূল্যায়ন পরীক্ষা", task.chapterTestCompleted),
                    8 to Triple("8. ভুল প্রশ্নের রিভিউ ও সংশোধন", if (isBangla) "ভুল উত্তরের নোট এবং MRH AI দিয়ে সমাধান" else "মিস্টেক নোটবুক থেকে দুর্বলতা দূর", task.mistakesReviewed)
                )

                steps.forEach { (index, data) ->
                    val (title, sub, isDone) = data
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isDone) Color(0xFF0B2E28) else DarkSurfaceVariant)
                            .clickable { onToggleStep(index) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Status",
                            tint = if (isDone) EmeraldSuccess else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDone) EmeraldSuccess else TextPrimary
                            )
                            Text(
                                text = sub,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Time Allocation Panel
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "সময় বণ্টন (মিনিট):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    TextButton(onClick = { showTimeSettings = !showTimeSettings }) {
                        Text(if (showTimeSettings) "সম্পন্ন" else "কাস্টমাইজ সময়", color = NeonCyan)
                    }
                }

                if (showTimeSettings) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceVariant)
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            TimeSliderRow("পাঠ্যবই রিডিং", textbookMin) { textbookMin = it; onUpdateTimeAllocations(textbookMin, mcqMin, cqMin, boardMin, revisionMin) }
                            TimeSliderRow("MCQ প্র্যাকটিস", mcqMin) { mcqMin = it; onUpdateTimeAllocations(textbookMin, mcqMin, cqMin, boardMin, revisionMin) }
                            TimeSliderRow("CQ প্র্যাকটিস", cqMin) { cqMin = it; onUpdateTimeAllocations(textbookMin, mcqMin, cqMin, boardMin, revisionMin) }
                            TimeSliderRow("বোর্ড প্রশ্ন", boardMin) { boardMin = it; onUpdateTimeAllocations(textbookMin, mcqMin, cqMin, boardMin, revisionMin) }
                            TimeSliderRow("রিভিশন", revisionMin) { revisionMin = it; onUpdateTimeAllocations(textbookMin, mcqMin, cqMin, boardMin, revisionMin) }
                        }
                    }
                }

                // Quick Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onOpenExtendDialog,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        border = BorderStroke(1.dp, NeonPurple),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.MoreTime, contentDescription = "Extend", tint = NeonPurple, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Extend Time", color = NeonPurple, fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            onAskAi(
                                "অধ্যায় প্রস্তুতি: ${task.chapterTitle}",
                                "আমি ${task.subjectName} এর '${task.chapterTitle}' অধ্যায়টি পড়ছি। আমাকে এই অধ্যায়ের সবচেয়ে গুরুত্বপূর্ণ ৩টি সূত্র, ৩টি কমন CQ টাইপ এবং ৫টি মোস্ট ইম্পরট্যান্ট MCQ ট্রিকস সহজ বাংলায় বিস্তারিত বুঝিয়ে দাও।"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF083344)),
                        border = BorderStroke(1.dp, NeonCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "AI", tint = NeonCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ask MRH AI", color = NeonCyan, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
            ) {
                Text("বন্ধ করো", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun TimeSliderRow(label: String, minutes: Int, onValueChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$label: $minutes মি.", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (minutes >= 10) onValueChange(minutes - 5) }, modifier = Modifier.size(24.dp)) {
                Text("-", color = NeonCyan, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = { if (minutes <= 120) onValueChange(minutes + 5) }, modifier = Modifier.size(24.dp)) {
                Text("+", color = NeonCyan, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Feature 4: Custom Time Extension Dialog
 */
@Composable
fun ExtendChapterDialog(
    chapterTitle: String,
    onDismiss: () -> Unit,
    onConfirmExtension: (extraDays: Int) -> Unit
) {
    var selectedDays by remember { mutableIntStateOf(1) }
    var customDaysInput by remember { mutableStateOf("") }
    var isCustom by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.MoreTime, contentDescription = "Extend", tint = NeonPurple)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Extend Chapter Time",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = chapterTitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCyan,
                        maxLines = 1
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "কত দিন অতিরিক্ত সময় যোগ করতে চান?",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary
                )

                val dayOptions = listOf(1, 2, 3, 5, 7)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    dayOptions.forEach { days ->
                        val isSelected = !isCustom && selectedDays == days
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NeonPurple else DarkSurfaceVariant)
                                .clickable {
                                    isCustom = false
                                    selectedDays = days
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+$days দিন",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else TextSecondary
                            )
                        }
                    }
                }

                // Custom Days Option
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isCustom) Color(0xFF2E1065) else DarkSurfaceVariant)
                        .clickable { isCustom = true }
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "Custom Days (নিজস্ব দিন সংখ্যা):",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isCustom) NeonPurple else TextSecondary
                        )
                        if (isCustom) {
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = customDaysInput,
                                onValueChange = { customDaysInput = it },
                                placeholder = { Text("দিন সংখ্যা লিখুন (যেমন: ৪, ১০)") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonPurple,
                                    unfocusedBorderColor = BorderGlow,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )
                        }
                    }
                }

                // Impact Notice
                val totalDaysAdded = if (isCustom) (customDaysInput.toIntOrNull() ?: 0) else selectedDays
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0C1322))
                        .border(1.dp, BorderGlow, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "📅 প্রভাব বিশ্লেষণ (Impact):",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = AmberGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "• এই অধ্যায়ে +$totalDaysAdded দিন যোগ হবে।\n• সম্পন্ন হওয়া আগের অধ্যায় অক্ষত থাকবে।\n• ভবিষ্যতের অবশিষ্ট সব অধ্যায় স্বয়ংক্রিয়ভাবে +$totalDaysAdded দিন সামনে এগিয়ে যাবে।",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val days = if (isCustom) (customDaysInput.toIntOrNull() ?: selectedDays) else selectedDays
                    if (days > 0) {
                        onConfirmExtension(days)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
            ) {
                Text("সময় বাড়াও", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = TextSecondary)
            }
        }
    )
}

/**
 * Feature 5: Missed Study Recovery Dialog
 */
@Composable
fun MissedRecoveryDialog(
    missedTasks: List<ScheduledTaskEntity>,
    onDismiss: () -> Unit,
    onRecoverAll: () -> Unit,
    onMarkTaskRecovered: (taskId: String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = "Missed", tint = AmberGold)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "মিসড স্টাডি রিকভারি প্ল্যান",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "মোট ${missedTasks.size}টি বকেয়া টাস্ক চিহ্নিত হয়েছে",
                        style = MaterialTheme.typography.bodySmall,
                        color = AmberGold
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "পূর্ববর্তী দিনে যে অধ্যায়গুলো সম্পন্ন হয়নি, সেগুলোকে প্রতিদিনের অতিরিক্ত রিভিশন স্লটে বণ্টন করে দেওয়া হবে যাতে দৈনিক পড়ার চাপ না বাড়ে।",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )

                missedTasks.forEach { task ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceVariant)
                            .border(1.dp, Color(0xFF4C0519), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${task.subjectName} (${task.dateString})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonPink,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = task.chapterTitle,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary
                                )
                            }
                            IconButton(
                                onClick = { onMarkTaskRecovered(task.id) }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Recover",
                                    tint = EmeraldSuccess
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onRecoverAll()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AmberGold)
            ) {
                Text("অটো রিকভার ও রি-শিডিউল করো", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বন্ধ করো", color = TextSecondary)
            }
        }
    )
}
