package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.ui.components.CyberCard
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BOOTSTRAPPED_ADMIN_EMAIL
import com.example.util.onGoogleSignInClicked

@Composable
fun AuthScreen(
    showBackButton: Boolean = true,
    onBack: () -> Unit = {},
    onAuthenticated: (launchAgentPanel: Boolean) -> Unit = {}
) {
    BackHandler(enabled = showBackButton) { onBack() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var isSigningIn by remember { mutableStateOf(false) }
    var isAdminSigningIn by remember { mutableStateOf(false) }
    var showAdminLoginDialog by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF070A13), Color(0xFF0B1426), Color(0xFF070A13))
                )
            )
            .systemBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        if (showBackButton) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 10.dp, top = 8.dp)
                    .size(48.dp)
                    .testTag("auth_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "ড্যাশবোর্ডে ফিরে যান",
                    tint = NeonCyan
                )
            }
        }

        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, top = 56.dp, bottom = 84.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(92.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0F2238))
                    .border(2.dp, NeonCyan, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_study_logo),
                    contentDescription = "COMPLETE MRH Logo",
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "COMPLETE MRH",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "SSC 2028 স্মার্ট এআই ও কুইজ সিস্টেম",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = NeonCyan,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "এজেন্ট প্যানেল ও ক্লাউড কুইজ সিঙ্ক চালু করতে আপনার Google অ্যাকাউন্ট দিয়ে প্রবেশ করুন অথবা নিচের কর্নারে এডমিন লগইন ব্যবহার করুন।",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            CyberCard(
                borderBrush = Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.6f), NeonPurple.copy(alpha = 0.6f))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    AuthFeatureRow(
                        icon = Icons.Default.Quiz,
                        tint = NeonCyan,
                        title = "৮টি স্মার্ট কুইজ ও এক্সাম মোড",
                        subtitle = "অধ্যায়ভিত্তিক, বই, র‍্যান্ডম, টাইমড এবং এজেন্ট প্রকাশিত MCQ"
                    )
                    AuthFeatureRow(
                        icon = Icons.Default.CloudDone,
                        tint = EmeraldSuccess,
                        title = "ক্লাউড সিঙ্ক ও ফলাফল বিশ্লেষণ",
                        subtitle = "প্রতিটি কুইজের নম্বর, সময় ও ব্যাখ্যাসহ ইতিহাস সংরক্ষণ"
                    )
                    AuthFeatureRow(
                        icon = Icons.Default.VerifiedUser,
                        tint = NeonPurple,
                        title = "নিরাপদ এজেন্ট রোল-ভিত্তিক অ্যাক্সেস",
                        subtitle = "ছবি/PDF OCR প্রশ্ন রিভিউ ও প্রকাশনার জন্য Firebase নিরাপত্তা"
                    )
                }
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_error_card"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B1019)),
                    border = BorderStroke(1.dp, NeonPink.copy(alpha = 0.7f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Authentication error",
                            tint = NeonPink,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            lineHeight = 19.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (isSigningIn || isAdminSigningIn) return@Button
                    isSigningIn = true
                    errorMessage = null
                    onGoogleSignInClicked(
                        context = context,
                        credentialManager = credentialManager,
                        onAuthSuccess = {
                            isSigningIn = false
                            onAuthenticated(false)
                        },
                        onAuthError = { msg ->
                            isSigningIn = false
                            errorMessage = msg
                        },
                        onAuthCancelled = {
                            isSigningIn = false
                        },
                        scope = scope
                    )
                },
                enabled = !isSigningIn && !isAdminSigningIn,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    disabledContainerColor = DarkSurfaceVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .testTag("google_sign_in_button")
            ) {
                if (isSigningIn) {
                    CircularProgressIndicator(
                        color = Color(0xFF031A24),
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "সাইন-ইন সম্পন্ন হচ্ছে...",
                        color = Color(0xFF031A24),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelLarge
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "Google Sign In",
                        tint = Color(0xFF031A24),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Google দিয়ে সাইন-ইন করুন",
                        color = Color(0xFF031A24),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelLarge,
                        fontSize = 15.sp
                    )
                }
            }
        }

        // Bottom-Right Corner Admin Login Option (Direct RBAC Entry -> Agent Panel)
        OutlinedButton(
            onClick = { showAdminLoginDialog = true },
            enabled = !isSigningIn && !isAdminSigningIn,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, NeonPurple.copy(alpha = 0.75f)),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = DarkSurface.copy(alpha = 0.94f),
                disabledContainerColor = DarkSurface.copy(alpha = 0.5f)
            ),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 18.dp, bottom = 14.dp)
                .heightIn(min = 48.dp)
                .testTag("admin_login_corner_button")
        ) {
            Icon(
                imageVector = Icons.Default.AdminPanelSettings,
                contentDescription = "এডমিন লগইন",
                tint = NeonPurple,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "এডমিন লগইন",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
    }

    if (showAdminLoginDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isAdminSigningIn) {
                    showAdminLoginDialog = false
                }
            },
            containerColor = DarkSurface,
            icon = {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin RBAC Access",
                    tint = NeonPurple,
                    modifier = Modifier.size(34.dp)
                )
            },
            title = {
                Text(
                    text = "অ্যাডমিন / এজেন্ট লগইন",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                        border = BorderStroke(1.dp, NeonPurple.copy(alpha = 0.55f)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "প্রাথমিক এজেন্ট হ্যান্ডেল: Mr1122",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                            Text(
                                text = "অনুমোদিত অ্যাডমিন: $BOOTSTRAPPED_ADMIN_EMAIL",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Text(
                        text = "অ্যাপের নিরাপত্তা ও Firebase নিয়ম অনুযায়ী APK-তে কোনো পাসওয়ার্ড সংরক্ষণ করা হয় না। বর্তমান সিস্টেমে সরাসরি এজেন্ট প্যানেলে প্রবেশ করতে আপনার অনুমোদিত অ্যাডমিন Google অ্যাকাউন্ট দিয়ে সাইন-ইন করুন।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 19.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isAdminSigningIn) return@Button
                        isAdminSigningIn = true
                        errorMessage = null
                        onGoogleSignInClicked(
                            context = context,
                            credentialManager = credentialManager,
                            onAuthSuccess = {
                                isAdminSigningIn = false
                                showAdminLoginDialog = false
                                onAuthenticated(true)
                            },
                            onAuthError = { msg ->
                                isAdminSigningIn = false
                                showAdminLoginDialog = false
                                errorMessage = msg
                            },
                            onAuthCancelled = {
                                isAdminSigningIn = false
                            },
                            scope = scope
                        )
                    },
                    enabled = !isAdminSigningIn,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("admin_google_sign_in_button")
                ) {
                    if (isAdminSigningIn) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("যাচাই হচ্ছে...", color = Color.White, fontWeight = FontWeight.Bold)
                    } else {
                        Text("অ্যাডমিন Google লগইন", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showAdminLoginDialog = false },
                    enabled = !isAdminSigningIn,
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Text("বাতিল", color = NeonCyan, fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }
}

@Composable
private fun AuthFeatureRow(
    icon: ImageVector,
    tint: Color,
    title: String,
    subtitle: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(DarkSurfaceVariant)
                .border(1.dp, tint.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                lineHeight = 18.sp
            )
        }
    }
}
