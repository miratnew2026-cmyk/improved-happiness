package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChapterInfo
import com.example.data.model.SocialIctPriorityMetrics
import com.example.data.model.SscSyllabusData
import com.example.ui.components.QuickExplanationDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.HindSiliguriFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MainViewModel

private data class SocialIctSubjectTheme(
    val id: String,
    val nameBn: String,
    val shortBn: String,
    val nameEn: String,
    val accent: Color,
    val deepTint: Color,
    val borderTint: Color,
    val pillBg: Color,
    val pillText: Color,
    val icon: ImageVector
)

private val BgsTheme = SocialIctSubjectTheme(
    id = "bgs",
    nameBn = "বাংলাদেশ ও বিশ্বপরিচয়",
    shortBn = "BGS",
    nameEn = "Bangladesh & Global Studies",
    accent = Color(0xFF38BDF8),
    deepTint = Color(0xFF0A1F38),
    borderTint = Color(0xFF0284C7),
    pillBg = Color(0xFF0C2D48),
    pillText = Color(0xFF7DD3FC),
    icon = Icons.Default.Public
)

private val IslamTheme = SocialIctSubjectTheme(
    id = "islam_moral",
    nameBn = "ইসলাম ও নৈতিক শিক্ষা",
    shortBn = "ইসলাম শিক্ষা",
    nameEn = "Islam & Moral Education",
    accent = Color(0xFF10B981),
    deepTint = Color(0xFF06261E),
    borderTint = Color(0xFF059669),
    pillBg = Color(0xFF064E3B),
    pillText = Color(0xFF6EE7B7),
    icon = Icons.Default.MenuBook
)

private val IctTheme = SocialIctSubjectTheme(
    id = "ict",
    nameBn = "তথ্য ও যোগাযোগ প্রযুক্তি",
    shortBn = "ICT",
    nameEn = "ICT",
    accent = Color(0xFFA855F7),
    deepTint = Color(0xFF1F1135),
    borderTint = Color(0xFF7C3AED),
    pillBg = Color(0xFF2E1065),
    pillText = Color(0xFFD8B4FE),
    icon = Icons.Default.Computer
)

private fun themeForSocialIctSubject(subjectId: String): SocialIctSubjectTheme = when (subjectId) {
    "bgs" -> BgsTheme
    "islam_moral" -> IslamTheme
    else -> IctTheme
}

private data class SocialIctPriorityStyle(
    val bg: Color,
    val border: Color,
    val text: Color,
    val label: String,
    val fullLabel: String
)

private fun styleForSocialIctPriority(tag: String): SocialIctPriorityStyle = when (tag) {
    "⭐" -> SocialIctPriorityStyle(
        bg = Color(0xFF064E3B),
        border = Color(0xFF10B981),
        text = Color(0xFF34D399),
        label = "⭐ গুরুত্বপূর্ণ",
        fullLabel = "⭐ অত্যন্ত গুরুত্বপূর্ণ অধ্যায়"
    )
    "☆" -> SocialIctPriorityStyle(
        bg = Color(0xFF3B0764),
        border = Color(0xFFA855F7),
        text = Color(0xFFE9D5FF),
        label = "☆ সাধারণ",
        fullLabel = "☆ সাধারণ অগ্রাধিকার অধ্যায়"
    )
    else -> SocialIctPriorityStyle(
        bg = Color(0xFF451A03),
        border = Color(0xFFF59E0B),
        text = Color(0xFFFDE68A),
        label = "🟡 স্বল্প অগ্রাধিকার",
        fullLabel = "🟡 স্বল্প অগ্রাধিকার অধ্যায়"
    )
}

/**
 * SSC 2028 Social Studies & ICT Study Dashboard
 * App Name: COMPLETE MRH
 *
 * Covers all 26 chapters strictly in syllabus order without duplication:
 * - BGS (14 chapters, Blue theme): 12 ⭐ Important, 2 ☆ Normal
 * - Islam Education (5 chapters, Emerald Green theme): 5 ⭐ Important
 * - ICT (7 chapters, Purple theme): 7 ⭐ Important
 */
@Composable
fun SocialIctPriorityScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onAskAi: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val chaptersProgress by viewModel.allChapters.collectAsState()
    val metrics by viewModel.socialIctPriorityMetrics.collectAsState()

    val quickExplainTitle by viewModel.quickExplainTitle.collectAsState()
    val quickExplainContent by viewModel.quickExplainContent.collectAsState()
    val isQuickExplainLoading by viewModel.isQuickExplainLoading.collectAsState()

    // Dedicated Chapter Detail Page target (subjectId to chapterNumber)
    var selectedChapterTarget by remember { mutableStateOf<Pair<String, Int>?>(null) }

    // Search & Filters
    var searchQuery by remember { mutableStateOf("") }
    var selectedSubjectFilter by remember { mutableStateOf("ALL") } // ALL, bgs, islam_moral, ict
    var selectedPriorityFilter by remember { mutableStateOf("ALL") } // ALL, IMPORTANT, NORMAL, LOW
    var selectedStatusFilter by remember { mutableStateOf("ALL") } // ALL, COMPLETED, INCOMPLETE
    var showResetConfirmationDialog by remember { mutableStateOf(false) }

    BackHandler {
        if (selectedChapterTarget != null) {
            selectedChapterTarget = null
        } else {
            onBack()
        }
    }

    val bgsSubject = SscSyllabusData.getSubject("bgs")
    val islamSubject = SscSyllabusData.getSubject("islam_moral")
    val ictSubject = SscSyllabusData.getSubject("ict")

    val allSocialIctChapters = remember(bgsSubject, islamSubject, ictSubject) {
        buildList {
            bgsSubject?.chapters?.forEach { add("bgs" to it) }
            islamSubject?.chapters?.forEach { add("islam_moral" to it) }
            ictSubject?.chapters?.forEach { add("ict" to it) }
        }
    }

    val filteredChapters = allSocialIctChapters.filter { (subId, chapter) ->
        val matchSubject = selectedSubjectFilter == "ALL" || subId == selectedSubjectFilter
        val matchPriority = when (selectedPriorityFilter) {
            "IMPORTANT" -> chapter.importanceTag == "⭐"
            "NORMAL" -> chapter.importanceTag == "☆"
            "LOW" -> chapter.importanceTag == "🟡"
            else -> true
        }
        val entity = chaptersProgress.find { it.id == "${subId}_ch_${chapter.number}" }
        val isDone = entity?.isCompleted == true
        val matchStatus = when (selectedStatusFilter) {
            "COMPLETED" -> isDone
            "INCOMPLETE" -> !isDone
            else -> true
        }
        val q = searchQuery.trim().lowercase()
        val matchSearch = if (q.isBlank()) {
            true
        } else {
            val theme = themeForSocialIctSubject(subId)
            chapter.title.lowercase().contains(q) ||
                chapter.keyTopics.lowercase().contains(q) ||
                theme.nameBn.lowercase().contains(q) ||
                theme.shortBn.lowercase().contains(q) ||
                theme.nameEn.lowercase().contains(q) ||
                chapter.number.toString().contains(q)
        }
        matchSubject && matchPriority && matchStatus && matchSearch
    }

    val backgroundGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF060D1E),
            Color(0xFF0A1931),
            Color(0xFF050A16)
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundGradient)
    ) {
        AnimatedContent(
            targetState = selectedChapterTarget,
            transitionSpec = {
                if (targetState != null) {
                    (slideInHorizontally(tween(240)) { it / 3 } + fadeIn(tween(220))) togetherWith
                        (slideOutHorizontally(tween(220)) { -it / 4 } + fadeOut(tween(180)))
                } else {
                    (slideInHorizontally(tween(240)) { -it / 3 } + fadeIn(tween(220))) togetherWith
                        (slideOutHorizontally(tween(220)) { it / 4 } + fadeOut(tween(180)))
                }
            },
            label = "social_ict_dashboard_detail_transition"
        ) { target ->
            if (target != null) {
                val (subjectId, chapterNumber) = target
                val chapter = SscSyllabusData.getChapter(subjectId, chapterNumber)
                if (chapter != null) {
                    val entityId = "${subjectId}_ch_${chapter.number}"
                    val entity = chaptersProgress.find { it.id == entityId }
                    val isCompleted = entity?.isCompleted == true
                    val note = entity?.notes.orEmpty()

                    SocialIctChapterDetailPage(
                        subjectId = subjectId,
                        chapter = chapter,
                        isCompleted = isCompleted,
                        savedNote = note,
                        onBack = { selectedChapterTarget = null },
                        onToggleComplete = {
                            viewModel.toggleChapterCompletion(entityId, isCompleted)
                        },
                        onSaveNote = { updatedNote ->
                            viewModel.saveChapterNote(entityId, updatedNote)
                            Toast.makeText(context, "অধ্যায়ের নোট সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                        },
                        onQuickAiSummary = {
                            val subName = themeForSocialIctSubject(subjectId).nameBn
                            viewModel.requestQuickExplanation(
                                title = "$subName: ${chapter.title}",
                                prompt = "$subName এর '${chapter.title}' (মূল টপিক: ${chapter.keyTopics}) অধ্যায়টির এসএসসি ২০২৮ পরীক্ষার জন্য সবচেয়ে গুরুত্বপূর্ণ তথ্য, সংজ্ঞা, সৃজনশীল (CQ) ও MCQ সাজেশন বাংলায় বিস্তারিত বুঝিয়ে দিন।"
                            )
                        },
                        onOpenFullAiTutor = {
                            val subName = themeForSocialIctSubject(subjectId).nameBn
                            val prompt = "$subName এর অধ্যায় ${chapter.number}: '${chapter.title}' (টপিক: ${chapter.keyTopics}) আমাকে এসএসসি ২০২৮ বোর্ড পরীক্ষার উপযোগী করে সহজ ভাষায়, মূল পয়েন্ট ও গুরুত্বপূর্ণ ক, খ, গ, ঘ সৃজনশীল প্রশ্নসহ বুঝিয়ে দাও।"
                            selectedChapterTarget = null
                            onAskAi(prompt)
                        }
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .systemBarsPadding()
                        .padding(horizontal = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 650.dp)
                            .fillMaxSize()
                    ) {
                        Spacer(modifier = Modifier.height(6.dp))

                        // Top App Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                IconButton(
                                    onClick = onBack,
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("social_ict_priority_back_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Back",
                                        tint = NeonCyan
                                    )
                                }
                                Column {
                                    Text(
                                        text = "COMPLETE MRH",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = NeonCyan,
                                        fontFamily = HindSiliguriFontFamily
                                    )
                                    Text(
                                        text = "SSC 2028 BGS, ইসলাম ও ICT ড্যাশবোর্ড",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        fontSize = 12.sp,
                                        fontFamily = HindSiliguriFontFamily
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        val copyText = buildString {
                                            appendLine("=== COMPLETE MRH: SSC 2028 BGS, ইসলাম ও ICT (২৬টি অধ্যায়) ===")
                                            appendLine("\n[SUBJECT 1: BGS / বাংলাদেশ ও বিশ্বপরিচয় (১৪টি অধ্যায়)]")
                                            bgsSubject?.chapters?.forEach { ch ->
                                                appendLine("${ch.number}. ${ch.importanceTag} ${ch.title}")
                                            }
                                            appendLine("\n[SUBJECT 2: ইসলাম ও নৈতিক শিক্ষা (৫টি অধ্যায়)]")
                                            islamSubject?.chapters?.forEach { ch ->
                                                appendLine("${ch.number}. ${ch.importanceTag} ${ch.title}")
                                            }
                                            appendLine("\n[SUBJECT 3: ICT / তথ্য ও যোগাযোগ প্রযুক্তি (৭টি অধ্যায়)]")
                                            ictSubject?.chapters?.forEach { ch ->
                                                appendLine("${ch.number}. ${ch.importanceTag} ${ch.title}")
                                            }
                                        }
                                        clipboardManager.setText(AnnotatedString(copyText))
                                        Toast.makeText(context, "২৬টি অধ্যায়ের তালিকা কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("social_ict_copy_list_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy Chapters List",
                                        tint = NeonCyan
                                    )
                                }

                                IconButton(
                                    onClick = { showResetConfirmationDialog = true },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("social_ict_reset_progress_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Reset Progress",
                                        tint = NeonPink
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Combined Social Studies & ICT Hero Dashboard
                            item {
                                SocialIctCombinedHeroCard(
                                    metrics = metrics,
                                    selectedSubjectFilter = selectedSubjectFilter,
                                    onSelectSubject = { clickedSubject ->
                                        selectedSubjectFilter = if (selectedSubjectFilter == clickedSubject) {
                                            "ALL"
                                        } else {
                                            clickedSubject
                                        }
                                    }
                                )
                            }

                            // Dedicated Individual Subject Dashboard Spotlight when filtered
                            if (selectedSubjectFilter != "ALL") {
                                item {
                                    SocialIctSpotlightCard(
                                        subjectId = selectedSubjectFilter,
                                        metrics = metrics,
                                        chapters = when (selectedSubjectFilter) {
                                            "bgs" -> bgsSubject?.chapters.orEmpty()
                                            "islam_moral" -> islamSubject?.chapters.orEmpty()
                                            else -> ictSubject?.chapters.orEmpty()
                                        },
                                        onShowAll = { selectedSubjectFilter = "ALL" }
                                    )
                                }
                            }

                            // Search & Filters
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = searchQuery,
                                        onValueChange = { searchQuery = it },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("social_ict_search_input"),
                                        placeholder = {
                                            Text(
                                                "অধ্যায় খুঁজুন (যেমন: স্বাধীনতা, ইবাদত, প্রোগ্রামিং, ওয়েব)...",
                                                color = TextTertiary,
                                                fontSize = 13.sp,
                                                fontFamily = HindSiliguriFontFamily
                                            )
                                        },
                                        leadingIcon = {
                                            Icon(Icons.Default.Search, contentDescription = "Search", tint = NeonCyan)
                                        },
                                        trailingIcon = {
                                            if (searchQuery.isNotEmpty()) {
                                                IconButton(onClick = { searchQuery = "" }) {
                                                    Icon(Icons.Default.Clear, contentDescription = "Clear Search", tint = TextSecondary)
                                                }
                                            }
                                        },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedContainerColor = Color(0xFF0C1A30),
                                            unfocusedContainerColor = Color(0xFF0C1A30),
                                            focusedBorderColor = NeonCyan,
                                            unfocusedBorderColor = Color(0xFF1E3A5F),
                                            focusedTextColor = TextPrimary,
                                            unfocusedTextColor = TextPrimary
                                        )
                                    )

                                    // Subject Tabs: Combined + Separate BGS / Islam / ICT Dashboards
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        val tabs = listOf(
                                            Triple("ALL", "সকল (২৬)", NeonCyan),
                                            Triple("bgs", "BGS (১৪)", BgsTheme.accent),
                                            Triple("islam_moral", "ইসলাম শিক্ষা (৫)", IslamTheme.accent),
                                            Triple("ict", "ICT (৭)", IctTheme.accent)
                                        )
                                        items(tabs) { (key, label, accent) ->
                                            val isSelected = selectedSubjectFilter == key
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = { selectedSubjectFilter = key },
                                                modifier = Modifier.testTag("social_ict_tab_$key"),
                                                label = {
                                                    Text(
                                                        label,
                                                        fontSize = 12.sp,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                        fontFamily = HindSiliguriFontFamily
                                                    )
                                                },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = accent,
                                                    selectedLabelColor = Color(0xFF04111E),
                                                    containerColor = Color(0xFF0F1E33),
                                                    labelColor = TextSecondary
                                                ),
                                                border = FilterChipDefaults.filterChipBorder(
                                                    borderColor = accent.copy(alpha = 0.35f),
                                                    selectedBorderColor = accent,
                                                    enabled = true,
                                                    selected = isSelected
                                                )
                                            )
                                        }
                                    }

                                    // Priority Filter Badges
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        val priorities = listOf(
                                            Triple("ALL", "সকল প্রায়োরিটি", NeonCyan),
                                            Triple("IMPORTANT", "⭐ গুরুত্বপূর্ণ (${metrics.importantCount})", Color(0xFF10B981)),
                                            Triple("NORMAL", "☆ সাধারণ (${metrics.normalCount})", Color(0xFFA855F7)),
                                            Triple("LOW", "🟡 স্বল্প (${metrics.lowCount})", Color(0xFFF59E0B))
                                        )
                                        items(priorities) { (key, label, color) ->
                                            val selected = selectedPriorityFilter == key
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(14.dp))
                                                    .background(if (selected) color.copy(alpha = 0.24f) else Color(0xFF0C1A30))
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (selected) color else Color(0xFF1E3A5F),
                                                        shape = RoundedCornerShape(14.dp)
                                                    )
                                                    .clickable { selectedPriorityFilter = key }
                                                    .padding(horizontal = 11.dp, vertical = 7.dp)
                                                    .testTag("social_ict_priority_filter_$key")
                                            ) {
                                                Text(
                                                    text = label,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (selected) color else TextSecondary,
                                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                                    fontFamily = HindSiliguriFontFamily,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }

                                    // Completion Status Filter
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf(
                                            "ALL" to "সব অধ্যায়",
                                            "INCOMPLETE" to "বাকি (${metrics.totalRemaining})",
                                            "COMPLETED" to "সম্পন্ন (${metrics.totalCompleted})"
                                        ).forEach { (statusKey, statusLabel) ->
                                            val isSelected = selectedStatusFilter == statusKey
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(if (isSelected) Color(0xFF163252) else Color(0xFF0B1628))
                                                    .border(
                                                        1.dp,
                                                        if (isSelected) NeonCyan else Color(0xFF1E3A5F),
                                                        RoundedCornerShape(10.dp)
                                                    )
                                                    .clickable { selectedStatusFilter = statusKey }
                                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                                            ) {
                                                Text(
                                                    text = statusLabel,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSelected) NeonCyan else TextSecondary,
                                                    fontFamily = HindSiliguriFontFamily
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Chapter Count Header
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "অধ্যায় তালিকা (${filteredChapters.size}টি প্রদর্শিত)",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFE2E8F0),
                                        fontFamily = HindSiliguriFontFamily
                                    )
                                    Text(
                                        text = "ট্যাপ করে বিস্তারিত দেখুন",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextTertiary,
                                        fontSize = 11.sp,
                                        fontFamily = HindSiliguriFontFamily
                                    )
                                }
                            }

                            if (filteredChapters.isEmpty()) {
                                item {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1D34)),
                                        border = BorderStroke(1.dp, Color(0xFF1E3A5F))
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(22.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Search,
                                                contentDescription = "Empty",
                                                tint = NeonCyan,
                                                modifier = Modifier.size(34.dp)
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "কোনো অধ্যায় খুঁজে পাওয়া যায়নি",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary,
                                                fontFamily = HindSiliguriFontFamily
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "ফিল্টার পরিবর্তন করুন অথবা অন্য কীওয়ার্ড দিয়ে খুঁজুন।",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = TextSecondary,
                                                fontFamily = HindSiliguriFontFamily
                                            )
                                        }
                                    }
                                }
                            } else {
                                items(
                                    items = filteredChapters,
                                    key = { "${it.first}_${it.second.number}" }
                                ) { (subId, chapter) ->
                                    val entityId = "${subId}_ch_${chapter.number}"
                                    val progressEntity = chaptersProgress.find { it.id == entityId }
                                    val isCompleted = progressEntity?.isCompleted == true
                                    val hasNote = !progressEntity?.notes.isNullOrBlank()

                                    SocialIctChapterCard(
                                        subjectId = subId,
                                        chapter = chapter,
                                        isCompleted = isCompleted,
                                        hasNote = hasNote,
                                        onToggleComplete = {
                                            viewModel.toggleChapterCompletion(entityId, isCompleted)
                                        },
                                        onOpenDetail = {
                                            selectedChapterTarget = subId to chapter.number
                                        }
                                    )
                                }
                            }

                            item {
                                Spacer(modifier = Modifier.height(28.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Reset Progress Confirmation Dialog
    if (showResetConfirmationDialog) {
        val activeSubjectLabel = when (selectedSubjectFilter) {
            "bgs" -> "বাংলাদেশ ও বিশ্বপরিচয় (১৪টি অধ্যায়)"
            "islam_moral" -> "ইসলাম ও নৈতিক শিক্ষা (৫টি অধ্যায়)"
            "ict" -> "তথ্য ও যোগাযোগ প্রযুক্তি (৭টি অধ্যায়)"
            else -> "BGS (১৪), ইসলাম শিক্ষা (৫) ও ICT (৭) সহ সকল ২৬টি অধ্যায়"
        }
        AlertDialog(
            onDismissRequest = { showResetConfirmationDialog = false },
            containerColor = Color(0xFF101C32),
            icon = {
                Icon(Icons.Default.Warning, contentDescription = "Reset Warning", tint = NeonPink, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "অগ্রগতি রিসেট নিশ্চিতকরণ",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontFamily = HindSiliguriFontFamily
                )
            },
            text = {
                Text(
                    text = "আপনি কি $activeSubjectLabel-এর সমাপ্তি অগ্রগতি রিসেট করতে চান? আপনার সংরক্ষিত ব্যক্তিগত নোটগুলি নিরাপদে থাকবে।",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    fontFamily = HindSiliguriFontFamily
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetSocialIctProgress(
                            if (selectedSubjectFilter in listOf("bgs", "islam_moral", "ict")) {
                                selectedSubjectFilter
                            } else {
                                null
                            }
                        )
                        showResetConfirmationDialog = false
                        Toast.makeText(context, "অগ্রগতি সফলভাবে রিসেট করা হয়েছে!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink)
                ) {
                    Text("হ্যাঁ, রিসেট করুন", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = HindSiliguriFontFamily)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmationDialog = false }) {
                    Text("বাতিল", color = TextSecondary, fontFamily = HindSiliguriFontFamily)
                }
            }
        )
    }

    QuickExplanationDialog(
        title = quickExplainTitle,
        content = quickExplainContent,
        isLoading = isQuickExplainLoading,
        onDismiss = { viewModel.closeQuickExplanation() }
    )
}

@Composable
private fun SocialIctCombinedHeroCard(
    metrics: SocialIctPriorityMetrics,
    selectedSubjectFilter: String,
    onSelectSubject: (String) -> Unit
) {
    val overallProgress by animateFloatAsState(
        targetValue = (metrics.totalPercent / 100f).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "social_ict_overall_progress"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1A31)),
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.horizontalGradient(
                listOf(BgsTheme.accent, IslamTheme.accent, IctTheme.accent)
            )
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "সমাজ বিজ্ঞান, ইসলাম ও ICT ড্যাশবোর্ড",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontFamily = HindSiliguriFontFamily
                    )
                    Text(
                        text = "সম্পন্ন: ${metrics.totalCompleted}/${metrics.totalChapters} • বাকি: ${metrics.totalRemaining}টি অধ্যায়",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCyan,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = HindSiliguriFontFamily
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF064E3B))
                        .border(1.dp, EmeraldSuccess, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${metrics.totalPercent}%",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF34D399)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { overallProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(9.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = NeonCyan,
                trackColor = Color(0xFF17263D)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 3 Separate Subject Mini Dashboards: Blue BGS, Emerald Islam, Purple ICT
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SocialIctMiniDashboardCard(
                    theme = BgsTheme,
                    completed = metrics.bgsCompleted,
                    total = metrics.bgsTotal,
                    remaining = metrics.bgsRemaining,
                    percent = metrics.bgsPercent,
                    isSelected = selectedSubjectFilter == "bgs",
                    onClick = { onSelectSubject("bgs") },
                    modifier = Modifier.weight(1f)
                )
                SocialIctMiniDashboardCard(
                    theme = IslamTheme,
                    completed = metrics.islamCompleted,
                    total = metrics.islamTotal,
                    remaining = metrics.islamRemaining,
                    percent = metrics.islamPercent,
                    isSelected = selectedSubjectFilter == "islam_moral",
                    onClick = { onSelectSubject("islam_moral") },
                    modifier = Modifier.weight(1f)
                )
                SocialIctMiniDashboardCard(
                    theme = IctTheme,
                    completed = metrics.ictCompleted,
                    total = metrics.ictTotal,
                    remaining = metrics.ictRemaining,
                    percent = metrics.ictPercent,
                    isSelected = selectedSubjectFilter == "ict",
                    onClick = { onSelectSubject("ict") },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF064E3B))
                            .border(0.8.dp, Color(0xFF10B981), RoundedCornerShape(8.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "⭐ গুরুত্বপূর্ণ: ${metrics.importantCount}টি",
                            fontSize = 10.sp,
                            color = Color(0xFF34D399),
                            fontWeight = FontWeight.Bold,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF3B0764))
                            .border(0.8.dp, Color(0xFFA855F7), RoundedCornerShape(8.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "☆ সাধারণ: ${metrics.normalCount}টি",
                            fontSize = 10.sp,
                            color = Color(0xFFE9D5FF),
                            fontWeight = FontWeight.Bold,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }
                Text(
                    text = "মোট ২৬ অধ্যায়",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary,
                    fontSize = 11.sp,
                    fontFamily = HindSiliguriFontFamily
                )
            }
        }
    }
}

@Composable
private fun SocialIctMiniDashboardCard(
    theme: SocialIctSubjectTheme,
    completed: Int,
    total: Int,
    remaining: Int,
    percent: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = (percent / 100f).coerceIn(0f, 1f),
        animationSpec = tween(400),
        label = "social_ict_mini_${theme.id}"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) theme.deepTint else Color(0xFF091326))
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) theme.accent else theme.borderTint.copy(alpha = 0.55f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(9.dp)
            .testTag("social_ict_mini_card_${theme.id}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = theme.icon,
                    contentDescription = theme.nameEn,
                    tint = theme.accent,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "$percent%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = theme.accent
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = theme.shortBn,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
                fontFamily = HindSiliguriFontFamily
            )
            Text(
                text = "$completed/$total • বাকি $remaining",
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1,
                fontFamily = HindSiliguriFontFamily
            )
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = theme.accent,
                trackColor = Color(0xFF17263D)
            )
        }
    }
}

@Composable
private fun SocialIctSpotlightCard(
    subjectId: String,
    metrics: SocialIctPriorityMetrics,
    chapters: List<ChapterInfo>,
    onShowAll: () -> Unit
) {
    val theme = themeForSocialIctSubject(subjectId)
    val (done, total, remaining, percent) = when (subjectId) {
        "bgs" -> listOf(metrics.bgsCompleted, metrics.bgsTotal, metrics.bgsRemaining, metrics.bgsPercent)
        "islam_moral" -> listOf(metrics.islamCompleted, metrics.islamTotal, metrics.islamRemaining, metrics.islamPercent)
        else -> listOf(metrics.ictCompleted, metrics.ictTotal, metrics.ictRemaining, metrics.ictPercent)
    }
    val impCount = chapters.count { it.importanceTag == "⭐" }
    val normCount = chapters.count { it.importanceTag == "☆" }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = theme.deepTint),
        border = BorderStroke(1.2.dp, theme.accent)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(theme.accent.copy(alpha = 0.2f))
                            .border(1.dp, theme.accent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(theme.icon, contentDescription = theme.nameEn, tint = theme.accent)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${theme.nameBn} ড্যাশবোর্ড",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontFamily = HindSiliguriFontFamily
                        )
                        Text(
                            text = "মোট $total অধ্যায় • ⭐ গুরুত্বপূর্ণ: $impCount • ☆ সাধারণ: $normCount",
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.pillText,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }
                TextButton(onClick = onShowAll) {
                    Text(
                        text = "সব দেখুন",
                        color = theme.accent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = HindSiliguriFontFamily
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "সম্পন্ন: $done/$total ($percent%)",
                    style = MaterialTheme.typography.labelMedium,
                    color = EmeraldSuccess,
                    fontWeight = FontWeight.Bold,
                    fontFamily = HindSiliguriFontFamily
                )
                Text(
                    text = "অবশিষ্ট: ${remaining}টি অধ্যায়",
                    style = MaterialTheme.typography.labelMedium,
                    color = AmberGold,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = HindSiliguriFontFamily
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { (percent / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = theme.accent,
                trackColor = Color(0xFF0A1426)
            )
        }
    }
}

@Composable
private fun SocialIctChapterCard(
    subjectId: String,
    chapter: ChapterInfo,
    isCompleted: Boolean,
    hasNote: Boolean,
    onToggleComplete: () -> Unit,
    onOpenDetail: () -> Unit
) {
    val theme = themeForSocialIctSubject(subjectId)
    val pStyle = styleForSocialIctPriority(chapter.importanceTag)

    val cardBg by animateColorAsState(
        targetValue = if (isCompleted) theme.deepTint else Color(0xFF0D1B32),
        animationSpec = tween(250),
        label = "social_ict_card_bg_${subjectId}_${chapter.number}"
    )
    val cardBorder by animateColorAsState(
        targetValue = if (isCompleted) theme.accent else theme.borderTint.copy(alpha = 0.45f),
        animationSpec = tween(250),
        label = "social_ict_card_border_${subjectId}_${chapter.number}"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("social_ict_chapter_card_${subjectId}_${chapter.number}")
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onOpenDetail),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = BorderStroke(1.dp, cardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (isCompleted) theme.accent else theme.pillBg)
                    .border(1.dp, theme.accent.copy(alpha = 0.7f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = String.format("%02d", chapter.number),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isCompleted) Color(0xFF04101D) else theme.pillText
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(pStyle.bg)
                            .border(0.8.dp, pStyle.border, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = pStyle.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = pStyle.text,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(theme.pillBg)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = theme.shortBn,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = theme.pillText,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }

                    if (hasNote) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "Saved Note",
                            tint = AmberGold,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = chapter.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isCompleted) TextSecondary else TextPrimary,
                    fontFamily = HindSiliguriFontFamily
                )

                Text(
                    text = chapter.keyTopics,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 2,
                    fontSize = 11.5.sp,
                    fontFamily = HindSiliguriFontFamily
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${chapter.defaultDays} দিন • অধ্যায় পেজ খুলুন",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = theme.accent,
                        fontFamily = HindSiliguriFontFamily
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = theme.accent,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            IconButton(
                onClick = onToggleComplete,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("social_ict_chapter_toggle_${subjectId}_${chapter.number}")
            ) {
                Icon(
                    imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = if (isCompleted) "Mark incomplete" else "Mark completed",
                    tint = if (isCompleted) theme.accent else Color(0xFF64748B),
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

@Composable
private fun SocialIctChapterDetailPage(
    subjectId: String,
    chapter: ChapterInfo,
    isCompleted: Boolean,
    savedNote: String,
    onBack: () -> Unit,
    onToggleComplete: () -> Unit,
    onSaveNote: (String) -> Unit,
    onQuickAiSummary: () -> Unit,
    onOpenFullAiTutor: () -> Unit
) {
    val theme = themeForSocialIctSubject(subjectId)
    val pStyle = styleForSocialIctPriority(chapter.importanceTag)
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var noteDraft by remember(subjectId, chapter.number, savedNote) { mutableStateOf(savedNote) }
    LaunchedEffect(savedNote) {
        noteDraft = savedNote
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 650.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("social_ict_detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Dashboard",
                            tint = theme.accent
                        )
                    }
                    Column {
                        Text(
                            text = "${theme.nameBn} • অধ্যায় ${chapter.number}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = theme.accent,
                            fontFamily = HindSiliguriFontFamily
                        )
                        Text(
                            text = "অধ্যায় বিস্তারিত পৃষ্ঠা — COMPLETE MRH",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.5.sp,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }

                IconButton(
                    onClick = {
                        val copyStr = "${theme.nameBn} — অধ্যায় ${chapter.number}: ${chapter.title} (${pStyle.label})\nমূল টপিক: ${chapter.keyTopics}"
                        clipboardManager.setText(AnnotatedString(copyStr))
                        Toast.makeText(context, "অধ্যায়ের তথ্য কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy chapter details",
                        tint = theme.accent
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = theme.deepTint),
                border = BorderStroke(1.3.dp, theme.accent)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(pStyle.bg)
                                .border(0.9.dp, pStyle.border, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = pStyle.fullLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = pStyle.text,
                                fontFamily = HindSiliguriFontFamily
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0A1426))
                                .border(0.8.dp, theme.borderTint, RoundedCornerShape(8.dp))
                                .padding(horizontal = 9.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = "Study Days",
                                    tint = theme.accent,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "প্রস্তুতি সময়: ${chapter.defaultDays} দিন",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    fontFamily = HindSiliguriFontFamily
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = chapter.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = HindSiliguriFontFamily
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "এসএসসি ২০২৮ বোর্ড পরীক্ষা • ${theme.nameBn} (${theme.nameEn})",
                        style = MaterialTheme.typography.bodySmall,
                        color = theme.pillText,
                        fontFamily = HindSiliguriFontFamily
                    )
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(onClick = onToggleComplete)
                    .testTag("social_ict_detail_completion_toggle"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCompleted) Color(0xFF064E3B).copy(alpha = 0.5f) else Color(0xFF0D1B32)
                ),
                border = BorderStroke(
                    1.2.dp,
                    if (isCompleted) EmeraldSuccess else theme.borderTint
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isCompleted) "অধ্যায়টি সম্পন্ন হিসেবে চিহ্নিত" else "অধ্যায়টি এখনও বাকি আছে",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isCompleted) Color(0xFF34D399) else TextPrimary,
                            fontFamily = HindSiliguriFontFamily
                        )
                        Text(
                            text = if (isCompleted) "আবার ট্যাপ করলে বাকি তালিকায় ফিরে যাবে" else "পড়া শেষ হলে এখানে ট্যাপ করে সম্পন্ন করুন",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                    Icon(
                        imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Completion status",
                        tint = if (isCompleted) EmeraldSuccess else TextTertiary,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B32)),
                border = BorderStroke(1.dp, theme.borderTint.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MenuBook, contentDescription = "Topics", tint = theme.accent, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "মূল আলোচ্য বিষয় ও পরীক্ষার ফোকাস",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = theme.accent,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = chapter.keyTopics,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        lineHeight = 22.sp,
                        fontFamily = HindSiliguriFontFamily
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF081424))
                            .border(0.8.dp, Color(0xFF1E3A5F), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "স্মার্ট প্রস্তুতি চেকলিস্ট:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = AmberGold,
                                fontFamily = HindSiliguriFontFamily
                            )
                            Text(
                                text = "১. মূল পাঠ্যবইয়ের গুরুত্বপূর্ণ তারিখ, সাল, অনুচ্ছেদ বা ট্যাগ নোট করুন\n২. সংক্ষিপ্ত ও অনুধাবনমূলক প্রশ্নগুলো আয়ত্ত করুন\n৩. বিগত বোর্ড পরীক্ষার ২৫+ MCQ ও CQ প্রশ্ন অনুশীলন করুন",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                lineHeight = 19.sp,
                                fontFamily = HindSiliguriFontFamily
                            )
                        }
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B32)),
                border = BorderStroke(1.dp, Color(0xFF1E3A5F))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Edit, contentDescription = "Personal Notes", tint = AmberGold, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ব্যক্তিগত নোট ও গুরুত্বপূর্ণ পয়েন্ট",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = AmberGold,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = noteDraft,
                        onValueChange = { noteDraft = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("social_ict_detail_note_input"),
                        placeholder = {
                            Text(
                                "গুরুত্বপূর্ণ তথ্য, আয়াত/হাদিস, ইতিহাস বা কোড সিনট্যাক্স লিখে সংরক্ষণ করুন...",
                                fontSize = 12.5.sp,
                                color = TextTertiary,
                                fontFamily = HindSiliguriFontFamily
                            )
                        },
                        minLines = 3,
                        maxLines = 6,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF081424),
                            unfocusedContainerColor = Color(0xFF081424),
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = Color(0xFF1E3A5F),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { onSaveNote(noteDraft.trim()) },
                        colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("social_ict_detail_save_note_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = Color(0xFF1A1002), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ব্যক্তিগত নোট সংরক্ষণ করুন",
                            color = Color(0xFF1A1002),
                            fontWeight = FontWeight.Bold,
                            fontFamily = HindSiliguriFontFamily
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onQuickAiSummary,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.2.dp, theme.accent),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "দ্রুত AI সারাংশ",
                        color = theme.accent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        fontFamily = HindSiliguriFontFamily
                    )
                }

                Button(
                    onClick = onOpenFullAiTutor,
                    colors = ButtonDefaults.buttonColors(containerColor = theme.accent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1.3f)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = "AI Tutor", tint = Color(0xFF04101D), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "MRH AI টিউটরে শিখুন",
                        color = Color(0xFF04101D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        fontFamily = HindSiliguriFontFamily
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}
