package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ScheduledTaskEntity
import com.example.ui.components.AiPulsingDot
import com.example.ui.components.ChapterProgressBar
import com.example.ui.components.ChapterStudySystemDialog
import com.example.ui.components.CyberCard
import com.example.ui.components.ExtendChapterDialog
import com.example.ui.components.MissedRecoveryDialog
import com.example.ui.components.QuickExplanationDialog
import com.example.ui.components.StudyPlanSetupDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyberGradient
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MainViewModel

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToAiChat: (String?) -> Unit,
    onNavigateToSyllabus: () -> Unit,
    onNavigateToExam: () -> Unit,
    onNavigateToPlanner: () -> Unit,
    onNavigateToMathPriority: () -> Unit = {},
    onNavigateToSciencePriority: () -> Unit = {},
    onNavigateToSocialIctPriority: () -> Unit = {},
    onNavigateToQuiz: () -> Unit = {},
    onNavigateToAgentPanel: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val totalMinutes by viewModel.totalStudyMinutes.collectAsState()
    val todayGoals by viewModel.todayGoals.collectAsState()
    val timerRemaining by viewModel.timerRemainingSeconds.collectAsState()
    val timerIsRunning by viewModel.timerIsRunning.collectAsState()
    val selectedSubject by viewModel.selectedTimerSubject.collectAsState()

    val activePlanConfig by viewModel.activePlanConfig.collectAsState()
    val allScheduledTasks by viewModel.allScheduledTasks.collectAsState()
    val planMetrics by viewModel.planMetrics.collectAsState()
    val bangla1Metrics by viewModel.bangla1Metrics.collectAsState()
    val mathMetrics by viewModel.mathPriorityMetrics.collectAsState()
    val scienceMetrics by viewModel.sciencePriorityMetrics.collectAsState()
    val socialIctMetrics by viewModel.socialIctPriorityMetrics.collectAsState()

    val quickExplainTitle by viewModel.quickExplainTitle.collectAsState()
    val quickExplainContent by viewModel.quickExplainContent.collectAsState()
    val isQuickExplainLoading by viewModel.isQuickExplainLoading.collectAsState()

    val todayTasks = allScheduledTasks.filter { it.dateString == viewModel.todayString }
    val missedTasks = allScheduledTasks.filter { it.dateString < viewModel.todayString && !it.isCompleted && !it.isRecovered }

    var newGoalText by remember { mutableStateOf("") }
    var showAddGoalInput by remember { mutableStateOf(false) }

    var showSetupDialog by remember { mutableStateOf(false) }
    var showRecoveryDialog by remember { mutableStateOf(false) }
    var selectedTaskForSystem by remember { mutableStateOf<ScheduledTaskEntity?>(null) }
    var selectedChapterForExtend by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Top App Bar branding
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_study_logo),
                        contentDescription = "MRH Study AI Logo",
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, NeonCyan, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "COMPLETE MRH",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "SSC 2028 COMEBACK",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            AiPulsingDot()
                        }
                    }
                }

                // Mission badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF311042), Color(0xFF10283A))))
                        .border(1.dp, NeonPurple, RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "Streak",
                            tint = AmberGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "মিশন ২০২৮",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Hero Banner Graphic (16:9 YouTube Aspect Ratio)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(18.dp))
                    .clickable { onNavigateToAiChat(null) },
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.2.dp, NeonCyan)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.banner_ssc_coach),
                        contentDescription = "SSC 2028 Comeback Study Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color(0x33070A13),
                                        Color(0xD9070A13)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "SSC 2028 COMEBACK",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            AiPulsingDot()
                        }
                        Text(
                            text = "MRH STUDY AI — পার্সোনাল স্টাডি কোচ",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "বাংলা ১ম পত্রের ৫৩টি অধ্যায় ও স্বয়ংসম্পূর্ণ বোর্ড রুটিন",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFE0F2FE)
                        )
                    }
                }
            }
        }

        // Quick MCQ Quiz Hub & Agent Panel Launch Card
        item {
            CyberCard(
                borderBrush = Brush.horizontalGradient(listOf(EmeraldSuccess, NeonCyan)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "স্মার্ট MCQ কুইজ ও এজেন্ট প্যানেল",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "১২ বিষয় • বই, অধ্যায়ভিত্তিক, টাইমড, এক্সাম ও এজেন্ট OCR কুইজ",
                                style = MaterialTheme.typography.bodySmall,
                                color = NeonCyan
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onNavigateToQuiz,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("dashboard_open_quiz_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Quiz,
                                contentDescription = "QUIZ",
                                tint = Color(0xFF031A24),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("QUIZ খুলুন", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onNavigateToAgentPanel,
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("dashboard_open_agent_panel_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Agent Panel",
                                tint = NeonPurple,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("এজেন্ট প্যানেল", color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Dedicated Bangla 1st Paper Complete Routine & Progress Section
        item {
            CyberCard(
                borderBrush = Brush.horizontalGradient(listOf(NeonCyan, Color(0xFF38BDF8))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "বাংলা ১ম পত্র সম্পূর্ণ রুটিন",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF033547))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "৫৩টি অধ্যায়",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NeonCyan,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            Text(
                                text = "গদ্য ২৫টি + কবিতা ২৮টি • মোট সময়সীমা: ${bangla1Metrics.plannedDays} দিন",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        IconButton(onClick = onNavigateToSyllabus) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = "View Syllabus",
                                tint = NeonCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Progress Overview Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "সম্পন্ন: ${bangla1Metrics.completedChapters}/৫৩ (${bangla1Metrics.percentage}%)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess
                        )
                        Text(
                            text = "বাকি: ${bangla1Metrics.remainingChapters}টি অধ্যায়",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberGold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    ChapterProgressBar(
                        completed = bangla1Metrics.completedChapters,
                        total = bangla1Metrics.totalChapters,
                        color = NeonCyan
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2 Section Breakdown: Prose (25) & Poetry (28)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Section 1: Prose Card
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToSyllabus() },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3A5F))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "বাংলা সাহিত্য — গদ্য",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "২৫টি অধ্যায় (১২টি ⭐)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NeonCyan,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "সম্পন্ন: ${bangla1Metrics.proseCompleted}/২৫",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldSuccess
                                    )
                                    val prosePct = if (bangla1Metrics.proseTotal > 0) (bangla1Metrics.proseCompleted * 100) / bangla1Metrics.proseTotal else 0
                                    Text(
                                        text = "$prosePct%",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }

                        // Section 2: Poetry Card
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToSyllabus() },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E1A47))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "বাংলা সাহিত্য — কবিতা",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "২৮টি কবিতা (১৬টি ⭐)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NeonPurple,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "সম্পন্ন: ${bangla1Metrics.poetryCompleted}/২৮",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldSuccess
                                    )
                                    val poetryPct = if (bangla1Metrics.poetryTotal > 0) (bangla1Metrics.poetryCompleted * 100) / bangla1Metrics.poetryTotal else 0
                                    Text(
                                        text = "$poetryPct%",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Subtask Metrics: MCQ, CQ, Board Questions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F1E2E))
                                .padding(8.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Text(text = "MCQ প্র্যাকটিস", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 10.sp)
                                Text(text = "${bangla1Metrics.mcqCompleted} টি", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = NeonCyan)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F1E2E))
                                .padding(8.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Text(text = "সৃজনশীল (CQ)", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 10.sp)
                                Text(text = "${bangla1Metrics.cqCompleted} টি", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = NeonPurple)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F1E2E))
                                .padding(8.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Text(text = "বোর্ড প্রশ্ন", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 10.sp)
                                Text(text = "${bangla1Metrics.boardCompleted} টি", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = AmberGold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onNavigateToSyllabus,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("৫৩টি অধ্যায় দেখুন", color = Color(0xFF031A24), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = { onNavigateToAiChat("বাংলা ১ম পত্রের গুরুত্বপূর্ণ সৃজনশীল ও MCQ এর পূর্ণাঙ্গ শর্ট সাজেশন দাও।") },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI",
                                    tint = NeonPurple,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("MRH AI সাজেশন", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // COMPLETE MRH: Mathematics Chapter Priority Dashboard Hero Card
        item {
            CyberCard(
                borderBrush = Brush.horizontalGradient(listOf(Color(0xFF00E5FF), Color(0xFFA855F7))),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToMathPriority() }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0284C7)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = "Math",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "COMPLETE MRH",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = NeonCyan
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF064E3B))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "⭐ ২৮টি গুরুত্বপূর্ণ",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 10.sp,
                                            color = EmeraldSuccess,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    text = "গণিত চ্যাপ্টার প্রায়োরিটি ড্যাশবোর্ড",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "সাধারণ গণিত (১৭) + উচ্চতর গণিত (১৪) = ৩১টি অধ্যায়",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF064E3B))
                                .border(1.dp, Color(0xFF10B981), RoundedCornerShape(12.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${mathMetrics.totalPercent}%",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF34D399)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { mathMetrics.totalPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = NeonCyan,
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // General Math
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0C1929))
                                .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "সাধারণ গণিত", style = MaterialTheme.typography.labelSmall, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                                Text(text = "সম্পন্ন: ${mathMetrics.generalMathCompleted}/১৭ (${mathMetrics.generalMathPercent}%)", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                            }
                        }

                        // Higher Math
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0C1929))
                                .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "উচ্চতর গণিত", style = MaterialTheme.typography.labelSmall, color = Color(0xFFC084FC), fontWeight = FontWeight.Bold)
                                Text(text = "সম্পন্ন: ${mathMetrics.higherMathCompleted}/১৪ (${mathMetrics.higherMathPercent}%)", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onNavigateToMathPriority,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_math_priority_button")
                    ) {
                        Icon(imageVector = Icons.Default.Calculate, contentDescription = "Math", tint = Color(0xFF021722))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "৩১টি অধ্যায়ের প্রায়োরিটি ড্যাশবোর্ড খুলুন",
                            color = Color(0xFF021722),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // COMPLETE MRH: Science Chapter Priority Dashboard Hero Card
        item {
            CyberCard(
                borderBrush = Brush.horizontalGradient(
                    listOf(Color(0xFF38BDF8), Color(0xFFA855F7), Color(0xFF10B981))
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToSciencePriority() }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFF0284C7), Color(0xFF7C3AED))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Science,
                                    contentDescription = "Science",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "COMPLETE MRH",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = NeonCyan
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF064E3B))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "⭐ ${scienceMetrics.importantCount}টি গুরুত্বপূর্ণ",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 10.sp,
                                            color = EmeraldSuccess,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    text = "বিজ্ঞান চ্যাপ্টার প্রায়োরিটি ড্যাশবোর্ড",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "পদার্থ (১৩) • রসায়ন (১২) • জীববিজ্ঞান (১৪) = ৩৯ অধ্যায়",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF064E3B))
                                .border(1.dp, Color(0xFF10B981), RoundedCornerShape(12.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${scienceMetrics.totalPercent}%",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF34D399)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { scienceMetrics.totalPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = Color(0xFF38BDF8),
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Subject Breakdown: Physics Blue / Chemistry Purple / Biology Green
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0A1F38))
                                .border(1.dp, Color(0xFF0284C7), RoundedCornerShape(10.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "পদার্থবিজ্ঞান", style = MaterialTheme.typography.labelSmall, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                                Text(text = "${scienceMetrics.physicsCompleted}/${scienceMetrics.physicsTotal} (${scienceMetrics.physicsPercent}%)", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF1F1135))
                                .border(1.dp, Color(0xFF7C3AED), RoundedCornerShape(10.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "রসায়ন", style = MaterialTheme.typography.labelSmall, color = Color(0xFFC084FC), fontWeight = FontWeight.Bold)
                                Text(text = "${scienceMetrics.chemistryCompleted}/${scienceMetrics.chemistryTotal} (${scienceMetrics.chemistryPercent}%)", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF092420))
                                .border(1.dp, Color(0xFF059669), RoundedCornerShape(10.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "জীববিজ্ঞান", style = MaterialTheme.typography.labelSmall, color = Color(0xFF34D399), fontWeight = FontWeight.Bold)
                                Text(text = "${scienceMetrics.biologyCompleted}/${scienceMetrics.biologyTotal} (${scienceMetrics.biologyPercent}%)", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onNavigateToSciencePriority,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_science_priority_button")
                    ) {
                        Icon(imageVector = Icons.Default.Science, contentDescription = "Science", tint = Color(0xFF021722))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "৩৯টি বিজ্ঞান অধ্যায়ের প্রায়োরিটি ড্যাশবোর্ড খুলুন",
                            color = Color(0xFF021722),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // COMPLETE MRH: BGS, Islam Education & ICT Priority Dashboard Hero Card
        item {
            CyberCard(
                borderBrush = Brush.horizontalGradient(
                    listOf(Color(0xFF38BDF8), Color(0xFF10B981), Color(0xFFA855F7))
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToSocialIctPriority() }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFF0284C7), Color(0xFF10B981))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Public,
                                    contentDescription = "BGS Islam ICT",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "COMPLETE MRH",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = NeonCyan
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF064E3B))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "⭐ ${socialIctMetrics.importantCount}টি গুরুত্বপূর্ণ",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 10.sp,
                                            color = EmeraldSuccess,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    text = "BGS, ইসলাম ও ICT প্রায়োরিটি ড্যাশবোর্ড",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "BGS (১৪) • ইসলাম শিক্ষা (৫) • ICT (৭) = ২৬ অধ্যায়",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF064E3B))
                                .border(1.dp, Color(0xFF10B981), RoundedCornerShape(12.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${socialIctMetrics.totalPercent}%",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF34D399)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { socialIctMetrics.totalPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = EmeraldSuccess,
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Subject Breakdown: BGS Blue / Islam Emerald / ICT Purple
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0A1F38))
                                .border(1.dp, Color(0xFF0284C7), RoundedCornerShape(10.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "BGS", style = MaterialTheme.typography.labelSmall, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                                Text(text = "${socialIctMetrics.bgsCompleted}/${socialIctMetrics.bgsTotal} (${socialIctMetrics.bgsPercent}%)", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF06261E))
                                .border(1.dp, Color(0xFF059669), RoundedCornerShape(10.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "ইসলাম শিক্ষা", style = MaterialTheme.typography.labelSmall, color = Color(0xFF34D399), fontWeight = FontWeight.Bold)
                                Text(text = "${socialIctMetrics.islamCompleted}/${socialIctMetrics.islamTotal} (${socialIctMetrics.islamPercent}%)", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF1F1135))
                                .border(1.dp, Color(0xFF7C3AED), RoundedCornerShape(10.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "ICT", style = MaterialTheme.typography.labelSmall, color = Color(0xFFC084FC), fontWeight = FontWeight.Bold)
                                Text(text = "${socialIctMetrics.ictCompleted}/${socialIctMetrics.ictTotal} (${socialIctMetrics.ictPercent}%)", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onNavigateToSocialIctPriority,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_social_ict_priority_button")
                    ) {
                        Icon(imageVector = Icons.Default.Public, contentDescription = "BGS Islam ICT", tint = Color(0xFF021722))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "২৬টি BGS, ইসলাম ও ICT অধ্যায় ড্যাশবোর্ড খুলুন",
                            color = Color(0xFF021722),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Feature 7: Study Planner Comprehensive Metrics Dashboard
        item {
            CyberCard(
                borderBrush = CyberGradient,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "এসএসসি ২০২৮ ভবিষ্যৎ স্টাডি প্ল্যান",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "মোট ${planMetrics.totalPlanDays} দিন • দৈনিক ${planMetrics.dailyHours} ঘণ্টা • লক্ষ্য: ${planMetrics.targetCompletionDate}",
                                style = MaterialTheme.typography.bodySmall,
                                color = NeonCyan
                            )
                        }

                        IconButton(
                            onClick = { showSetupDialog = true },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceVariant)
                        ) {
                            Icon(imageVector = Icons.Default.Settings, contentDescription = "Config", tint = NeonCyan)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Syllabus Percentage Progress Bar
                    ChapterProgressBar(
                        completed = planMetrics.completedChapters,
                        total = planMetrics.totalChapters,
                        color = NeonCyan
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Grid Metrics: Total, Completed, Remaining Chapters & Days
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkSurfaceVariant)
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "মোট অধ্যায়", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(text = "${planMetrics.totalChapters}টি", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkSurfaceVariant)
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "সম্পন্ন অধ্যায়", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(text = "${planMetrics.completedChapters}টি", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkSurfaceVariant)
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "অবশিষ্ট অধ্যায়", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(text = "${planMetrics.remainingChapters}টি", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NeonPink)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkSurfaceVariant)
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "অবশিষ্ট দিন", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(text = "${planMetrics.remainingDays} দিন", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AmberGold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Pending Practice Items: Pending MCQs, CQs, Board Questions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F2338))
                                .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "বকেয়া MCQ", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                                Text(text = "${planMetrics.pendingMcqCount}টি", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF28113A))
                                .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "বকেয়া CQ", style = MaterialTheme.typography.labelSmall, color = NeonPurple)
                                Text(text = "${planMetrics.pendingCqCount}টি", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0D2820))
                                .border(1.dp, EmeraldSuccess.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "বোর্ড প্রশ্ন", style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess)
                                Text(text = "${planMetrics.pendingBoardQuestionCount}টি", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                        }
                    }

                    // Missed tasks recovery alert inside dashboard
                    if (missedTasks.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF3B1219))
                                .clickable { showRecoveryDialog = true }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = "Missed", tint = AmberGold, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "${missedTasks.size}টি মিসড পড়া চিহ্নিত হয়েছে", style = MaterialTheme.typography.labelSmall, color = AmberGold, fontWeight = FontWeight.Bold)
                            }
                            Text(text = "রিকভার প্ল্যান >", style = MaterialTheme.typography.labelSmall, color = NeonCyan, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Today's Scheduled Chapter Tasks from Future Planner
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "আজকের শিডিউল টাস্ক (Future Plan)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    TextButton(onClick = onNavigateToPlanner) {
                        Text(text = "সম্পূর্ণ শিডিউল >", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                    }
                }

                if (todayTasks.isEmpty()) {
                    CyberCard(modifier = Modifier.fillMaxWidth()) {
                        Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                            Text(
                                text = "আজকের জন্য কোনো টাস্ক বাকি নেই! সম্পূর্ণ শিডিউল দেখতে প্ল্যানার ট্যাবে যান।",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                } else {
                    todayTasks.forEach { task ->
                        val phaseDoneCount = listOf(
                            task.textbookRead, task.conceptUnderstood, task.notesCreated,
                            task.mcqPracticeCompleted, task.cqPracticeCompleted, task.boardQuestionsSolved,
                            task.chapterTestCompleted, task.mistakesReviewed
                        ).count { it }

                        CyberCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            onClick = { selectedTaskForSystem = task }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${task.subjectName} • দিন ${task.dayNumber}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = NeonCyan
                                    )
                                    Text(
                                        text = "${task.allocatedHours} ঘণ্টা বরাদ্দ",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { viewModel.toggleTaskCompleteDirectly(task.id, task.isCompleted) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                            contentDescription = "Status",
                                            tint = if (task.isCompleted) EmeraldSuccess else TextSecondary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = task.chapterTitle,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (task.isCompleted) TextTertiary else TextPrimary
                                        )
                                        Text(
                                            text = "৮-ধাপ প্রস্তুতি: $phaseDoneCount/৮ সম্পন্ন",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (phaseDoneCount == 8) EmeraldSuccess else TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(onClick = { selectedTaskForSystem = task }) {
                                        Text("৮-ধাপ চেকলিস্ট", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                                    }
                                    TextButton(onClick = { selectedChapterForExtend = task.chapterTitle }) {
                                        Icon(imageVector = Icons.Default.MoreTime, contentDescription = "Extend", tint = NeonPurple, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Extend Time", style = MaterialTheme.typography.labelSmall, color = NeonPurple)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Focus Study Timer Card
        item {
            CyberCard(
                borderBrush = CyberGradient,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Timer",
                                tint = NeonCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "স্টাডি ফোকাস টাইমার (Pomodoro)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = selectedSubject,
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonPurple,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Timer Display & Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val minutes = timerRemaining / 60
                        val seconds = timerRemaining % 60
                        val timeFormatted = String.format("%02d:%02d", minutes, seconds)

                        Column {
                            Text(
                                text = timeFormatted,
                                style = MaterialTheme.typography.displayLarge.copy(fontSize = 38.sp),
                                fontWeight = FontWeight.Bold,
                                color = if (timerIsRunning) NeonCyan else TextPrimary
                            )
                            Text(
                                text = if (timerIsRunning) "মনোযোগ দিয়ে পড়ো..." else "২৫ মিনিটের সেশন",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.resetTimer() },
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(DarkSurfaceVariant)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Reset Timer",
                                    tint = TextSecondary
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    if (timerIsRunning) viewModel.pauseTimer() else viewModel.startTimer()
                                },
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (timerIsRunning) NeonPink else NeonCyan
                                ),
                                modifier = Modifier
                                    .size(54.dp)
                                    .testTag("timer_toggle_button"),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                            ) {
                                Icon(
                                    imageVector = if (timerIsRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play or Pause",
                                    tint = Color(0xFF031A24),
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Today's Goals Section
        item {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "আজকের স্টাডি গোল",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        IconButton(
                            onClick = { showAddGoalInput = !showAddGoalInput },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Goal",
                                tint = NeonCyan
                            )
                        }
                    }

                    if (showAddGoalInput) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newGoalText,
                                onValueChange = { newGoalText = it },
                                placeholder = { Text("নতুন লক্ষ্য লিখুন (যেমন: ২০টি MCQ সলভ)", fontSize = 13.sp) },
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonCyan,
                                    unfocusedBorderColor = BorderGlow,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (newGoalText.isNotBlank()) {
                                        viewModel.addNewGoal(newGoalText.trim(), 30)
                                        newGoalText = ""
                                        showAddGoalInput = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("যোগ", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (todayGoals.isEmpty()) {
                        Text(
                            text = "আজকের জন্য কোনো গোল সেট করা হয়নি। '+' বাটনে ক্লিক করে যোগ করুন।",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextTertiary
                        )
                    } else {
                        todayGoals.forEach { goal ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { viewModel.toggleGoal(goal.id, goal.isCompleted) }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (goal.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = "Status",
                                    tint = if (goal.isCompleted) EmeraldSuccess else TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = goal.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (goal.isCompleted) TextTertiary else TextPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { viewModel.deleteGoal(goal.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = TextTertiary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Quick AI Study Prompts
        item {
            Column {
                Text(
                    text = "MRH AI কুইক স্টাডি অ্যাসিস্ট্যান্ট",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))

                val quickPrompts = listOf(
                    "আমাকে সাধারণ গণিতের ৩য় অধ্যায়ের বীজগণিতের মান নির্ণয়ের ৫টি মোস্ট ইম্পরট্যান্ট অঙ্ক ধাপে ধাপে সমাধান করে দাও।" to "গণিত সমাধান",
                    "পদার্থবিজ্ঞান ৩য় অধ্যায় (বল)-এর নিউটনের গতির দ্বিতীয় সূত্র এবং ভরবেগের সংরক্ষণশীলতার বাস্তব উদাহরণসহ ব্যাখ্যা করো।" to "পদার্থ বিজ্ঞান",
                    "রসায়ন অধ্যায় ৬: মোলের ধারণা ও রাসায়নিক গণনার লিমিটিং বিক্রিয়ক নির্ণয়ের নিয়ম বাংলায় পানির মতো সহজ করে শেখাও।" to "রসায়ন সহজ ব্যাখ্যা",
                    "ইংরেজি ২য় পত্র: Right form of verbs-এর শীর্ষ ৫টি নিয়ম ও উদাহরণ যা এসএসসি বোর্ড পরীক্ষায় প্রতি বছর আসে।" to "English Grammar"
                )

                quickPrompts.forEach { (prompt, label) ->
                    CyberCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onNavigateToAiChat(prompt) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF1E293B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = NeonCyan
                                )
                                Text(
                                    text = prompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Dialogs
    if (showSetupDialog) {
        StudyPlanSetupDialog(
            currentConfig = activePlanConfig,
            onDismiss = { showSetupDialog = false },
            onGeneratePlan = { durationMonths, dailyHours, startDateMillis, easyDays, normalDays, difficultDays, veryDifficultDays ->
                viewModel.generateNewStudyPlan(
                    durationMonths = durationMonths,
                    dailyHours = dailyHours,
                    startDateMillis = startDateMillis,
                    easyDays = easyDays,
                    normalDays = normalDays,
                    difficultDays = difficultDays,
                    veryDifficultDays = veryDifficultDays
                )
            }
        )
    }

    if (selectedTaskForSystem != null) {
        val currentTask = allScheduledTasks.find { it.id == selectedTaskForSystem!!.id } ?: selectedTaskForSystem!!
        ChapterStudySystemDialog(
            task = currentTask,
            onDismiss = { selectedTaskForSystem = null },
            onToggleStep = { stepIndex -> viewModel.toggleTaskStep(currentTask, stepIndex) },
            onUpdateTimeAllocations = { textbook, mcq, cq, board, revision ->
                viewModel.updateTaskTimeAllocations(currentTask.id, textbook, mcq, cq, board, revision)
            },
            onOpenExtendDialog = {
                selectedChapterForExtend = currentTask.chapterTitle
            },
            onAskAi = { title, prompt ->
                viewModel.requestQuickExplanation(title, prompt)
            }
        )
    }

    if (selectedChapterForExtend != null) {
        ExtendChapterDialog(
            chapterTitle = selectedChapterForExtend!!,
            onDismiss = { selectedChapterForExtend = null },
            onConfirmExtension = { extraDays ->
                viewModel.extendChapterTime(selectedChapterForExtend!!, extraDays)
                selectedChapterForExtend = null
            }
        )
    }

    if (showRecoveryDialog) {
        MissedRecoveryDialog(
            missedTasks = missedTasks,
            onDismiss = { showRecoveryDialog = false },
            onRecoverAll = { viewModel.recoverAllMissedTasks() },
            onMarkTaskRecovered = { taskId -> viewModel.markTaskRecovered(taskId) }
        )
    }

    QuickExplanationDialog(
        title = quickExplainTitle,
        content = quickExplainContent,
        isLoading = isQuickExplainLoading,
        onDismiss = { viewModel.closeQuickExplanation() }
    )
}
