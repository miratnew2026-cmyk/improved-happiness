package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Tracks syllabus chapter completion, personal notes, and sync readiness.
 */
@Entity(tableName = "chapter_progress")
data class ChapterProgressEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val subjectId: String,
    val chapterNumber: Int,
    val chapterTitle: String,
    val isCompleted: Boolean = false,
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)

/**
 * Records focused study sessions logged by the Study Timer.
 */
@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val subjectName: String,
    val durationMinutes: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val sessionType: String = "Pomodoro",
    val isSynced: Boolean = false
)

/**
 * Daily goals for the SSC 2028 preparation plan.
 */
@Entity(tableName = "daily_goals")
data class DailyGoalEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val targetMinutes: Int = 30,
    val isCompleted: Boolean = false,
    val dateString: String, // e.g. "2026-11-07"
    val updatedAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)

/**
 * Saves exam scores, model test results, and weak topic tags.
 */
@Entity(tableName = "exam_results")
data class ExamResultEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val examTitle: String,
    val subjectName: String,
    val score: Int,
    val totalQuestions: Int,
    val accuracyPercentage: Float,
    val weakTopics: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)

/**
 * Tracks wrong answers during MCQ/CQ practice so students can master their weak spots.
 */
@Entity(tableName = "mistakes_notebook")
data class MistakeEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val subjectName: String,
    val chapterTitle: String,
    val questionText: String,
    val studentAnswer: String,
    val correctAnswer: String,
    val explanation: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isResolved: Boolean = false,
    val isSynced: Boolean = false
)

/**
 * Persists MRH STUDY AI study chat conversation history locally.
 */
@Entity(tableName = "chat_history")
data class ChatMessageEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // "user" or "ai"
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isError: Boolean = false
)

/**
 * Global configuration for the student's active Future Study Plan.
 */
@Entity(tableName = "study_plan_config")
data class StudyPlanConfigEntity(
    @PrimaryKey
    val id: String = "active_plan",
    val durationMonths: Int = 4, // 4, 5, or 6 Months
    val dailyStudyHours: Int = 4, // 4, 5, or 6 Hours
    val startDateMillis: Long = System.currentTimeMillis(),
    val targetCompletionDateMillis: Long = System.currentTimeMillis() + 120L * 24 * 60 * 60 * 1000,
    val extendedDaysTotal: Int = 0,
    val easyChapterDays: Int = 1,
    val normalChapterDays: Int = 2,
    val difficultChapterDays: Int = 3,
    val veryDifficultChapterDays: Int = 5,
    val totalPlanDays: Int = 120,
    val createdAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)

/**
 * Scheduled daily study task generated for the entire plan duration.
 */
@Entity(tableName = "scheduled_study_tasks")
data class ScheduledTaskEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val dayNumber: Int, // 1 to 120/150/180
    val dateString: String, // "YYYY-MM-DD"
    val dateMillis: Long,
    val subjectId: String,
    val subjectName: String,
    val chapterNumber: Int,
    val chapterTitle: String,
    val taskType: String = "CHAPTER_STUDY", // "CHAPTER_STUDY", "REVISION", "BOARD_PRACTICE", "MODEL_TEST", "RECOVERY"
    val allocatedHours: Float = 2.0f,
    
    // Feature 3: The 8-phase study system checklists
    val textbookRead: Boolean = false,
    val conceptUnderstood: Boolean = false,
    val notesCreated: Boolean = false,
    val mcqPracticeCompleted: Boolean = false,
    val cqPracticeCompleted: Boolean = false,
    val boardQuestionsSolved: Boolean = false,
    val chapterTestCompleted: Boolean = false,
    val mistakesReviewed: Boolean = false,

    // Time assignments (in minutes) for each study phase
    val textbookMinutes: Int = 30,
    val mcqMinutes: Int = 25,
    val cqMinutes: Int = 35,
    val boardSolveMinutes: Int = 20,
    val revisionMinutes: Int = 10,

    // Quantitative metrics
    val mcqCount: Int = 25,
    val cqCount: Int = 3,
    val boardQuestionCount: Int = 8,

    // Completion and Extension
    val isCompleted: Boolean = false,
    val isRecovered: Boolean = false,
    val extendedDays: Int = 0,
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)
