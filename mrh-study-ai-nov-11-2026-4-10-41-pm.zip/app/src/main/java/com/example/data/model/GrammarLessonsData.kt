package com.example.data.model

data class GrammarRule(
    val title: String,
    val explanationBn: String,
    val formulaOrStructure: String,
    val examples: List<String>,
    val boardTip: String
)

data class GrammarTopic(
    val id: String,
    val title: String,
    val subtitleBn: String,
    val iconName: String,
    val rules: List<GrammarRule>
)

object GrammarLessonsData {
    val topics = listOf(
        GrammarTopic(
            id = "parts_of_speech",
            title = "1. Parts of Speech & Basics",
            subtitleBn = "পদ প্রকরণ ও শব্দের গঠনগত রূপ",
            iconName = "category",
            rules = listOf(
                GrammarRule(
                    title = "Noun & Identification Suffixes",
                    explanationBn = "যে শব্দ দ্বারা কোনো ব্যক্তি, বস্তু, স্থান বা গুণের নাম বোঝায়। শব্দের শেষে -tion, -sion, -ment, -ness, -ity, -ance, -ence থাকলে সাধারণত Noun হয়।",
                    formulaOrStructure = "Suffix: -tion (Education), -ment (Development), -ness (Kindness)",
                    examples = listOf(
                        "Knowledge is power. ('Knowledge' is an Abstract Noun)",
                        "The honesty of the boy surprised us."
                    ),
                    boardTip = "Suffix-Prefix প্রশ্নে Noun রূপান্তর প্রায়শই আসে।"
                ),
                GrammarRule(
                    title = "Adjective vs Adverb",
                    explanationBn = "Adjective কোনো Noun/Pronoun কে বিশেষায়িত করে। আর Adverb কোনো Verb, Adjective বা অন্য Adverb কে মডিফাই করে। সাধারণত Adjective + ly = Adverb (Slow -> Slowly)। তবে Friendly, Lovely হলো Adjective!",
                    formulaOrStructure = "Noun + ly = Adjective; Adjective + ly = Adverb",
                    examples = listOf(
                        "He runs quickly. ('Quickly' modifies the verb 'runs')",
                        "She is a lovely girl. ('Lovely' is an adjective)"
                    ),
                    boardTip = "Friend + ly = Friendly (Adjective, নট Adverb!) খেয়াল রেখো।"
                )
            )
        ),
        GrammarTopic(
            id = "tenses",
            title = "2. Tense Master Guide",
            subtitleBn = "কাল ও ক্রিয়ার রূপের ১২টি নিয়ম",
            iconName = "schedule",
            rules = listOf(
                GrammarRule(
                    title = "Present Indefinite & 3rd Person Singular",
                    explanationBn = "নিয়মিত বা চিরন্তন সত্য কাজের ক্ষেত্রে Present Indefinite Tense হয়। Subject যদি ৩য় পুরুষ একবচন (He, She, It, যেকোনো একক নাম) হয়, তবে মূল Verb-এর শেষে s/es যুক্ত হয়।",
                    formulaOrStructure = "Subject + Verb(s/es) + Object",
                    examples = listOf(
                        "The sun rises in the east.",
                        "He goes to school every day."
                    ),
                    boardTip = "Every day, always, regular থাকলে Present Indefinite বসবে।"
                ),
                GrammarRule(
                    title = "Past Perfect with 'Before' & 'After'",
                    explanationBn = "অতীতের দুটি কাজের মধ্যে পূর্বে ঘটা কাজের ক্ষেত্রে Past Perfect (had + V3) এবং পরের কাজের জন্য Past Simple (V2) হয়। মনে রাখার ট্রিক: Before এর পূর্বে Had, After এর পরে Had!",
                    formulaOrStructure = "Past Perfect + BEFORE + Past Indefinite | Past Indefinite + AFTER + Past Perfect",
                    examples = listOf(
                        "The train had left before we reached the station.",
                        "The doctor came after the patient had died."
                    ),
                    boardTip = "বোর্ড পরীক্ষায় এই দুটি সূত্র থেকে প্রায় প্রতি বছর ১টি প্রশ্ন নিশ্চিত থাকে।"
                )
            )
        ),
        GrammarTopic(
            id = "right_form_of_verbs",
            title = "3. Right Form of Verbs",
            subtitleBn = "ক্রিয়ার সঠিক রূপ নির্ণয়",
            iconName = "check_circle",
            rules = listOf(
                GrammarRule(
                    title = "Since & As if / As though",
                    explanationBn = "যদি Since-এর প্রথম অংশ Present Indefinite/Perfect হয়, তবে পরের অংশ Past Indefinite হবে। আর ১ম অংশ Past Indefinite হলে পরের অংশ Past Perfect হবে। As if / As though-এর পর 'to be' verb আসলে সর্বদা 'were' বসে।",
                    formulaOrStructure = "Present + SINCE + Past Indefinite | Past Indefinite + SINCE + Past Perfect",
                    examples = listOf(
                        "Many years have passed since I met you last.",
                        "It was long since we had seen each other.",
                        "He speaks as if he knew everything / as if he were a leader."
                    ),
                    boardTip = "অবাস্তব কল্পনা বোঝালে Was এর বদলে Were বসানো বাধ্যতামূলক।"
                ),
                GrammarRule(
                    title = "With a view to / Look forward to",
                    explanationBn = "Preposition-এর পর সাধারণত Verb + ing হয়। 'To'-এর পর বেস ফর্ম হলেও With a view to, look forward to, get used to, be accustomed to-এর পর Verb + ing হয়।",
                    formulaOrStructure = "With a view to / Look forward to + (Verb + ing)",
                    examples = listOf(
                        "He went to the library with a view to reading books.",
                        "I am looking forward to hearing from you soon."
                    ),
                    boardTip = "শুধুমাত্র To থাকলে V1, কিন্তু With a view to থাকলে V + ing।"
                )
            )
        ),
        GrammarTopic(
            id = "transformation",
            title = "4. Transformation of Sentences",
            subtitleBn = "বাক্যের রূপান্তর (Voice, Degree, Simple/Complex)",
            iconName = "transform",
            rules = listOf(
                GrammarRule(
                    title = "Simple - Complex - Compound",
                    explanationBn = "Simple বাক্যে ১টি মাত্র Finite Verb থাকে। Complex-এ একটি Principal এবং এক বা একাধিক Subordinate Clause থাকে (Though, Although, Since, As, When, If দিয়ে যুক্ত)। Compound-এ Co-ordinating Conjunction (And, But, Or, Yet) থাকে।",
                    formulaOrStructure = "Simple: In spite of / Despite | Complex: Though / Although | Compound: But",
                    examples = listOf(
                        "Simple: In spite of his poverty, he is honest.",
                        "Complex: Though he is poor, he is honest.",
                        "Compound: He is poor but he is honest."
                    ),
                    boardTip = "Despite-এর সাথে কখনো 'of' বসে না (Despite his poverty, NOT Despite of)!"
                ),
                GrammarRule(
                    title = "Passive Voice of Interrogative Sentences",
                    explanationBn = "হু (Who) থাকলে By whom এবং হুম (Whom) থাকলে Who দিয়ে Passive শুরু হয়। অক্সিলিয়ারি ভার্ব Subject-এর পূর্বে চলে আসে।",
                    formulaOrStructure = "Who + V... -> By whom + Aux + Sub + V3?",
                    examples = listOf(
                        "Active: Who wrote Hamlet?",
                        "Passive: By whom was Hamlet written?",
                        "Active: Whom did you call?",
                        "Passive: Who was called by you?"
                    ),
                    boardTip = "Interrogative বাক্যের শেষে প্রশ্নবোধক চিহ্ন (?) দিতে ভুলবে না।"
                )
            )
        ),
        GrammarTopic(
            id = "prepositions",
            title = "5. Appropriate Prepositions",
            subtitleBn = "বোর্ড পরীক্ষার সেরা অ্যাপ্রোপ্রিয়েট প্রেপোজিশন",
            iconName = "link",
            rules = listOf(
                GrammarRule(
                    title = "Top Board Appropriate Prepositions List",
                    explanationBn = "কিছু শব্দের পর নির্দিষ্ট Preposition বরাদ্দ থাকে যা অর্থ প্রকাশ করে। এগুলো মুখস্থ ও নিয়মিত রিভিশন করা আবশ্যক।",
                    formulaOrStructure = "Word + Fixed Preposition + Context",
                    examples = listOf(
                        "Abide by (মেনে চলা): We must abide by the school rules.",
                        "Good at (দক্ষ): She is very good at mathematics.",
                        "Senior to / Junior to (সিনিয়র): He is senior to me by two years (NOT than).",
                        "Devoted to (নিয়োজিত): Mother Teresa was devoted to social welfare.",
                        "Refrain from (বিরত থাকা): Refrain from telling lies."
                    ),
                    boardTip = "Senior, Junior, Superior, Inferior-এর পর 'than' নয়, সর্বদা 'to' বসে।"
                )
            )
        ),
        GrammarTopic(
            id = "narration",
            title = "6. Direct & Indirect Speech (Narration)",
            subtitleBn = "উক্তি পরিবর্তন ও প্যাসেজ ন্যারেশন",
            iconName = "record_voice_over",
            rules = listOf(
                GrammarRule(
                    title = "Tense Changes in Indirect Speech",
                    explanationBn = "Reporting verb অতীত কালের (said) হলে Reported Speech-এর Tense অনুরূপ অতীতে পরিবর্তিত হয়। Present Indefinite -> Past Indefinite; Present Continuous -> Past Continuous; Present Perfect -> Past Perfect; Past Indefinite -> Past Perfect.",
                    formulaOrStructure = "V1 -> V2; Am/Is/Are -> Was/Were; Have/Has -> Had; Did/V2 -> Had + V3",
                    examples = listOf(
                        "Direct: He said, 'I am ill.'",
                        "Indirect: He said that he was ill.",
                        "Direct: She said, 'I went there.'",
                        "Indirect: She said that she had gone there."
                    ),
                    boardTip = "চিরন্তন সত্য হলে Tense-এর কোনো পরিবর্তন হবে না (The teacher said that the earth moves round the sun)."
                )
            )
        ),
        GrammarTopic(
            id = "connectors_modifiers",
            title = "7. Connectors, Modifiers & Tag Questions",
            subtitleBn = "সংযোজক, পরিবর্তনকারী ও প্রশ্নচিহ্ন",
            iconName = "compare_arrows",
            rules = listOf(
                GrammarRule(
                    title = "Tag Questions Golden Rules",
                    explanationBn = "মূল বাক্য Affirmative হলে Tag Negative (n't) হবে। মূল বাক্য Negative হলে Tag Affirmative হবে। Let's থাকলে 'shall we?' এবং Imperative sentence-এ আদেশ/অনুরোধ বোঝালে 'will you?' হয়।",
                    formulaOrStructure = "Affirmative Statement, Negative Tag? | Negative Statement, Affirmative Tag?",
                    examples = listOf(
                        "He knows you, doesn't he?",
                        "Let's play football, shall we?",
                        "Open the door, will you?",
                        "Barking dogs seldom bite, do they? ('seldom' is negative)"
                    ),
                    boardTip = "Hardly, scarcely, seldom, rarely, few, little থাকলে বাক্যটি Negative ধরা হয়।"
                )
            )
        ),
        GrammarTopic(
            id = "writing_skills",
            title = "8. Writing Skills (CV, Letter & Paragraph)",
            subtitleBn = "কম্পোজিশন ও লিখিত অংশের সর্বোচ্চ নম্বর তোলার কৌশল",
            iconName = "edit_note",
            rules = listOf(
                GrammarRule(
                    title = "CV with Cover Letter Format",
                    explanationBn = "CV-তে প্রথমে Cover letter (Date, Receiver, Subject, Salutation, Body, Signature) এবং পরে Resume (Personal Details, Academic Qualifications table, Experience, References) থাকবে।",
                    formulaOrStructure = "Cover Letter (Left page) + Detailed Resume / Biodata (Right page)",
                    examples = listOf(
                        "Academic Table Columns: Exam/Degree, Board/University, Year of Passing, GPA/CGPA",
                        "References: At least two reputable persons with contact details."
                    ),
                    boardTip = "CV অবশ্যই পাশাপাশি দুই পৃষ্ঠায় (Left-to-Right facing pages) লিখতে হবে।"
                )
            )
        )
    )
}
