package com.example.data.remote

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject

enum class OperationType(val value: String) {
    CREATE("create"),
    UPDATE("update"),
    DELETE("delete"),
    LIST("list"),
    GET("get"),
    WRITE("write")
}

fun handleFirestoreError(
    exception: Throwable,
    operationType: OperationType,
    path: String?
): String {
    val causes = generateSequence(exception) { it.cause }
    val rootError = causes.firstOrNull { it is FirebaseFirestoreException }
        ?: causes.firstOrNull { it !is CancellationException }
        ?: exception

    val currentUser = try {
        Firebase.auth.currentUser
    } catch (_: Exception) {
        null
    }

    val providerInfoList = currentUser?.providerData?.map { provider ->
        JSONObject().apply {
            put("providerId", provider.providerId)
            put("email", provider.email)
        }
    } ?: emptyList()

    val authInfoJson = JSONObject().apply {
        put("userId", currentUser?.uid)
        put("email", currentUser?.email)
        put("emailVerified", currentUser?.isEmailVerified)
        put("tenantId", currentUser?.tenantId)
        put("providerInfo", JSONArray(providerInfoList))
    }

    val errorInfoJson = JSONObject().apply {
        put("error", rootError.message ?: rootError.toString())
        put("operationType", operationType.value)
        put("path", path)
        put("authInfo", authInfoJson)
    }

    val jsonString = errorInfoJson.toString()
    Log.e("FirestoreError", "Firestore Error: $jsonString")
    return jsonString
}

fun Throwable.unwrapFirestoreException(): FirebaseFirestoreException? {
    var current: Throwable? = this
    while (current != null) {
        if (current is FirebaseFirestoreException) return current
        current = current.cause
    }
    return null
}

fun Throwable.userFriendlyFirestoreMessage(fallback: String): String {
    val fsEx = unwrapFirestoreException()
    return when (fsEx?.code) {
        FirebaseFirestoreException.Code.PERMISSION_DENIED ->
            "অনুমতি নেই: এই কাজের জন্য আপনার অ্যাকাউন্ট অনুমোদিত নয় বা সেশন যাচাই হয়নি।"
        FirebaseFirestoreException.Code.UNAUTHENTICATED ->
            "অনুগ্রহ করে প্রথমে Google অ্যাকাউন্ট দিয়ে লগইন করুন।"
        FirebaseFirestoreException.Code.UNAVAILABLE ->
            "সার্ভারের সাথে সংযোগ বিচ্ছিন্ন হয়েছে। ইন্টারনেট সংযোগ পরীক্ষা করুন।"
        FirebaseFirestoreException.Code.RESOURCE_EXHAUSTED ->
            "আজকের ফ্রি ডেটাবেস কোটা শেষ হয়েছে। আগামীকাল আবার চেষ্টা করুন।"
        else -> fsEx?.localizedMessage ?: localizedMessage ?: fallback
    }
}
