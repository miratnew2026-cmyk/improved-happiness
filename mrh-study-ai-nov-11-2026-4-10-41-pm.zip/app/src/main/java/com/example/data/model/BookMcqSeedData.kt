package com.example.data.model

/**
 * Curated NCTB SSC 2028 textbook MCQs covering all 12 subjects with clean
 * textbook Unicode typography (√, ×, ÷, ±, π, θ, ², ³) and detailed Bangla explanations.
 */
object BookMcqSeedData {

    val bookMcqs: List<PlayableMcq> = listOf(
        // --- 1. বাংলা ১ম পত্র ---
        PlayableMcq(
            id = "book_b1_1",
            subjectId = "bangla_1",
            subjectName = "বাংলা ১ম পত্র",
            chapterNumber = 3,
            chapterTitle = "সুভা",
            question = "‘সুভা’ গল্পে সুভাষিণীর সবচেয়ে বড় নির্ভরতার আশ্রয় কী ছিল?",
            options = listOf("তার মায়ের স্নেহ", "প্রকৃতি ও বোবা প্রাণীর জগৎ", "গ্রাম্য পাঠশালা", "গ্রামের মেলা"),
            correctIndex = 1,
            explanation = "কথা বলতে না পারায় সুভা নির্বাক প্রকৃতি এবং সর্বশী-পাঙ্গুলি গাভী ও ছাগশিশুর সাথেই মনের ভাব বিনিময় করত।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_b1_2",
            subjectId = "bangla_1",
            subjectName = "বাংলা ১ম পত্র",
            chapterNumber = 5,
            chapterTitle = "বই পড়া",
            question = "প্রমথ চৌধুরীর মতে ‘সুশিক্ষিত লোক মাত্রই’ কী?",
            options = listOf("ডিগ্রিধারী", "স্বশিক্ষিত", "ধনবান", "পণ্ডিত"),
            correctIndex = 1,
            explanation = "‘বই পড়া’ প্রবন্ধে প্রমথ চৌধুরী বলেছেন— সুশিক্ষিত লোক মাত্রই স্বশিক্ষিত, কারণ লাইব্রেরিতে মানুষ নিজের ইচ্ছায় জ্ঞান অর্জন করে।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_b1_3",
            subjectId = "bangla_1",
            subjectName = "বাংলা ১ম পত্র",
            chapterNumber = 26,
            chapterTitle = "বঙ্গবাণী",
            question = "“যে সব বঙ্গেত জন্মি হিংসে বঙ্গবাণী”— এখানে কবি কাদের প্রতি ক্ষোভ প্রকাশ করেছেন?",
            options = listOf("বিদেশি শাসকদের", "বাংলা ভাষাবিরোধী হীনম্মন্য মানুষদের", "নিরক্ষর কৃষকদের", "প্রাচীন পুঁথি লেখকদের"),
            correctIndex = 1,
            explanation = "আবদুল হাকিম বাংলায় জন্মগ্রহণ করেও যারা বাংলা ভাষাকে ঘৃণা ও অবজ্ঞা করে, তাদের জন্মপরিচয় নিয়ে সংশয় প্রকাশ করেছেন।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_b1_4",
            subjectId = "bangla_1",
            subjectName = "বাংলা ১ম পত্র",
            chapterNumber = 27,
            chapterTitle = "কপোতাক্ষ নদ",
            question = "মাইকেল মধুসূদন দত্ত রচিত ‘কপোতাক্ষ নদ’ কবিতাটি কোন ছন্দে ও কাঠামোয় রচিত?",
            options = listOf("মাত্রাবৃত্ত, মহাকাব্য", "অক্ষরবৃত্ত, চতুর্দশপদী সনেট", "স্বরবৃত্ত, গীতিকবিতা", "মুক্তক ছন্দ, নাট্যকাব্য"),
            correctIndex = 1,
            explanation = "‘কপোতাক্ষ নদ’ ১৪ চরণের চতুর্দশপদী (সনেট) কবিতা; প্রতি চরণে ১৪ মাত্রা বিশিষ্ট অক্ষরবৃত্ত ছন্দ ব্যবহৃত হয়েছে।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_b1_5",
            subjectId = "bangla_1",
            subjectName = "বাংলা ১ম পত্র",
            chapterNumber = 34,
            chapterTitle = "মানুষ",
            question = "‘মানুষ’ কবিতায় মন্দির ও মসজিদের দরজা বন্ধ হওয়ার মূল কারণ কী?",
            options = listOf("ভক্তদের অনুপস্থিতি", "পুরোহিত ও মোল্লার স্বার্থপরতা", "প্রাকৃতিক দুর্যোগ", "রাজার নির্দেশ"),
            correctIndex = 1,
            explanation = "ক্ষুধার্ত ভুখারিকে ফিরিয়ে দিয়ে পুরোহিত ও মোল্লা মানবতার চেয়ে নিজেদের ভোগ-স্বার্থকে বড় করে দেখেছে।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),

        // --- 2. বাংলা ২য় পত্র ---
        PlayableMcq(
            id = "book_b2_1",
            subjectId = "bangla_2",
            subjectName = "বাংলা ২য় পত্র",
            chapterNumber = 3,
            chapterTitle = "সন্ধি (স্বরসন্ধি ও ব্যঞ্জনসন্ধি)",
            question = "‘সঞ্চয়’ শব্দের সঠিক সন্ধি বিচ্ছেদ কোনটি?",
            options = listOf("সম্ + চয়", "সন্ + চয়", "সম + জয়", "স + চয়"),
            correctIndex = 0,
            explanation = "ম্-এর পরে চ-বর্গীয় ধ্বনি থাকলে ম্ স্থানে অনুস্বার (ং) বা ঞ হয়। তাই সম্ + চয় = সঞ্চয়।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_b2_2",
            subjectId = "bangla_2",
            subjectName = "বাংলা ২য় পত্র",
            chapterNumber = 5,
            chapterTitle = "সমাস ও প্রকারভেদ",
            question = "‘নীল যে পদ্ম = নীলপদ্ম’ — এটি কোন সমাসের উদাহরণ?",
            options = listOf("তৎপুরুষ", "কর্মধারয়", "বহুব্রীহি", "অব্যয়ীভাব"),
            correctIndex = 1,
            explanation = "বিশেষণ ও বিশেষ্য পদে সমাস হয়ে পরপদের অর্থ প্রাধান্য পেলে সাধারণ কর্মধারয় সমাস হয়।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_b2_3",
            subjectId = "bangla_2",
            subjectName = "বাংলা ২য় পত্র",
            chapterNumber = 7,
            chapterTitle = "কারক ও বিভক্তি",
            question = "“তিলে তৈল হয়”— এখানে ‘তিলে’ কোন কারকে কোন বিভক্তি?",
            options = listOf("অধিকরণে সপ্তমী", "অপাদানে সপ্তমী", "করণে সপ্তমী", "কর্মে সপ্তমী"),
            correctIndex = 1,
            explanation = "যা থেকে কোনো কিছু গৃহীত, উৎপন্ন বা বিচ্যুত হয় তাকে অপাদান কারক বলে। তিল থেকে তৈল উৎপন্ন হওয়ায় ‘তিলে’ অপাদানে সপ্তমী বিভক্তি।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),

        // --- 3. ইংরেজি ১ম পত্র ---
        PlayableMcq(
            id = "book_e1_1",
            subjectId = "english_1",
            subjectName = "ইংরেজি ১ম পত্র",
            chapterNumber = 3,
            chapterTitle = "Unit 3: Events and Festivals",
            question = "When did UNESCO declare 21 February as International Mother Language Day?",
            options = listOf("17 November 1999", "21 February 2000", "26 March 1998", "16 December 1999"),
            correctIndex = 0,
            explanation = "১৯৯৯ সালের ১৭ নভেম্বর ইউনেস্কো ২১শে ফেব্রুয়ারিকে আন্তর্জাতিক মাতৃভাষা দিবস হিসেবে ঘোষণা করে।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_e1_2",
            subjectId = "english_1",
            subjectName = "ইংরেজি ১ম পত্র",
            chapterNumber = 7,
            chapterTitle = "Unit 8: World Heritage",
            question = "Who built the historic Shat Gambuj Mosque in Bagerhat?",
            options = listOf("Sultan Fakhruddin", "Ulugh Khan Jahan", "Shayesta Khan", "Isa Khan"),
            correctIndex = 1,
            explanation = "পঞ্চদশ শতাব্দীতে তুর্কি সেনাপতি উলুঘ খান জাহান বাগেরহাটে ষাট গম্বুজ মসজিদ নির্মাণ করেন।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),

        // --- 4. ইংরেজি ২য় পত্র ---
        PlayableMcq(
            id = "book_e2_1",
            subjectId = "english_2",
            subjectName = "ইংরেজি ২য় পত্র",
            chapterNumber = 2,
            chapterTitle = "Right Form of Verbs",
            question = "Neither Rina nor her friends _____ present in the seminar yesterday.",
            options = listOf("was", "were", "are", "is"),
            correctIndex = 1,
            explanation = "Neither...nor দ্বারা যুক্ত দুটি Subject-এর ক্ষেত্রে শেষের Subject (her friends = plural) ও অতীত নির্দেশক 'yesterday' অনুযায়ী 'were' বসে।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_e2_2",
            subjectId = "english_2",
            subjectName = "ইংরেজি ২য় পত্র",
            chapterNumber = 4,
            chapterTitle = "Tag Questions",
            question = "Let's solve the SSC math problem together, _____?",
            options = listOf("will we", "shall we", "do we", "aren't we"),
            correctIndex = 1,
            explanation = "কোনো Imperative বাক্য 'Let's' (Let us) দিয়ে শুরু হলে এর Tag question সর্বদা 'shall we?' হয়।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_e2_3",
            subjectId = "english_2",
            subjectName = "ইংরেজি ২য় পত্র",
            chapterNumber = 3,
            chapterTitle = "Changing Sentences",
            question = "Identify the comparative form of: 'Dhaka is one of the largest cities in Bangladesh.'",
            options = listOf(
                "Dhaka is larger than any other city.",
                "Dhaka is larger than most other cities in Bangladesh.",
                "Very few cities are larger than Dhaka.",
                "No other city is as large as Dhaka."
            ),
            correctIndex = 1,
            explanation = "'one of the + superlative'-কে comparative করতে 'than most other + plural noun' ব্যবহৃত হয়।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),

        // --- 5. সাধারণ গণিত ---
        PlayableMcq(
            id = "book_gm_1",
            subjectId = "general_math",
            subjectName = "সাধারণ গণিত",
            chapterNumber = 2,
            chapterTitle = "সেট ও ফাংশন",
            question = "কোনো সেট A-এর উপাদান সংখ্যা n = 4 হলে, এর প্রকৃত উপসেটের সংখ্যা কত?",
            options = listOf("16", "15", "8", "14"),
            correctIndex = 1,
            explanation = "উপসেট সংখ্যা 2ⁿ = 2⁴ = 16; প্রকৃত উপসেট সংখ্যা = 2ⁿ - 1 = 16 - 1 = 15।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_gm_2",
            subjectId = "general_math",
            subjectName = "সাধারণ গণিত",
            chapterNumber = 3,
            chapterTitle = "বীজগাণিতিক রাশি",
            question = "যদি x = √6 + √5 হয়, তবে x + 1/x এর মান কত?",
            options = listOf("2√6", "2√5", "√6 - √5", "11"),
            correctIndex = 0,
            explanation = "1/x = 1 / (√6 + √5) = √6 - √5। অতএব x + 1/x = (√6 + √5) + (√6 - √5) = 2√6।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_gm_3",
            subjectId = "general_math",
            subjectName = "সাধারণ গণিত",
            chapterNumber = 4,
            chapterTitle = "সূচক ও লগারিদম",
            question = "log₃(81) এর মান কত?",
            options = listOf("3", "4", "9", "2"),
            correctIndex = 1,
            explanation = "81 = 3⁴। তাই log₃(81) = log₃(3⁴) = 4 × log₃(3) = 4 × 1 = 4।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_gm_4",
            subjectId = "general_math",
            subjectName = "সাধারণ গণিত",
            chapterNumber = 9,
            chapterTitle = "ত্রিকোণমিতিক অনুপাত",
            question = "sinθ = √3/2 এবং θ সূক্ষ্মকোণ হলে, cos2θ বা tanθ এর মান কত?",
            options = listOf("tanθ = √3", "tanθ = 1/√3", "tanθ = 1", "tanθ = 2"),
            correctIndex = 0,
            explanation = "sin60° = √3/2 হওয়ায় θ = 60°। অতএব tan60° = √3।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_gm_5",
            subjectId = "general_math",
            subjectName = "সাধারণ গণিত",
            chapterNumber = 16,
            chapterTitle = "পরিমিতি",
            question = "একটি বৃত্তের ব্যাসার্ধ r = 7 cm হলে, বৃত্তের ক্ষেত্রফল (π = 22/7 ধরে) কত?",
            options = listOf("44 cm²", "154 cm²", "77 cm²", "308 cm²"),
            correctIndex = 1,
            explanation = "বৃত্তের ক্ষেত্রফল = πr² = (22/7) × 7² = 22 × 7 = 154 cm²।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),

        // --- 6. উচ্চতর গণিত ---
        PlayableMcq(
            id = "book_hm_1",
            subjectId = "higher_math",
            subjectName = "উচ্চতর গণিত",
            chapterNumber = 7,
            chapterTitle = "অসীম ধারা",
            question = "1 + 1/2 + 1/4 + 1/8 + ... অসীম গুণোত্তর ধারাটির অসীমতক সমষ্টি কত?",
            options = listOf("1", "2", "4", "অসীমতক সমষ্টি নেই"),
            correctIndex = 1,
            explanation = "এখানে প্রথম পদ a = 1, সাধারণ অনুপাত r = 1/2 (< 1)। অসীমতক সমষ্টি S∞ = a / (1 - r) = 1 / (1 - 1/2) = 2।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_hm_2",
            subjectId = "higher_math",
            subjectName = "উচ্চতর গণিত",
            chapterNumber = 8,
            chapterTitle = "ত্রিকোণমিতি",
            question = "135° কোণের বৃত্তীয় বা রেডিয়ান মান কত?",
            options = listOf("3π/4 রেডিয়ান", "2π/3 রেডিয়ান", "5π/6 রেডিয়ান", "π/4 রেডিয়ান"),
            correctIndex = 0,
            explanation = "135° = 135 × (π/180) = 3π/4 রেডিয়ান।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_hm_3",
            subjectId = "higher_math",
            subjectName = "উচ্চতর গণিত",
            chapterNumber = 11,
            chapterTitle = "স্থানাঙ্ক জ্যামিতি",
            question = "A(2, 3) এবং B(5, 7) বিন্দুদ্বয়ের মধ্যবর্তী দূরত্ব কত একক?",
            options = listOf("4 একক", "5 একক", "6 একক", "√7 একক"),
            correctIndex = 1,
            explanation = "দূরত্ব AB = √{(5 - 2)² + (7 - 3)²} = √(3² + 4²) = √(9 + 16) = √25 = 5 একক।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_hm_4",
            subjectId = "higher_math",
            subjectName = "উচ্চতর গণিত",
            chapterNumber = 14,
            chapterTitle = "সম্ভাবনা",
            question = "একটি নিরপেক্ষ ছক্কা একবার নিক্ষেপ করলে জোড় সংখ্যা উঠার সম্ভাবনা কত?",
            options = listOf("1/6", "1/3", "1/2", "2/3"),
            correctIndex = 2,
            explanation = "ছক্কার মোট ফলাফল {1, 2, 3, 4, 5, 6} অর্থাৎ 6টি। এর মধ্যে জোড় সংখ্যা {2, 4, 6} = 3টি। সম্ভাবনা = 3/6 = 1/2।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),

        // --- 7. পদার্থবিজ্ঞান ---
        PlayableMcq(
            id = "book_phy_1",
            subjectId = "physics",
            subjectName = "পদার্থবিজ্ঞান",
            chapterNumber = 7,
            chapterTitle = "তরঙ্গ ও শব্দ",
            question = "কোনো শব্দের কম্পাঙ্ক f = 500 Hz এবং বায়ুতে শব্দের বেগ v = 340 m/s হলে তরঙ্গদৈর্ঘ্য λ কত?",
            options = listOf("0.68 m", "1.47 m", "0.34 m", "6.80 m"),
            correctIndex = 0,
            explanation = "আমরা জানি v = fλ ⇒ λ = v / f = 340 / 500 = 0.68 m।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_phy_2",
            subjectId = "physics",
            subjectName = "পদার্থবিজ্ঞান",
            chapterNumber = 8,
            chapterTitle = "আলোর প্রতিফলন",
            question = "একটি অবতল দর্পণের বক্রতার ব্যাসার্ধ R = 20 cm হলে এর ফোকাস দূরত্ব f কত?",
            options = listOf("40 cm", "10 cm", "20 cm", "5 cm"),
            correctIndex = 1,
            explanation = "গোলীয় দর্পণের ফোকাস দূরত্ব f = R / 2 = 20 / 2 = 10 cm।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_phy_3",
            subjectId = "physics",
            subjectName = "পদার্থবিজ্ঞান",
            chapterNumber = 11,
            chapterTitle = "চল বিদ্যুৎ",
            question = "4 Ω এবং 4 Ω মানের দুটি রোধ সমান্তরালে যুক্ত করলে তুল্যরোধ কত হবে?",
            options = listOf("8 Ω", "2 Ω", "1 Ω", "16 Ω"),
            correctIndex = 1,
            explanation = "1/Rp = 1/4 + 1/4 = 2/4 = 1/2 ⇒ Rp = 2 Ω।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),

        // --- 8. রসায়ন ---
        PlayableMcq(
            id = "book_chem_1",
            subjectId = "chemistry",
            subjectName = "রসায়ন",
            chapterNumber = 6,
            chapterTitle = "মোলের ধারণা ও রাসায়নিক গণনা",
            question = "প্রমাণ অবস্থায় (STP) 2 মোল CO₂ গ্যাসের আয়তন কত লিটার?",
            options = listOf("11.2 L", "22.4 L", "44.8 L", "24.7 L"),
            correctIndex = 2,
            explanation = "STP-তে 1 মোল গ্যাসের আয়তন 22.4 L। তাই 2 মোল CO₂ গ্যাসের আয়তন = 2 × 22.4 L = 44.8 L।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_chem_2",
            subjectId = "chemistry",
            subjectName = "রসায়ন",
            chapterNumber = 9,
            chapterTitle = "এসিড-ক্ষারক সমতা",
            question = "বিশুদ্ধ পানির pH মান কত?",
            options = listOf("5", "7", "9", "14"),
            correctIndex = 1,
            explanation = "বিশুদ্ধ পানি নিরপেক্ষ হওয়ায় এর [H⁺] = 10⁻⁷ M এবং pH = -log[H⁺] = 7।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_chem_3",
            subjectId = "chemistry",
            subjectName = "রসায়ন",
            chapterNumber = 7,
            chapterTitle = "রাসায়নিক বিক্রিয়া",
            question = "জারণ-বিজারণ বিক্রিয়ায় যে পদার্থ ইলেকট্রন ত্যাগ করে তাকে কী বলে?",
            options = listOf("জারক", "বিজারক", "প্রভাবক", "লবণ"),
            correctIndex = 1,
            explanation = "জারণ অর্থ ইলেকট্রন ছারণ/ত্যাগ। যে বিক্রিয়ক নিজে ইলেকট্রন ত্যাগ করে অপরকে বিজারিত করে, তাকে বিজারক বলে।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),

        // --- 9. জীববিজ্ঞান ---
        PlayableMcq(
            id = "book_bio_1",
            subjectId = "biology",
            subjectName = "জীববিজ্ঞান",
            chapterNumber = 3,
            chapterTitle = "কোষ বিভাজন",
            question = "মাইটোসিস কোষ বিভাজনের কোন ধাপে ক্রোমোজোমগুলো বিষুবীয় অঞ্চলে অবস্থান করে?",
            options = listOf("প্রোফেজ", "মেটাফেজ", "অ্যানাফেজ", "টেলোফেজ"),
            correctIndex = 1,
            explanation = "মেটাফেজ ধাপে স্পিন্ডল যন্ত্রের বিষুবীয় অঞ্চলে (মধ্যভাগে) ক্রোমোজোমগুলো সবচেয়ে খাটো ও মোটা অবস্থায় সজ্জিত হয়।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_bio_2",
            subjectId = "biology",
            subjectName = "জীববিজ্ঞান",
            chapterNumber = 4,
            chapterTitle = "জীবনীশক্তি",
            question = "সবাত শ্বসনে ১ অণু গ্লুকোজ সম্পূর্ণ জারিত হলে নিট কত অণু ATP উৎপন্ন হয়?",
            options = listOf("2 ATP", "18 ATP", "36 ATP", "38 ATP"),
            correctIndex = 3,
            explanation = "সবাত শ্বসনের গ্লাইকোলাইসিস ও ক্রেবস চক্র মিলিয়ে ১ অণু গ্লুকোজ থেকে মোট ৩৮ অণু ATP তৈরি হয়।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_bio_3",
            subjectId = "biology",
            subjectName = "জীববিজ্ঞান",
            chapterNumber = 12,
            chapterTitle = "জীবের বংশগতি ও জৈব অভিব্যক্তি",
            question = "DNA অণুতে অ্যাডেনিন (A)-এর সাথে কোন নাইট্রোজেন বেস হাইড্রোজেন বন্ধনে যুক্ত থাকে?",
            options = listOf("গুয়ানিন (G)", "সাইটোসিন (C)", "থাইমিন (T)", "ইউরাসিল (U)"),
            correctIndex = 2,
            explanation = "DNA ডাবল হেলিক্সে অ্যাডেনিন (A) দুটি হাইড্রোজেন বন্ধনে থাইমিন (T)-এর সাথে এবং G তিনটি বন্ধনে C-এর সাথে যুক্ত থাকে।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),

        // --- 10. বাংলাদেশ ও বিশ্বপরিচয় ---
        PlayableMcq(
            id = "book_bgs_1",
            subjectId = "bgs",
            subjectName = "বাংলাদেশ ও বিশ্বপরিচয়",
            chapterNumber = 1,
            chapterTitle = "পূর্ব বাংলার আন্দোলন ও জাতীয়তাবাদের উত্থান",
            question = "ঐতিহাসিক ৬ দফা কর্মসূচি কত সালে এবং কোথায় ঘোষণা করা হয়?",
            options = listOf("১৯৫৪, ঢাকা", "১৯৬৬, লাহোর", "১৯৬৯, ঢাকা", "১৯৭০, করাচি"),
            correctIndex = 1,
            explanation = "১৯৬৬ সালের ৫-৬ ফেব্রুয়ারি লাহোরে অনুষ্ঠিত বিরোধী দলগুলোর সম্মেলনে বঙ্গবন্ধু শেখ মুজিবুর রহমান বাঙালির মুক্তির সনদ ৬ দফা ঘোষণা করেন।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_bgs_2",
            subjectId = "bgs",
            subjectName = "বাংলাদেশ ও বিশ্বপরিচয়",
            chapterNumber = 2,
            chapterTitle = "বাংলাদেশের স্বাধীনতা",
            question = "মুজিবনগর সরকার কত তারিখে শপথ গ্রহণ করে?",
            options = listOf("১০ এপ্রিল ১৯৭১", "১৭ এপ্রিল ১৯৭১", "২৬ মার্চ ১৯৭১", "১৪ ডিসেম্বর ১৯৭১"),
            correctIndex = 1,
            explanation = "১৯৭১ সালের ১০ এপ্রিল সরকার গঠিত হয় এবং ১৭ এপ্রিল মেহেরপুরের বৈদ্যনাথতলায় (মুজিবনগর) শপথ গ্রহণ করে।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_bgs_3",
            subjectId = "bgs",
            subjectName = "বাংলাদেশ ও বিশ্বপরিচয়",
            chapterNumber = 3,
            chapterTitle = "সৌরজগৎ ও ভূমণ্ডল",
            question = "প্রতি ১° দ্রাঘিমার পার্থক্যের জন্য সময়ের পার্থক্য কত হয়?",
            options = listOf("২ মিনিট", "৪ মিনিট", "১৫ মিনিট", "৬০ মিনিট"),
            correctIndex = 1,
            explanation = "পৃথিবী ২৪ ঘণ্টায় (১৪৪০ মিনিটে) ৩৬০° আবর্তন করে। তাই ১৪৪০ ÷ ৩৬০ = ৪ মিনিট।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),

        // --- 11. ইসলাম ও নৈতিক শিক্ষা ---
        PlayableMcq(
            id = "book_islam_1",
            subjectId = "islam_moral",
            subjectName = "ইসলাম ও নৈতিক শিক্ষা",
            chapterNumber = 1,
            chapterTitle = "আকাইদ ও নৈতিক জীবন",
            question = "ইসলামের সর্বপ্রথম ও সর্বপ্রধান মৌলিক বিশ্বাস কোনটি?",
            options = listOf("রিসালাত", "তাওহিদ", "আখিরাত", "মালাইকা"),
            correctIndex = 1,
            explanation = "তাওহিদ অর্থ আল্লাহ তাআলার একত্ববাদ। আকাইদের সকল বিশ্বাসের মূল ভিত্তি হলো তাওহিদ।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_islam_2",
            subjectId = "islam_moral",
            subjectName = "ইসলাম ও নৈতিক শিক্ষা",
            chapterNumber = 2,
            chapterTitle = "শরিয়তের উৎস",
            question = "ইসলামি শরিয়তের প্রধান ও প্রথম উৎস কোনটি?",
            options = listOf("হাদিস", "ইজমা", "আল-কুরআন", "কিয়াস"),
            correctIndex = 2,
            explanation = "ইসলামি শরিয়তের চারটি প্রধান উৎস— আল-কুরআন, হাদিস, ইজমা ও কিয়াস; এর মধ্যে সর্বপ্রথম ও সর্বোচ্চ উৎস হলো আল-কুরআন।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_islam_3",
            subjectId = "islam_moral",
            subjectName = "ইসলাম ও নৈতিক শিক্ষা",
            chapterNumber = 4,
            chapterTitle = "আখলাক",
            question = "“যে প্রতারণা করে সে আমাদের দলভুক্ত নয়”— এটি কোন গুণ অর্জনের প্রতি গুরুত্বারোপ করে?",
            options = listOf("দানশীলতা", "সততা ও আমানতদারিতা", "ধৈর্যশীলতা", "বীরত্ব"),
            correctIndex = 1,
            explanation = "মহানবি (সা.) প্রতারণা ত্যাগ করে ব্যবসা ও সামাজিক জীবনে সততা এবং আমানতদারিতা রক্ষার কঠোর নির্দেশ দিয়েছেন।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),

        // --- 12. তথ্য ও যোগাযোগ প্রযুক্তি (ICT) ---
        PlayableMcq(
            id = "book_ict_1",
            subjectId = "ict",
            subjectName = "তথ্য ও যোগাযোগ প্রযুক্তি",
            chapterNumber = 2,
            chapterTitle = "কম্পিউটার ও কম্পিউটার ব্যবহারকারীর নিরাপত্তা",
            question = "ইন্টারনেটে অস্থায়ীভাবে সংরক্ষিত ফাইল ডিলিট করলে কম্পিউটারের কী সুবিধা হয়?",
            options = listOf("পাসওয়ার্ড পরিবর্তন হয়", "গতি বৃদ্ধি পায় ও হার্ডডিস্কে জায়গা খালি হয়", "মনিটর উজ্জ্বল হয়", "ভাইরাস তৈরি হয়"),
            correctIndex = 1,
            explanation = "Temporary Files ডিলিট করলে ডিস্ক স্পেস মুক্ত হয় এবং সিস্টেমের পারফরম্যান্স দ্রুততর হয়।",
            difficulty = "easy",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_ict_2",
            subjectId = "ict",
            subjectName = "তথ্য ও যোগাযোগ প্রযুক্তি",
            chapterNumber = 6,
            chapterTitle = "প্রোগ্রামিংয়ের মাধ্যমে সমস্যা সমাধান",
            question = "ফ্লোচার্টে সিদ্ধান্ত গ্রহণ (Condition Check) বোঝাতে কোন প্রতীক ব্যবহৃত হয়?",
            options = listOf("বৃত্ত (Oval)", "আয়তক্ষেত্র (Rectangle)", "রম্বস বা ডায়মন্ড (Diamond)", "সামান্তরিক (Parallelogram)"),
            correctIndex = 2,
            explanation = "ফ্লোচার্টে হ্যাঁ/না বা শর্ত যাচাইয়ের সিদ্ধান্ত প্রতীক হিসেবে ডায়মন্ড (হীরক) চিহ্ন ব্যবহৃত হয়।",
            difficulty = "medium",
            sourceBadge = "বই"
        ),
        PlayableMcq(
            id = "book_ict_3",
            subjectId = "ict",
            subjectName = "তথ্য ও যোগাযোগ প্রযুক্তি",
            chapterNumber = 7,
            chapterTitle = "ইন্টারনেট ও ওয়েব পরিচিতি",
            question = "HTML-এ সবচেয়ে বড় শিরোনাম (Heading) প্রদর্শনের জন্য কোন ট্যাগ ব্যবহৃত হয়?",
            options = listOf("<h6>", "<head>", "<h1>", "<title>"),
            correctIndex = 2,
            explanation = "HTML-এ <h1> থেকে <h6> পর্যন্ত ৬টি হেডিং ট্যাগ রয়েছে, যেখানে <h1> হলো সবচেয়ে বড় প্রধান শিরোনাম।",
            difficulty = "easy",
            sourceBadge = "বই"
        )
    )

    fun allBookPlayableMcqs(): List<PlayableMcq> {
        val boardConverted = BoardQuestionsData.sampleMcqs.map { bq ->
            val subject = SscSyllabusData.getSubject(bq.subjectId)
            val matchedChapter = subject?.chapters?.find { ch ->
                ch.title.contains(bq.chapterName, ignoreCase = true) ||
                    bq.chapterName.contains(ch.title, ignoreCase = true)
            }
            PlayableMcq(
                id = bq.id,
                subjectId = bq.subjectId,
                subjectName = subject?.nameBn ?: bq.subjectName,
                chapterNumber = matchedChapter?.number ?: 1,
                chapterTitle = matchedChapter?.title ?: bq.chapterName,
                question = bq.question,
                options = bq.options,
                correctIndex = bq.correctIndex.coerceIn(0, 3),
                explanation = bq.explanation,
                difficulty = "medium",
                sourceBadge = "বোর্ড ও বই"
            )
        }
        return (boardConverted + bookMcqs).distinctBy { it.question.trim() }
    }
}

fun McqQuestionRecord.toPlayableMcq(): PlayableMcq {
    val cleanOptions = options.take(4).let { opts ->
        if (opts.size == 4) opts else List(4) { idx -> opts.getOrNull(idx) ?: "অপশন ${idx + 1}" }
    }
    val badge = when (sourceType) {
        "book" -> "বই (এজেন্ট)"
        "ocr_image" -> "OCR ছবি"
        "ocr_pdf" -> "OCR PDF"
        else -> "এজেন্ট"
    }
    return PlayableMcq(
        id = id,
        subjectId = subjectId,
        subjectName = subjectName,
        chapterNumber = chapterNumber.toInt().coerceAtLeast(1),
        chapterTitle = chapterTitle,
        question = question,
        options = cleanOptions,
        correctIndex = correctIndex.toInt().coerceIn(0, 3),
        explanation = explanation,
        difficulty = difficulty,
        sourceBadge = badge
    )
}
