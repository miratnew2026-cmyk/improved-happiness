package com.example.data.model

data class BoardMcqQuestion(
    val id: String,
    val subjectId: String,
    val subjectName: String,
    val chapterName: String,
    val boardTag: String, // e.g. "Dhaka Board 2024"
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

data class CreativeQuestion(
    val id: String,
    val subjectId: String,
    val subjectName: String,
    val chapterName: String,
    val boardTag: String,
    val stimulus: String, // উদ্দীপক
    val questionKa: String, // ক (১ নম্বর)
    val answerKa: String,
    val questionKha: String, // খ (২ নম্বর)
    val answerKha: String,
    val questionGa: String, // গ (৩ নম্বর)
    val answerGa: String,
    val questionGha: String, // ঘ (৪ নম্বর)
    val answerGha: String
)

object BoardQuestionsData {
    val sampleMcqs = listOf(
        BoardMcqQuestion(
            id = "mcq_gm_1",
            subjectId = "general_math",
            subjectName = "সাধারণ গণিত",
            chapterName = "বাস্তব সংখ্যা",
            boardTag = "ঢাকা বোর্ড ২০২৩",
            question = "নিচের কোনটি অমূলদ সংখ্যা?",
            options = listOf("√4", "√(16/9)", "√8", "0.333..."),
            correctIndex = 2,
            explanation = "√8 = 2√2। যে সংখ্যাকে p/q আকারে প্রকাশ করা যায় না এবং যার দশমিক রূপ অসীম অনাবৃত্ত তা অমূলদ সংখ্যা। এখানে √8 একটি অমূলদ সংখ্যা।"
        ),
        BoardMcqQuestion(
            id = "mcq_gm_2",
            subjectId = "general_math",
            subjectName = "সাধারণ গণিত",
            chapterName = "বীজগাণিতিক রাশি",
            boardTag = "রাজশাহী বোর্ড ২০২৪",
            question = "x + 1/x = 3 হলে, x³ + 1/x³ এর মান কত?",
            options = listOf("27", "18", "36", "9"),
            correctIndex = 1,
            explanation = "সূত্রানুসারে: x³ + 1/x³ = (x + 1/x)³ - 3(x)(1/x)(x + 1/x) = 3³ - 3(3) = 27 - 9 = 18।"
        ),
        BoardMcqQuestion(
            id = "mcq_phy_1",
            subjectId = "physics",
            subjectName = "পদার্থবিজ্ঞান",
            chapterName = "গতি",
            boardTag = "চট্টগ্রাম বোর্ড ২০২৪",
            question = "স্থিরাবস্থা থেকে সুষম ত্বরণে চলমান কোনো বস্তুর অতিক্রান্ত দূরত্ব (s) সময়ের (t) সাথে কীভাবে সম্পর্কিত?",
            options = listOf("s ∝ t", "s ∝ t²", "s ∝ √t", "s ∝ 1/t"),
            correctIndex = 1,
            explanation = "আমরা জানি, s = ut + ½at²। যেহেতু বস্তুটি স্থিরাবস্থা থেকে শুরু করে (u = 0), তাই s = ½at²। ত্বরণ a ধ্রুবক হলে s ∝ t²।"
        ),
        BoardMcqQuestion(
            id = "mcq_phy_2",
            subjectId = "physics",
            subjectName = "পদার্থবিজ্ঞান",
            chapterName = "কাজ, ক্ষমতা ও শক্তি",
            boardTag = "যশোর বোর্ড ২০২৩",
            question = "একটি বস্তুর বেগ দ্বিগুণ করা হলে এর গতিশক্তি পূর্বের কত গুণ হবে?",
            options = listOf("২ গুণ", "৩ গুণ", "৪ গুণ", "অপরিবর্তিত থাকবে"),
            correctIndex = 2,
            explanation = "গতিশক্তি Ek = ½mv²। বেগ v দ্বিগুণ (2v) করা হলে Ek' = ½m(2v)² = 4(½mv²) = 4Ek। অতএব গতিশক্তি ৪ গুণ হবে।"
        ),
        BoardMcqQuestion(
            id = "mcq_chem_1",
            subjectId = "chemistry",
            subjectName = "রসায়ন",
            chapterName = "পর্যায় সারণি",
            boardTag = "দিনাজপুর বোর্ড ২০২৪",
            question = "কোন মৌলটির পারমাণবিক ব্যাসার্ধ সবচেয়ে কম?",
            options = listOf("Na", "Mg", "Al", "Cl"),
            correctIndex = 3,
            explanation = "একই পর্যায়ের বাম থেকে ডানে গেলে নিউক্লিয়াসে প্রোটন সংখ্যা বৃদ্ধি পায় এবং সর্ববহিঃস্থ স্তরের ইলেকট্রনের প্রতি আকর্ষণ বৃদ্ধি পাওয়ায় পারমাণবিক ব্যাসার্ধ হ্রাস পায়। ৩য় পর্যায়ে Cl সবচেয়ে ডানে অবস্থিত।"
        ),
        BoardMcqQuestion(
            id = "mcq_chem_2",
            subjectId = "chemistry",
            subjectName = "রসায়ন",
            chapterName = "রাসায়নিক বন্ধন",
            boardTag = "কুমিল্লা বোর্ড ২০২৪",
            question = "অ্যামোনিয়া (NH₃) অণুতে কয়টি মুক্তজোড় ইলেকট্রন বিদ্যমান?",
            options = listOf("১ জোড়া", "২ জোড়া", "৩ জোড়া", "নেই"),
            correctIndex = 0,
            explanation = "নাইট্রোজেনের যোজ্যতা স্তরে ৫টি ইলেকট্রন রয়েছে। ৩টি ইলেকট্রন ৩টি হাইড্রোজেন পরমাণুর সাথে ৩টি বন্ধনজোড় গঠন করে। বাকি ২টি ইলেকট্রন ১ জোড়া মুক্তজোড় (lone pair) হিসেবে থাকে।"
        ),
        BoardMcqQuestion(
            id = "mcq_bio_1",
            subjectId = "biology",
            subjectName = "জীববিজ্ঞান",
            chapterName = "জীবকোষ ও টিস্যু",
            boardTag = "সিলেট বোর্ড ২০২৩",
            question = "কোষের শক্তিঘর (Powerhouse) কাকে বলা হয়?",
            options = listOf("রাইবোসোম", "মাইটোকন্ড্রিয়া", "গলজি বডি", "লাইসোজোম"),
            correctIndex = 1,
            explanation = "মাইটোকন্ড্রিয়ায় ক্রেবস চক্র ও ইলেকট্রন পরিবহন তন্ত্রের মাধ্যমে কোষের সিংহভাগ শক্তি (ATP) উৎপন্ন হয়, এজন্য একে কোষের পাওয়ার হাউস বলে।"
        ),
        BoardMcqQuestion(
            id = "mcq_ict_1",
            subjectId = "ict",
            subjectName = "ICT",
            chapterName = "আমার লিখনী ও হিসাব",
            boardTag = "বরিশাল বোর্ড ২০২৪",
            question = "স্প্রেডশিটে A1 থেকে A10 পর্যন্ত ঘরের সংখ্যার যোগফল নির্ণয়ের সঠিক সূত্র কোনটি?",
            options = listOf("=ADD(A1:A10)", "=SUM(A1:A10)", "=TOTAL(A1..A10)", "=SUM(A1+A10)"),
            correctIndex = 1,
            explanation = "মাইক্রোসফট এক্সেলে রেঞ্জের সমষ্টি নির্ণয়ের আদর্শ সিনট্যাক্স হলো: =SUM(First_Cell:Last_Cell), অর্থাৎ =SUM(A1:A10)।"
        )
    )

    val sampleCreativeQuestions = listOf(
        CreativeQuestion(
            id = "cq_phy_1",
            subjectId = "physics",
            subjectName = "পদার্থবিজ্ঞান",
            chapterName = "গতি ও বল",
            boardTag = "ঢাকা বোর্ড ২০২৪",
            stimulus = "৮০০ কেজি ভরের একটি প্রাইভেট কার ৭২ কিমি/ঘণ্টা সুষম বেগে চলছিল। চালক ৫০ মিটার দূরে একটি শিশুকে দেখে সাথে সাথে ব্রেক চাপলেন এবং গাড়িটি শিশুর ঠিক সামনে এসে থেমে গেল।",
            questionKa = "পরম বেগ কাকে বলে?",
            answerKa = "মহাবিশ্বের কোনো প্রকৃত স্থির প্রসঙ্গ কাঠামোর সাপেক্ষে কোনো বস্তুর বেগকে পরম বেগ বলে।",
            questionKha = "ঘর্ষণ বল একটি অসংরক্ষণশীল বল কেন? ব্যাখ্যা করো।",
            answerKha = "যে বল দ্বারা কোনো বস্তুকে যেকোনো পথ ঘুরিয়ে আবার পূর্বের অবস্থানে আনলে মোট কাজের পরিমাণ শূন্য হয় না, তাকে অসংরক্ষণশীল বল বলে। ঘর্ষণ বল সর্বদা গতির বিপরীতে কাজ করে এবং তাপ হিসেবে শক্তিক্ষয় ঘটায়। এই শক্তির পুনরুদ্ধার সম্ভব হয় না বলে ঘর্ষণ একটি অসংরক্ষণশীল বল।",
            questionGa = "গাড়িটির মন্থন নির্ণয় করো।",
            answerGa = "এখানে,\nআদিবেগ u = 72 km/h = (72 × 1000) / 3600 = 20 m/s\nশেষবেগ v = 0 m/s\nদূরত্ব s = 50 m\n\nআমরা জানি: v² = u² - 2as\nবা, 0² = (20)² - 2 × a × 50\nবা, 100a = 400\nবা, a = 4 m/s²\nঅতএব, গাড়িটির মন্থন ৪ মি/সে²।",
            questionGha = "গাড়িটি থামাতে ব্রেকজনিত বলের মান নিউটনের দ্বিতীয় সূত্রানুসারে বিশ্লেষণ করো।",
            answerGha = "নিউটনের গতির দ্বিতীয় সূত্রানুসারে:\nপ্রযুক্ত বল F = ma\nএখানে,\nগাড়ির ভর m = 800 kg\nমন্থন a = 4 m/s²\n\nবল F = 800 kg × 4 m/s² = 3200 N\n\nবিশ্লেষণ: গাড়িটি থামাতে ব্রেক দ্বারা ৩২০০ নিউটন মানের মন্দন সৃষ্টিকারী বল প্রয়োগ করতে হয়েছিল। চালকের তাৎক্ষণিক প্রতিক্রিয়া এবং ঘর্ষণ বল উপযুক্ত হওয়ায় গাড়িটি ঠিক শিশুর সামনে থামতে সক্ষম হয় এবং দুর্ঘটনা এড়ানো সম্ভব হয়।"
        )
    )
}
