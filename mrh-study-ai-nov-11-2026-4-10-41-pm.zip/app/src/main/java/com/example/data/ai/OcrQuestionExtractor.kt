package com.example.data.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import com.example.data.model.DraftExtractedMcq
import com.example.ui.components.TextbookMathFormatter
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt

private const val TAG = "OcrQuestionExtractor"
private const val MAX_IMAGE_DIM_PX = 1600
private const val MAX_PDF_PAGES_FOR_OCR = 6
private const val MAX_PDF_UPLOAD_BYTES = 15 * 1024 * 1024
private const val MAX_IMAGE_UPLOAD_BYTES = 4 * 1024 * 1024
private const val OCR_TIMEOUT_MS = 60_000L

data class OcrExtractionOutcome(
    val fileName: String,
    val fileType: String, // "image" | "pdf"
    val mimeType: String,
    val fileBytes: ByteArray,
    val pageCountProcessed: Int,
    val draftQuestions: List<DraftExtractedMcq>
)

class OcrQuestionExtractor(context: Context) {

    private val appContext = context.applicationContext

    private val ocrQuestionsSchema = Schema.obj(
        properties = mapOf(
            "questions" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "question" to Schema.string(
                            description = "Clean readable MCQ question stem in Bangla or English without option bullets or raw LaTeX"
                        ),
                        "optionA" to Schema.string(description = "Option 1 / ক text without (ক) prefix"),
                        "optionB" to Schema.string(description = "Option 2 / খ text without (খ) prefix"),
                        "optionC" to Schema.string(description = "Option 3 / গ text without (গ) prefix"),
                        "optionD" to Schema.string(description = "Option 4 / ঘ text without (ঘ) prefix"),
                        "correctIndex" to Schema.integer(
                            description = "0-based index of the correct option (0=A/ক, 1=B/খ, 2=C/গ, 3=D/ঘ). Default to 0 if unknown."
                        ),
                        "explanation" to Schema.string(
                            description = "Concise textbook explanation in Bangla if inferable or blank string if none"
                        ),
                        "difficulty" to Schema.enumeration(
                            values = listOf("easy", "medium", "hard"),
                            description = "Difficulty level"
                        )
                    )
                ),
                description = "Extracted multiple-choice questions"
            )
        )
    )

    private val ocrModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = ocrQuestionsSchema
                temperature = 0.2f
            }
        )
    }

    suspend fun extractFromImageUri(
        uri: Uri,
        subjectName: String,
        chapterTitle: String
    ): Result<OcrExtractionOutcome> = try {
        val (fileName, bitmap, jpegBytes) = withContext(Dispatchers.IO) {
            val name = resolveDisplayName(uri, defaultPrefix = "mcq_page", fallbackExt = "jpg")
            val decoded = decodeDownsampledBitmap(uri, MAX_IMAGE_DIM_PX)
                ?: throw IllegalStateException("ছবিটি পড়া যায়নি। অনুগ্রহ করে স্পষ্ট একটি ছবি নির্বাচন করুন।")
            val compressed = compressBitmapJpeg(decoded, MAX_IMAGE_UPLOAD_BYTES)
            Triple(name, decoded, compressed)
        }

        val prompt = buildOcrPrompt(subjectName, chapterTitle, pageCount = 1)
        val responseText = withTimeout(OCR_TIMEOUT_MS) {
            val response = ocrModel.generateContent(
                content {
                    image(bitmap)
                    text(prompt)
                }
            )
            response.text
        } ?: throw IllegalStateException("OCR মডেল কোনো ফলাফল পাঠায়নি।")

        val drafts = parseDraftMcqsJson(responseText)
        if (drafts.isEmpty()) {
            Result.failure(
                IllegalStateException("ছবি থেকে পাঠযোগ্য কোনো MCQ প্রশ্ন শনাক্ত করা যায়নি। আরও পরিষ্কার ছবি দিন।")
            )
        } else {
            Result.success(
                OcrExtractionOutcome(
                    fileName = fileName,
                    fileType = "image",
                    mimeType = "image/jpeg",
                    fileBytes = jpegBytes,
                    pageCountProcessed = 1,
                    draftQuestions = drafts
                )
            )
        }
    } catch (e: TimeoutCancellationException) {
        Log.e(TAG, "Image OCR timed out", e)
        Result.failure(IllegalStateException("OCR প্রক্রিয়ার সময়সীমা শেষ হয়েছে (60s)। অনুগ্রহ করে পুনরায় চেষ্টা করুন।"))
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e(TAG, "Image OCR extraction failed", e)
        Result.failure(e)
    }

    suspend fun extractFromPdfUri(
        uri: Uri,
        subjectName: String,
        chapterTitle: String
    ): Result<OcrExtractionOutcome> = try {
        val (fileName, pageBitmaps, pdfBytes) = withContext(Dispatchers.IO) {
            val name = resolveDisplayName(uri, defaultPrefix = "question_paper", fallbackExt = "pdf")
            val rawBytes = readUriBytesLimited(uri, MAX_PDF_UPLOAD_BYTES)
            val renderedPages = renderPdfPages(uri, MAX_PDF_PAGES_FOR_OCR)
            if (renderedPages.isEmpty()) {
                throw IllegalStateException("PDF ফাইলে কোনো পাঠযোগ্য পৃষ্ঠা পাওয়া যায়নি।")
            }
            Triple(name, renderedPages, rawBytes)
        }

        val prompt = buildOcrPrompt(subjectName, chapterTitle, pageCount = pageBitmaps.size)
        val responseText = withTimeout(OCR_TIMEOUT_MS) {
            val response = ocrModel.generateContent(
                content {
                    pageBitmaps.forEach { pageBitmap ->
                        image(pageBitmap)
                    }
                    text(prompt)
                }
            )
            response.text
        } ?: throw IllegalStateException("PDF OCR মডেল কোনো উত্তর পাঠায়নি।")

        val drafts = parseDraftMcqsJson(responseText)
        if (drafts.isEmpty()) {
            Result.failure(
                IllegalStateException("PDF থেকে কোনো MCQ প্রশ্ন বের করা যায়নি। দয়া করে পরিষ্কার স্ক্যান করা প্রশ্নপত্র দিন।")
            )
        } else {
            Result.success(
                OcrExtractionOutcome(
                    fileName = fileName,
                    fileType = "pdf",
                    mimeType = "application/pdf",
                    fileBytes = pdfBytes,
                    pageCountProcessed = pageBitmaps.size,
                    draftQuestions = drafts
                )
            )
        }
    } catch (e: TimeoutCancellationException) {
        Log.e(TAG, "PDF OCR timed out", e)
        Result.failure(IllegalStateException("PDF OCR বিশ্লেষণে ৬০ সেকেন্ডের বেশি সময় লেগেছে। ছোট বা পরিষ্কার PDF দিন।"))
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e(TAG, "PDF OCR extraction failed", e)
        Result.failure(e)
    }

    internal fun parseDraftMcqsJson(jsonString: String): List<DraftExtractedMcq> {
        val root = JSONObject(jsonString)
        val arr = root.optJSONArray("questions") ?: return emptyList()
        val result = mutableListOf<DraftExtractedMcq>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val rawQ = TextbookMathFormatter.format(obj.optString("question", "").trim())
            val optA = TextbookMathFormatter.format(obj.optString("optionA", "").trim())
            val optB = TextbookMathFormatter.format(obj.optString("optionB", "").trim())
            val optC = TextbookMathFormatter.format(obj.optString("optionC", "").trim())
            val optD = TextbookMathFormatter.format(obj.optString("optionD", "").trim())

            if (rawQ.length < 3 || listOf(optA, optB, optC, optD).any { it.isBlank() }) {
                continue
            }

            val rawIndex = obj.optInt("correctIndex", 0).coerceIn(0, 3)
            val explanation = TextbookMathFormatter.format(obj.optString("explanation", "").trim())
            val rawDiff = obj.optString("difficulty", "medium").lowercase()
            val difficulty = if (rawDiff in listOf("easy", "medium", "hard")) rawDiff else "medium"

            result.add(
                DraftExtractedMcq(
                    tempId = "draft_${UUID.randomUUID()}",
                    question = rawQ,
                    options = listOf(optA, optB, optC, optD),
                    correctIndex = rawIndex,
                    explanation = explanation,
                    difficulty = difficulty
                )
            )
        }
        return result
    }

    private fun buildOcrPrompt(subjectName: String, chapterTitle: String, pageCount: Int): String =
        """
        You are an expert Bangladeshi NCTB SSC 2028 MCQ digitization engine.
        Inspect the provided $pageCount page(s) for Subject: "$subjectName", Chapter: "$chapterTitle".
        Extract every readable Multiple Choice Question (MCQ) cleanly:
        - Fix minor OCR spacing/spelling noise cleanly.
        - Convert mathematical expressions into crisp Unicode NCTB textbook style (√, π, ×, ÷, ±, x², x³, 1/x).
        - NEVER use raw LaTeX (\sqrt, \frac, $...$).
        - Put exact 4 options without "(ক)", "(খ)", "(গ)", "(ঘ)" or "a)", "b)" prefixes inside optionA..optionD.
        - Set correctIndex (0..3) if marked or clearly solvable, and provide a brief Bangla explanation.
        - Output strict JSON matching the provided schema.
        """.trimIndent()

    private fun resolveDisplayName(uri: Uri, defaultPrefix: String, fallbackExt: String): String {
        appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) {
                        val name = cursor.getString(idx)?.trim()
                        if (!name.isNullOrBlank()) return name.take(120)
                    }
                }
            }
        return "${defaultPrefix}_${System.currentTimeMillis()}.$fallbackExt"
    }

    private fun decodeDownsampledBitmap(uri: Uri, maxDimPx: Int): Bitmap? {
        val resolver = appContext.contentResolver
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOpts)
        }
        val origW = boundsOpts.outWidth
        val origH = boundsOpts.outHeight
        if (origW <= 0 || origH <= 0) return null

        var sampleSize = 1
        while (origW / sampleSize > maxDimPx || origH / sampleSize > maxDimPx) {
            sampleSize *= 2
        }

        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        val decoded = resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOpts)
        } ?: return null

        val maxSide = max(decoded.width, decoded.height)
        if (maxSide <= maxDimPx) return decoded
        val scale = maxDimPx.toFloat() / maxSide.toFloat()
        val targetW = (decoded.width * scale).roundToInt().coerceAtLeast(1)
        val targetH = (decoded.height * scale).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(decoded, targetW, targetH, true)
    }

    private fun compressBitmapJpeg(bitmap: Bitmap, maxBytes: Int): ByteArray {
        var quality = 85
        var bytes: ByteArray
        do {
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            bytes = out.toByteArray()
            quality -= 10
        } while (bytes.size > maxBytes && quality >= 35)
        return bytes
    }

    private fun readUriBytesLimited(uri: Uri, maxBytes: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        appContext.contentResolver.openInputStream(uri)?.use { input ->
            while (true) {
                val read = input.read(buf)
                if (read <= 0) break
                if (out.size() + read > maxBytes) {
                    throw IllegalStateException("ফাইলের আকার ১৫ MB সীমার চেয়ে বেশি। অনুগ্রহ করে ছোট PDF ব্যবহার করুন।")
                }
                out.write(buf, 0, read)
            }
        } ?: throw IllegalStateException("ফাইলটি খোলা যায়নি।")
        return out.toByteArray()
    }

    private fun renderPdfPages(uri: Uri, maxPages: Int): List<Bitmap> {
        val pfd = appContext.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("PDF ফাইল ডিস্ক্রিপ্টর খোলা যায়নি।")
        val bitmaps = mutableListOf<Bitmap>()
        try {
            PdfRenderer(pfd).use { renderer ->
                val count = renderer.pageCount.coerceAtMost(maxPages)
                for (i in 0 until count) {
                    renderer.openPage(i).use { page ->
                        val baseW = page.width.coerceAtLeast(1)
                        val baseH = page.height.coerceAtLeast(1)
                        val scale = (1200f / max(baseW, baseH).toFloat()).coerceIn(1f, 2f)
                        val w = (baseW * scale).roundToInt().coerceIn(300, MAX_IMAGE_DIM_PX)
                        val h = (baseH * scale).roundToInt().coerceIn(300, MAX_IMAGE_DIM_PX)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        Canvas(bmp).drawColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bitmaps.add(bmp)
                    }
                }
            }
        } finally {
            pfd.close()
        }
        return bitmaps
    }
}
