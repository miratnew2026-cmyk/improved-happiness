package com.example

import androidx.test.core.app.ApplicationProvider
import com.example.data.ai.OcrQuestionExtractor
import com.example.data.model.BookMcqSeedData
import com.example.data.model.McqQuestionRecord
import com.example.data.model.QuizModeType
import com.example.data.model.SscSyllabusData
import com.example.data.model.toPlayableMcq
import com.example.viewmodel.GuestQuizViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class QuizAndOcrUnitTest {

    @Test
    fun bookMcqSeedData_coversAllTwelveSubjectsWithValidOptions() {
        val allMcqs = BookMcqSeedData.allBookPlayableMcqs()
        assertTrue("Book MCQ pool should not be empty", allMcqs.size >= 30)

        val representedSubjectIds = allMcqs.map { it.subjectId }.toSet()
        SscSyllabusData.subjects.forEach { subject ->
            assertTrue(
                "Subject ${subject.id} (${subject.nameBn}) should have curated book MCQs",
                subject.id in representedSubjectIds
            )
        }

        allMcqs.forEach { mcq ->
            assertEquals("MCQ ${mcq.id} must have 4 options", 4, mcq.options.size)
            assertTrue("MCQ ${mcq.id} question must be non-blank", mcq.question.isNotBlank())
            assertTrue("MCQ ${mcq.id} options must be non-blank", mcq.options.all { it.isNotBlank() })
            assertTrue("MCQ ${mcq.id} correctIndex must be 0..3", mcq.correctIndex in 0..3)
        }
    }

    @Test
    fun mcqRecordToPlayable_preservesFieldsAndSourceBadges() {
        val record = McqQuestionRecord(
            id = "mcq_test_1",
            subjectId = "physics",
            subjectName = "পদার্থবিজ্ঞান",
            chapterNumber = 8L,
            chapterTitle = "আলোর প্রতিফলন",
            question = "1/u + 1/v = 1/f সমীকরণে f কী?",
            options = listOf("বক্রতার ব্যাসার্ধ", "ফোকাস দূরত্ব", "লক্ষ্যবস্তুর দূরত্ব", "বিম্বের দূরত্ব"),
            correctIndex = 1L,
            explanation = "গোলীয় দর্পণের প্রধান ফোকাস থেকে মেরু পর্যন্ত দূরত্বকে ফোকাস দূরত্ব f বলে।",
            difficulty = "easy",
            sourceType = "ocr_pdf",
            ocrReviewed = true,
            status = "published"
        )
        val playable = record.toPlayableMcq()
        assertEquals("mcq_test_1", playable.id)
        assertEquals("OCR PDF", playable.sourceBadge)
        assertEquals(8, playable.chapterNumber)
        assertEquals(1, playable.correctIndex)
        assertEquals(4, playable.options.size)
    }

    @Test
    fun ocrQuestionExtractor_parseDraftMcqsJson_formatsLatexAndSkipsInvalidEntries() {
        val context = ApplicationProvider.getApplicationContext<android.app.Application>()
        val extractor = OcrQuestionExtractor(context)
        val json = """
            {
              "questions": [
                {
                  "question": "যদি ${'$'}x = \\sqrt{6} + \\sqrt{5}${'$'} হয়, তবে ${'$'}x^2${'$'} কত?",
                  "optionA": "11 + 2\\sqrt{30}",
                  "optionB": "11 - 2\\sqrt{30}",
                  "optionC": "\\frac{1}{2}",
                  "optionD": "6 + 5",
                  "correctIndex": 0,
                  "explanation": "${'$'}(a+b)^2 = a^2 + 2ab + b^2${'$'}",
                  "difficulty": "medium"
                },
                {
                  "question": "অসম্পূর্ণ প্রশ্ন",
                  "optionA": "",
                  "optionB": "B",
                  "optionC": "C",
                  "optionD": "D",
                  "correctIndex": 1,
                  "explanation": "",
                  "difficulty": "easy"
                }
              ]
            }
        """.trimIndent()

        val drafts = extractor.parseDraftMcqsJson(json)
        assertEquals("Should extract 1 valid MCQ and skip blank-option entry", 1, drafts.size)

        val item = drafts.first()
        assertFalse("Formatted question must not contain raw latex $ delimiters", item.question.contains("$"))
        assertTrue("Formatted question should contain Unicode sqrt √6", item.question.contains("√6"))
        assertTrue("Formatted question should contain superscript x²", item.question.contains("x²"))
        assertEquals("1/2", item.options[2])
        assertEquals("medium", item.difficulty)
    }

    @Test
    fun guestQuizViewModel_runsBookQuizOfflineAndRecordsMistakesWithoutFirebase() {
        val guestVm = GuestQuizViewModel()
        guestVm.selectSubject("physics")
        guestVm.selectMode(QuizModeType.BOOK_MCQ)
        guestVm.setQuestionLimit(5)
        guestVm.startConfiguredQuiz()

        val started = guestVm.sessionState.value
        assertTrue("Guest quiz session should activate immediately without sign-in", started.isActive)
        assertFalse("Session should not be submitted yet", started.isSubmitted)
        assertTrue("Should load physics book MCQs", started.questions.isNotEmpty())

        val firstMcq = started.questions.first()
        val wrongOptionIndex = (firstMcq.correctIndex + 1) % firstMcq.options.size
        guestVm.selectAnswer(0, wrongOptionIndex)

        val recordedMistakes = mutableListOf<String>()
        guestVm.submitActiveQuiz { _, _, question, _, _, _ ->
            recordedMistakes.add(question)
        }

        val completed = guestVm.sessionState.value
        assertTrue("Session should mark submitted", completed.isSubmitted)
        assertFalse("Guest mode must not claim cloud save is active", completed.isSavingAttempt)
        assertTrue("Wrongly answered / skipped questions must invoke local mistake callback", recordedMistakes.contains(firstMcq.question))
        guestVm.closeSession()
    }

    @Test
    fun guestQuizViewModel_promptsSignInWhenAgentUploadedModeSelectedUnauthenticated() {
        val guestVm = GuestQuizViewModel()
        guestVm.selectMode(QuizModeType.AGENT_UPLOADED)
        guestVm.startConfiguredQuiz()

        assertFalse("Agent uploaded quiz should not start when unauthenticated", guestVm.sessionState.value.isActive)
        assertNotNull("Banner should ask user to sign in for agent quizzes", guestVm.selectionState.value.bannerMessage)
    }
}
